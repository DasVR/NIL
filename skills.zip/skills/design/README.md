# NIL Frontend Design Skills

Hermes design skills installed for NIL and all premium UI work.

## Anti-slop / taste
- `taste-skill` — anti-slop frontend skill, brief inference first
- `taste-soft-skill` — airy, premium interfaces with spring physics
- `taste-minimalist-skill` — clean editorial / tool-focused UIs
- `taste-redesign-skill` — audit-first redesigns
- `taste-image-to-code` — three-stage image-to-code workflow
- `hallmark` — (already installed) 57 slop-test gates

## Design framework
- `impeccable` — operational commands + 7 playbooks
- `open-design-web-guidelines` — Vercel Web Interface Guidelines compliance

## Ship gates / craft checks
- `tastecheck-design-system-interview` — interview before building
- `tastecheck-responsive-layout` — responsive patterns
- `tastecheck-spacing-system` — spacing system rules
- `tastecheck-web-typography` — typography foundations
- `tastecheck-micro-motion` — motion principles
- `tastecheck-improve-existing-website` — existing site improvement

## Token architecture
- `design-system` — (already installed) three-layer token system
- `ui-ux-pro-max` — (already installed) 79 styles, 192 palettes
