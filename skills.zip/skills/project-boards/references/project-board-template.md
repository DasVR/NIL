# PROJECT BOARD — [Name / Area]
## Updated: YYYY-MM-DD
## Where we talk about work, track everything, and decide what to lock in on

---

## AT A GLANCE — CURRENT STATE

| Area | Status | Blocker |
|------|--------|---------|
| **Thing A** | Live / Scaffolded / Not Started | What's blocking it |
| **Thing B** | Running but rough | Specific blocker |

---

## ACTIVE — Working On Right Now

### A1. [Task Name]
**Goal:** One sentence
- [ ] Concrete subtask
- [ ] Concrete subtask

**Why this matters:** Why the user should care

**ETA:** X days/hours

---

## BACKLOG — Next Up After Active

### B1. [Task Name]
- [ ] Step
- [ ] Step

**Priority:** High / Medium / Low — why

---

## BLOCKED — Waiting On Something

| Blocker | What It's Blocking | What You Need To Do |
|---------|-------------------|---------------------|
| No real client work | Portfolio content | Build 2-3 mock projects |
| Supabase creds missing | Dashboard auth | Log into supabase.com, copy URL + anon key |

---

## DONE — Recently Completed

- [x] Thing that got done

---

## QUICK WINS — Do These Today (Under 1 Hour Each)

1. **Thing** — why it matters, time estimate
2. **Thing** — why it matters, time estimate

---

## WEEKLY RHYTHM (Suggested)

| Day | Focus |
|-----|-------|
| **Monday** | Outreach / admin |
| **Tuesday** | Build / polish |
| **Wednesday** | Infrastructure / experiments |
| **Thursday** | Build / polish |
| **Friday** | Follow-ups |
| **Weekend** | Chill or grind if hyped |

---

## NOTES / RANDOM IDEAS

- Idea that doesn't fit anywhere else
- Future direction
- Random context
