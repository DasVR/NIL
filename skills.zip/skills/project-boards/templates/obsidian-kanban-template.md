---
kanban-plugin: basic
---

# KANBAN — [Name]
## Updated: [Date]

## 🔥 To Do — Not Started / Backlog

### Income + Clients
- [ ] Task

### Creative + Content
- [ ] Task

### Homelab + Infrastructure
- [ ] Task

### Tools + Skills
- [ ] Task

### School + Personal
- [ ] Task

## 🔄 In Progress — Active Right Now

- [ ] Task with context

## ⏳ Blocked — Waiting On Something

| Blocker | What It's Blocking | What You Need To Do |
|---------|-------------------|---------------------|
| ...     | ...               | ...                 |

## ✅ Done — Recently Completed

### This Week
- [x] Task

### Earlier (Last Month)
- [x] Task

### Foundation (Earlier)
- [x] Task

## 💡 Ideas — Future / Not Committed

- Idea with context

---

*Last updated: [Date]*
*This doc lives at [Path]*
*Edit anytime. Tag #for-finn to ping me about changes.*
