# MASTER BOARD — Unified Living Plan Template

Use this when the user wants "one big plan file" that consolidates EVERYTHING — homelab, portfolio, school, income, tools, routines, and schedule.

## Where to save
`/home/das/MASTER-BOARD.md` (or user's home directory)

## When to use
- User says "make everything set in stone"
- User wants a unified view across all life areas
- Multiple scattered plan docs exist (`MASTER-PLAN.md`, `PROJECTS.md`, `MASTER-EXECUTION-PLAN.md`, etc.)
- User specifically asks for "one doc to rule them all"

## Structure

```markdown
# MASTER BOARD — [Name]
## Living Document | Updated: [Date]
## One doc to rule them all. Edit this. Reference this. Don't let plans scatter.

---

## AT A GLANCE — CURRENT STATE

| Area | Status | Blocker | Notes |
|------|--------|---------|-------|
| **Portfolio** | ... | ... | ... |
| **Homelab** | ... | ... | ... |
| **Income** | ... | ... | ... |
| **School** | ... | ... | ... |
| **Tools** | ... | ... | ... |

---

## ACTIVE — Working On Right Now

### A1. [Task Name]
**Goal:** ...
- [ ] step
- [ ] step
**Why it matters:** ...
**ETA:** ...

---

## BACKLOG — Next Up After Active

### B1. [Task Name]
- [ ] step
**Priority:** ...

---

## BLOCKED — Waiting On Something

| Blocker | What It's Blocking | What You Need To Do |
|---------|-------------------|---------------------|
| ... | ... | ... |

---

## DONE — Recently Completed

- [x] thing
- [x] thing

---

## QUICK WINS — Do These Today (Under 30 Min Each)

1. **Thing** — why it matters

---

## SCHOOL SCHEDULE + DAILY ROUTINE

### When School Starts

| Time Block | Activity | Where |
|------------|----------|-------|
| 6:30 AM | Wake up | Bed |
| ... | ... | ... |

### Deep Work Rules
- Phone in another room
- One task only
- 50 min work / 10 min break

---

## TOOL INVENTORY — What We Have Where

| Tool | URL / Path | Status | Purpose |
|------|-----------|--------|---------|
| ... | ... | ... | ... |

---

## DOCUMENT INVENTORY — All Your Docs

| Document | Location | Status |
|----------|----------|--------|
| ... | ... | ... |

---

## WHAT TO IGNORE (For Now)

- ...

---

## NEXT ACTIONS (When You Get Back)

1. ...

---

*This doc lives at `/home/das/MASTER-BOARD.md`. Edit it anytime. Tell me what changed.*
```

## Key Differences from Simple Project Board
- Includes **Tool Inventory** and **Document Inventory** tables
- Includes **School Schedule + Daily Routine** section
- Includes **What to Ignore** section to reduce noise
- "At a Glance" has a Notes column for extra context
- More comprehensive than the basic kanban-style board

## How to build it
1. Search home dir for all `*PLAN*`, `*MASTER*`, `PROJECTS.md`, `*.md` planning docs
2. Read the 3-5 most recent / largest ones
3. Extract every item and sort into buckets
4. Build the consolidated structure above
5. Save to `~/MASTER-BOARD.md`
6. Copy to user's active project repo (e.g. `~/portfolio-v2/`) so Cursor IDE has context
