---
name: project-boards
description: Maintain living markdown project boards that consolidate scattered plans into an actionable kanban-style tracking system.
triggers:
  - User has many scattered planning documents and wants a centralized view
  - User asks "what do we need to work on" or "what should we be doing"
  - User wants a productivity place to track projects and status
  - Accumulated plans, research docs, or master plans need consolidation
  - User says they feel overwhelmed by scattered documents
  - User explicitly asks for "one big plan file" or a unified master board
  - User wants everything (homelab, portfolio, school, income, tools) in one doc
---

# Living Project Boards

When a user has accumulated many planning documents, master plans, research docs, or TODO lists and needs a centralized place to track what's actually happening:

## Workflow

1. **Deep Audit** — Search across ALL document locations:
   - Obsidian vault (`vault/Master/**/*.md`)
   - Home directory (`~/*.md`, `~/hermes-plans/*.md`, `~/MASTER*`)
   - Active project repos (`portfolio-v2/cursor-research/*.md`)
   - Read 20-40 files to catch everything, not just recent ones.
2. **Categorize** — Sort every item into exactly one bucket:
   - **To Do** — Not started, no blockers, ready to pick up
   - **In Progress** — Currently being worked on, has momentum
   - **Blocked** — Waiting on external thing (hardware, credentials, DNS, etc.)
   - **Done** — Completed items, tiered by time (This Week / Earlier / Foundation)
   - **Ideas** — Future concepts, not committed yet
3. **Write** — Save as `Kanban.md` in the Obsidian vault (preferred) or `~/PROJECTS.md`.
4. **Format** — Use kanban-plugin YAML frontmatter for Obsidian Kanban visual view. Group items by category (Income, Creative, Homelab, Tools, School, Personal).

## Document Structure

```markdown
---
kanban-plugin: basic
---

# PROJECT KANBAN — [Name]
## Updated: [Date]

## 🔥 To Do — Not Started / Backlog
- [ ] Task by category (Income, Creative, Homelab, etc.)

## 🔄 In Progress — Active Right Now
- [ ] Task with context

## ⏳ Blocked — Waiting On Something
| Blocker | What It's Blocking | What You Need To Do |

## ✅ Done — Recently Completed
- [x] This Week
- [x] Earlier
- [x] Foundation

## 💡 Ideas — Future / Not Committed
- Idea with context
```

## Key Principles

- The board is a **living document** — user edits it manually, agent reads it back at session start
- **User prefers Obsidian Kanban plugin** for visual board view over AFFiNE. Save `Kanban.md` to the Obsidian vault with `--- kanban-plugin: basic ---` YAML frontmatter.
- Done items must be **tiered by time** — split into This Week / Earlier / Foundation sections so the board doesn't become a graveyard.
- Group tasks **by life category** (Income, Creative, Homelab, Tools, School, Personal) within each column so scanning is fast.
- Blockers must have a **"what you need to do"** column to make next action clear
- **When user is AFK / away:** Keep working on active items, fix broken things, build infrastructure. Summarize what got done when they return. Don't ask questions they can't answer while away.
- **PUSH TO GITHUB IMMEDIATELY** after any meaningful changes. The user expects repos pushed so Cursor IDE has context. Standard workflow: commit and push after creating or updating the plan.
- **When vault write fails** (permission denied): the Obsidian vault files may be owned by the container user (UID 82) with no group write. Use `sudo tee <path>` to write the file, then verify with `cat`.

## Skill Files

- `templates/master-board-template.md` — Full unified "one doc to rule them all" template. Use when user wants everything consolidated (homelab + portfolio + school + income + tools + routines) rather than a simple kanban board.
- `templates/obsidian-kanban-template.md` — 5-column kanban with category groupings inside each column, tiered Done section, and blocked table. Use for Obsidian Kanban plugin.

## Pitfalls

- **Don't** create a new board every session — update the existing one
- **Don't** let done items pile up forever — tier them (This Week / Earlier / Foundation) and archive old ones
- **Don't** put vague wishes in active — active items need concrete next actions
- **Don't** skip the blocked section — hiding blockers makes them fester
- **Don't** overbuild — the board is a conversation tool, not a Jira replacement
- **Don't** use AFFiNE for kanban — this user prefers Obsidian Kanban plugin; AFFiNE is docs-only for them
- **Don't** stop at surface-level docs — do a deep audit across vault + home dir + repos to catch everything
- **Don't** forget to push to GitHub — user expects repos pushed so Cursor IDE has context
