#!/bin/bash
# Extract config.plist from an OpenCore qcow2 boot disk using guestfish INSIDE the Docker-OSX container.
# This avoids the nested shell quoting problem (sg docker -c "docker exec ... bash -c '...'")
# by using a script file + docker cp instead of inline commands.
#
# Usage:
#   1. docker cp this script into the container: docker cp <this-file> bbubbles:/tmp/extract-config.sh
#   2. docker exec bbubbles bash /tmp/extract-config.sh
#   3. The config.plist contents are printed to stdout (filter with grep for serials)
#
# To verify serial numbers are injected, pipe output:
#   docker exec bbubbles bash /tmp/extract-config.sh 2>/dev/null | grep -A1 "SystemSerialNumber\|MLB\|SystemUUID\|SystemProductName"
#
# The qcow2 path can be overridden with the BOOTDISK env var (default: /home/arch/OSX-KVM/OpenCore/OpenCore.qcow2)

BOOTDISK="${BOOTDISK:-/home/arch/OSX-KVM/OpenCore/OpenCore.qcow2}"

echo "=== Extracting config.plist from $BOOTDISK ===" >&2
guestfish --ro -a "$BOOTDISK" << 'GUESTFISH_EOF'
run
mount /dev/sda1 /
cat /EFI/OC/config.plist
GUESTFISH_EOF