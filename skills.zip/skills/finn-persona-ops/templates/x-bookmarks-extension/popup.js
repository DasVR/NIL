// Popup script - handles UI and export logic
// Adapt this for other scraping tasks by changing the selectors and data shape

let exportFormat = 'json';
let collectedData = [];
let scrapingActive = false;

function setFormat(fmt) {
  exportFormat = fmt;
  document.querySelectorAll('.format-sel button').forEach(b => b.classList.remove('active'));
  document.getElementById(fmt + 'Btn').classList.add('active');
}
window.setFormat = setFormat;

function updateStatus(msg) { document.getElementById('status').textContent = msg; }
function updateCount(count) { document.getElementById('counter').textContent = `${count} bookmarks`; }

async function startExport() {
  const includeReplies = document.getElementById('includeReplies').checked;
  const includeMedia = document.getElementById('includeMedia').checked;
  const scrollDelay = parseInt(document.getElementById('scrollDelay').value) || 800;
  const maxScrolls = parseInt(document.getElementById('maxScrolls').value) || 0;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes('bookmarks')) {
    updateStatus('Please go to x.com/i/bookmarks first!');
    return;
  }

  scrapingActive = true;
  collectedData = [];
  document.getElementById('startBtn').style.display = 'none';
  document.getElementById('stopBtn').style.display = 'block';
  document.getElementById('downloadBtn').style.display = 'none';
  updateStatus('Scrolling and scraping...');
  updateCount(0);

  chrome.tabs.sendMessage(tab.id, {
    type: 'START_SCRAPING',
    delay: scrollDelay,
    maxScrolls: maxScrolls,
    includeReplies: includeReplies
  });

  const pollInterval = setInterval(async () => {
    if (!scrapingActive) { clearInterval(pollInterval); return; }
    chrome.tabs.sendMessage(tab.id, { type: 'GET_DATA' }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response && response.data) {
        collectedData = response.data;
        updateCount(collectedData.length);
      }
    });
  }, 500);

  const doneCheck = setInterval(async () => {
    if (!scrapingActive) { clearInterval(doneCheck); finishExport(includeMedia); }
  }, 1000);

  setTimeout(() => { if (scrapingActive) stopExport(); }, 600000);
}

function stopExport() {
  scrapingActive = false;
  document.getElementById('stopBtn').style.display = 'none';
  document.getElementById('startBtn').style.display = 'block';
  chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    chrome.tabs.sendMessage(tab.id, { type: 'GET_DATA' }, (response) => {
      if (response && response.data) {
        collectedData = response.data;
        updateCount(collectedData.length);
      }
      finishExport(document.getElementById('includeMedia').checked);
    });
  });
}

function finishExport(includeMedia) {
  if (!includeMedia) {
    collectedData = collectedData.map(t => {
      const { media, ...rest } = t;
      return rest;
    });
  }
  updateStatus(`Done! ${collectedData.length} bookmarks collected. Click Download to save.`);
  document.getElementById('stopBtn').style.display = 'none';
  document.getElementById('startBtn').style.display = 'block';
  document.getElementById('downloadBtn').style.display = 'block';
}

function downloadFile() {
  let content = '', filename = '', mimeType = '';
  if (exportFormat === 'json') {
    content = JSON.stringify(collectedData);
    filename = `x-bookmarks-${Date.now()}.json`;
    mimeType = 'application/json';
  } else if (exportFormat === 'csv') {
    const headers = ['id','url','author','handle','text','timestamp','replies','retweets','likes','views','isReply','replyingTo','media'];
    const rows = collectedData.map(t => [
      t.id, t.url, `"${(t.author||'').replace(/"/g,'""')}"`, t.handle,
      `"${(t.text||'').replace(/"/g,'""').replace(/\n/g,' ')}"`, t.timestamp,
      t.metrics?.replies||0, t.metrics?.retweets||0, t.metrics?.likes||0, t.metrics?.views||0,
      t.isReply?'yes':'no', t.replyingTo||'',
      t.media?`"${t.media.map(m=>m.url).join('; ')}"`:''
    ].join(','));
    content = headers.join(',') + '\n' + rows.join('\n');
    filename = `x-bookmarks-${Date.now()}.csv`;
    mimeType = 'text/csv';
  } else if (exportFormat === 'md') {
    content = collectedData.map((t, i) => {
      let entry = `### ${i+1}. ${t.author||'Unknown'} (${t.handle||''})\n`;
      entry += `**Date:** ${t.timestamp}\n**URL:** ${t.url}\n**Text:** ${t.text||''}\n`;
      entry += `**Engagement:** ${t.metrics?.replies||0} replies | ${t.metrics?.retweets||0} retweets | ${t.metrics?.likes||0} likes | ${t.metrics?.views||0} views\n`;
      if (t.isReply) entry += `**Reply to:** ${t.replyingTo||''}\n`;
      if (t.media?.length) entry += `**Media:** ${t.media.map(m=>m.url).join(', ')}\n`;
      return entry + '---\n';
    }).join('\n');
    filename = `x-bookmarks-${Date.now()}.md`;
    mimeType = 'text/markdown';
  }
  const blob = new Blob([content], { type: mimeType });
  const reader = new FileReader();
  reader.onload = () => {
    chrome.runtime.sendMessage({ type: 'DOWNLOAD_FILE', url: reader.result, filename });
  };
  reader.readAsDataURL(blob);
}

window.startExport = startExport;
window.stopExport = stopExport;
window.downloadFile = downloadFile;