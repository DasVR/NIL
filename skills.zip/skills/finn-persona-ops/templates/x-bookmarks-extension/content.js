// X Bookmarks Exporter - Content Script
// Runs on x.com/bookmarks page, scrapes tweets as user scrolls

let scraping = false;
let collected = new Map(); // dedupe by tweet id
let scrollCount = 0;

function getTweetData(tweetEl) {
  try {
    const link = tweetEl.querySelector('a[href*="/status/"]');
    const href = link?.getAttribute('href') || '';
    const url = href.startsWith('http') ? href : `https://x.com${href}`;
    const idMatch = url.match(/status\/(\d+)/);
    const id = idMatch ? idMatch[1] : '';

    const authorEl = tweetEl.querySelector('[data-testid="User-Name"]') || tweetEl.querySelector('a[role="link"] span');
    let author = authorEl?.textContent?.trim() || '';
    let handle = '';
    const handleLink = tweetEl.querySelector('a[href^="/"][href*="/status/"]');
    if (handleLink) {
      const handleMatch = handleLink.getAttribute('href')?.match(/^\/([^\/]+)/);
      if (handleMatch) handle = '@' + handleMatch[1];
    }

    const textEl = tweetEl.querySelector('[data-testid="tweetText"]') || tweetEl.querySelector('[lang]');
    const text = textEl?.textContent?.trim() || '';

    const timeEl = tweetEl.querySelector('time');
    const timestamp = timeEl?.getAttribute('datetime') || timeEl?.textContent || '';

    const getMetric = (label) => {
      const groups = tweetEl.querySelectorAll('[role="group"] button');
      for (const g of groups) {
        const aria = g.getAttribute('aria-label') || '';
        if (aria.includes(label)) {
          const match = aria.match(/(\d[\d,]*)/);
          return match ? parseInt(match[1].replace(/,/g, '')) : 0;
        }
      }
      return 0;
    };

    const replies = getMetric('repl');
    const retweets = getMetric('repost') + getMetric('Repost');
    const likes = getMetric('like');
    const views = getMetric('view');

    const media = [];
    const imgs = tweetEl.querySelectorAll('img[src*="pbs.twimg.com/media"]');
    imgs.forEach(img => media.push({ type: 'image', url: img.src }));
    const vids = tweetEl.querySelectorAll('video[src]');
    vids.forEach(v => media.push({ type: 'video', url: v.src }));

    const isReply = tweetEl.textContent?.includes('Replying to') || false;
    const replyingTo = tweetEl.querySelector('a[href*="/status/"]:not([href*="' + id + '"])')?.getAttribute('href') || '';

    return {
      id, url, author, handle, text, timestamp,
      metrics: { replies, retweets, likes, views },
      media: media.length > 0 ? media : undefined,
      isReply,
      replyingTo: replyingTo ? `https://x.com${replyingTo}` : undefined
    };
  } catch (e) {
    return null;
  }
}

function scrapeVisible() {
  const tweets = document.querySelectorAll('[data-testid="tweet"]');
  let newCount = 0;
  tweets.forEach(tweet => {
    const data = getTweetData(tweet);
    if (data && data.id && !collected.has(data.id)) {
      collected.set(data.id, data);
      newCount++;
    }
  });
  return newCount;
}

async function autoScroll(delay, maxScrolls, includeReplies) {
  scrollCount = 0;
  let noNewCount = 0;
  while (scraping) {
    const newCount = scrapeVisible();
    if (newCount > 0) noNewCount = 0;
    else noNewCount++;
    window.postMessage({ type: 'BOOKMARK_PROGRESS', count: collected.size, scrollCount, done: false }, '*');
    if (maxScrolls > 0 && scrollCount >= maxScrolls) break;
    if (noNewCount > 10) break;
    window.scrollBy(0, window.innerHeight * 0.8);
    scrollCount++;
    await new Promise(r => setTimeout(r, delay));
  }
  scrapeVisible();
  window.postMessage({ type: 'BOOKMARK_PROGRESS', count: collected.size, scrollCount, done: true }, '*');
}

window.addEventListener('message', (e) => {
  if (e.data.type === 'START_SCRAPING') {
    scraping = true;
    collected.clear();
    autoScroll(e.data.delay, e.data.maxScrolls, e.data.includeReplies);
  } else if (e.data.type === 'STOP_SCRAPING') {
    scraping = false;
  } else if (e.data.type === 'GET_DATA') {
    window.postMessage({ type: 'BOOKMARK_DATA', data: Array.from(collected.values()) }, '*');
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'START_SCRAPING') {
    scraping = true;
    collected.clear();
    autoScroll(msg.delay, msg.maxScrolls, msg.includeReplies);
    sendResponse({ ok: true });
  } else if (msg.type === 'STOP_SCRAPING') {
    scraping = false;
    sendResponse({ ok: true });
  } else if (msg.type === 'GET_DATA') {
    sendResponse({ data: Array.from(collected.values()) });
  }
  return true;
});