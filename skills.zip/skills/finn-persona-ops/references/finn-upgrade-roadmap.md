# Finn Upgrade Roadmap — From Bookmarks Arsenal

Condensed roadmap derived from `/home/das/hermes-plans/finn-master-upguide.md` (July 14, 2026).
The full guide has 5 parts; this reference captures the actionable feature roadmap and action plan.

## Phase 1: Quick Wins (This Week)
1. ✅ **Switch fast_model to gemma3:4b** — DONE July 15 2026. `hermes config set model.fast_model gemma3:4b`.
2. **Install design skills** — emilkowalski/skills, tasteskill.dev, GSAP animation pack as Hermes skills. 2-3 hrs.
3. **Install Reicon + Blossom Carousel** as design assets. 1 hr.
4. **Create Spec Kit skill** — Force spec-before-build for coding tasks. 2-3 hrs.
5. **Enable humanize disabled features** — Afterthoughts, inside jokes. 30 min.
6. ✅ **Install Watchtower on server** — DONE July 15 2026. Deployed in foundation stack. Needed `DOCKER_API_VERSION=1.45` env var fix.
7. **Update CHANGES-LOG.md** — Document recent work. 30 min.
8. ✅ **Deploy Phase 1 foundation services** — DONE July 15 2026. Caddy, AdGuard, Vaultwarden, Beszel, Uptime Kuma, ntfy, Watchtower, Fail2Ban. See `references/homelab-deployment.md` for details.
9. ✅ **Kill old QEMU VM** — DONE July 15 2026. Freed 7.4GB RAM. Old Docker-OSX was running as bare QEMU process, not in Docker container.
10. ✅ **Model benchmarks** — DONE July 15 2026. v2 benchmarks tested 20 models (results at `/home/das/hermes-plans/ollama-model-benchmarks-v2.md`). v3 benchmarks running with 32 STABLE models (excluded gemini-3-flash-preview and gpt-oss:20b which are broken/preview). Results at `/home/das/hermes-plans/ollama-model-benchmarks-v3.md`.
11. ✅ **Rebuild model router** — DONE July 15 2026. Multi-role complexity detection with 8 roles (casual/coding/reasoning/creative/complex/classifier/memory/browser), zero-latency Python string analysis, 15/15 test pass rate. See `references/model-router-design.md` for full design details. Reasoning model updated from nemotron-3-ultra to qwen3-coder-next after v2 benchmarks showed better output quality.
12. ✅ **Fun services research** — DONE July 15 2026. 120 services compiled at `/home/das/hermes-plans/homelab-fun-services.md`. 10 categories with Docker images, GitHub URLs, RAM estimates, fun ratings.
13. ✅ **Master homelab plan** — DONE July 15 2026. Combined doc at `/home/das/hermes-plans/das-homelab-master-plan.md` (42KB, 1477 lines). Supersedes server-upgrade-2026.md and ubuntu-server-toolkit.md.
14. ✅ **Bookmarks arsenal v2** — DONE July 15 2026. Full 229-bookmark compiled doc at `/home/das/x-bookmarks-arsenal-v2.md` (108KB, 4264 lines). All 13 categories with reply context.
15. ✅ **Finn master upgrade guide** — DONE July 14 2026. At `/home/das/hermes-plans/finn-master-upguide.md` (46KB, 726 lines). 5 parts: arsenal explained, new features, teaching Finn, doc review, action plan.

## Phase 2: MCP Servers (Next Week)
1. **Graphify** — Codebase knowledge graph. `uv tool install graphifyy` + `graphify install`. Configure as MCP server. Half a day.
2. **NotebookLM MCP** — Research brain that builds knowledge over time. Half a day.
3. **Stealth Browser MCP** — 97 anti-bot tools. `npx -y @anthropic/mcp-server-stealth-browser`. Half a day.
4. **Test all MCP servers** with real tasks. Half a day.

## Phase 3: Voice + Advanced (Week 3)
1. **pocket-tts** on server — Already installed at `/tmp/pocket_tts_env/`. Need to wire as tool + create skill. 1 day.
2. **Voice skill** — When to use voice, how to generate. Half a day.
3. ~~**Obsidian vault** — Structured knowledge base.~~ ❌ REPLACED July 24: sqlite-vec vector memory instead (see `references/agent-memory-research.md`)
4. ✅ **Vector memory (sqlite-vec)** — DONE July 24 2026. RAG-style memory retrieval built and tested. Plugin at `plugins/memory/vector-memory/`. Uses `all-MiniLM-L6-v2` embeddings (384-dim, local, free), sqlite-vec for cosine similarity search, retrieves top-8 relevant memories per query instead of injecting all. See `references/agent-memory-research.md` for full details.
5. **Retrospective loop** — After-task review notes. Half a day.
6. **Homepage + Beszel** — Server dashboard + monitoring. 1 day.

## Phase 4: Automation (Week 4+)
1. **Fiverr profile** with parent account — Web design clients. 1 day.
2. **AI employee workflow** — Finn finds leads, drafts proposals, texts Arriq. 2-3 days.
3. **AutoSocial** — Social media automation for photography. 1 day.
4. **MoneyPrinterTurbo** — Automated content pipeline. 1 day.
5. **n8n** — Visual automation replacing manual cron jobs. 1-2 days.

## Phase 5: Deep Upgrades (Month 2+)
1. **Self-improving loops** — Finn reviews past work, updates skills. 2-3 days.
2. **Multi-agent team** — PM + devs + tester for complex projects. 1-2 weeks.
3. **Fine-tune on conversation history** — Like the iMessage example from bookmarks. Research first.
4. **Fable-method problem-solving skill** — Distill structured loop. 1 day.
5. **Agent mail** — Give Finn a real inbox. 2-3 days.
6. **Birdclaw** — Local Twitter archive replacing the extension. 1 day.

## Key Insight
"Finn doesn't need a better model. Finn needs better tools, better skills, and better loops."
The Anthropic engineer making $1.2M/year with the same model proves it — the setup is the ceiling, not the model.

## Document Overlap (Consolidation Targets)
- **Humanization cluster** (5 docs): humanizing-finn.md + research + implementation + teen-texting + tomo → consolidate into one
- **Server cluster** (2 docs): server-upgrade-2026.md + ubuntu-server-toolkit.md → merge
- **Execution plan cluster** (3 docs): v1 + v2 + ADVANCED-SETUP-PLAN → archive v1, keep v2 + Advanced
- **Change tracking** (3 docs): CHANGES-LOG + night-update + discord-changes → fold into CHANGES-LOG

## Biggest Gaps (All have bookmark solutions)
1. No voice capability → pocket-tts/LuxTTS/Fish Audio
2. No codebase intelligence → graphify
3. No anti-bot browsing → stealth-browser-mcp
4. No research brain → NotebookLM MCP
5. No self-improving loop → Obsidian retrospective loop
6. No content pipeline → AutoSocial/MoneyPrinterTurbo
