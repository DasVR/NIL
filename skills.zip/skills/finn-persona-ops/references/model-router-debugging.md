# Model Router Plugin Debugging Notes

**Session:** July 30 2026
**Plugin:** `~/.hermes/plugins/hermes-model-router/`

## Syntax Error (Fixed July 30)
`__init__.py` had a duplicated code block at lines 93-99 — the `has_multi_step = any(...)` assignment and preceding list elements were pasted 3×, causing an indent/syntax error that prevented the plugin from loading at all.

**Fix:** Remove the duplicate lines so only one `has_multi_step` assignment remains.

**Verification:**
```bash
python3 -c "import ast; ast.parse(open('~/.hermes/plugins/hermes-model-router/__init__.py').read()); print('syntax OK')"
```

**Important:** After fixing the file on disk, the running Hermes session does NOT pick up the fix. A session restart (`/new` or full restart) is required for the plugin loader to re-import the fixed module.

## Hook Name Mismatch
The plugin manifest (`plugin.yaml`) declares `pre_turn_context_build`, but this hook name is NOT observed in other working plugins. Valid hooks used by working plugins:
- `pre_gateway_dispatch` — fires on incoming gateway messages
- `pre_llm_call` — fires before every LLM tool loop, receives `(session_id, user_message, conversation_history, is_first_turn, model, platform)`
- `post_llm_call` — fires after LLM response

**Implication:** `pre_turn_context_build` may never fire, which explains why casual messages are still routed to `kimi-k2.6` instead of `deepseek-v4-flash`.

**Recommended fix:** Re-implement router logic inside `pre_llm_call` where `agent.model` can be modified directly based on `_analyze_complexity(user_message)`.

## hermes-token-router vs hermes-tool-router
`hermes-token-router` is a **ghost entry** in `config.yaml` plugins.enabled — the directory `~/.hermes/plugins/hermes-token-router/` contains only an empty `__init__.py` and `plugin.yaml` with no actual routing logic. This plugin is dead/placeholder.

The **actual** token-saving plugin is **`hermes-tool-router`** (which confusingly uses `name: hermes-token-router` in its own `plugin.yaml`). It lives at `~/.hermes/plugins/hermes-tool-router/` and narrows tool schemas to reduce prompt token overhead. It works and should remain enabled.

**Pitfall:** Do NOT create a new `hermes-token-router` plugin — it will conflict with the real `hermes-tool-router`.

## vector-memory Plugin Must Be Explicitly Enabled
Setting `memory.provider: vector-memory` in `config.yaml` is NOT sufficient. The plugin must ALSO appear in:
```yaml
plugins:
  enabled:
    - ...
    - vector-memory
```
Without this, the plugin loader skips it entirely — silent failure, no error logged.

## Config.yaml Writes Are Blocked
The `patch` tool refuses to write `~/.hermes/config.yaml` with error:
> "Refusing to write to Hermes config file. Edit ~/.hermes/config.yaml directly or use 'hermes config' instead."

**Workaround:** Use Python yaml manipulation via `terminal` or the `hermes config` CLI.

## Available Ollama Cloud Models (July 30 2026)
Cache shows 18 models including:
- `deepseek-v4-flash`
- `kimi-k2.7-code`
- `kimi-k2.6`
- `glm-5.2`
- `gemma4:31b`
- `nemotron-3-ultra`
- `qwen3.5:397b`

The router `config.yaml` references models that DO exist in the cache, so model availability is not the issue — hook registration is.

## User Preference: Token Efficiency
User explicitly complained: "you use too many tokens for this casual convo." This means the router MUST work for casual chat — routing simple greetings/replies to a smaller model (`deepseek-v4-flash` or `gemma3:4b`) instead of the main model (`kimi-k2.6`).

## Verification After Restart
After fixing the router and restarting, check logs for routing evidence:
```bash
grep -i "model-router\|hermes-model-router" ~/.hermes/logs/gateway.log | tail -5
```
Expected output on a casual message like "yo":
```
hermes-model-router: routed to deepseek-v4-flash (category=casual, score=0, words=1, code=False, tools=False)
```
If the router is NOT firing, check:
1. Plugin syntax is valid (`python3 -m py_compile __init__.py`)
2. Plugin is in `plugins.enabled`
3. Session was restarted AFTER the fix
4. The `register` function in `__init__.py` calls `ctx.register_hook("pre_llm_call", ...)` not `pre_turn_context_build`