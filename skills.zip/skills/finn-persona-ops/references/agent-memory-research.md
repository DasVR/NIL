# Agent Memory Systems — Research Notes (July 2026)

Condensed findings from evaluating production-grade memory options for Finn's
humanization plugin. The goal: replace hindsight's "inject all memories every
turn" with RAG-style retrieval so context window stays flat as memories grow.

## Problem
- Hindsight injects ALL memories into every turn
- As memories grow, they crowd out actual conversation context
- Need: embed memories → store as vectors → retrieve top-K relevant per turn

## Options Evaluated

### 1. Letta (formerly MemGPT) — Berkeley research, 24k stars
- Full platform, not just a memory layer
- Memory blocks (core, archival, etc.)
- Self-hostable via Docker but heavy for single-user
- Verdict: overkill for personal companion bot

### 2. mem0 — purpose-built agent memory
- Handles extract → embed → store → retrieve pipeline
- Supports qdrant/pgvector/chroma backends
- Reference implementation in awesome-llm-apps repo uses:
  - mem0 + qdrant + ollama embeddings (nomic-embed-text)
- Pros: fully featured, actively maintained
- Cons: another dependency, needs vector store container, more latency
- Verdict: best for multi-user SaaS; heavier than needed here

### 3. ChromaDB — standalone vector DB
- Docker container, postgres backend option
- Millions of embeddings scale
- Verdict: single-purpose container is bloat for our stack

### 4. pgvector — postgres extension
- If we already have postgres, adds vector search with zero new infra
- HNSW/IVFFlat indexes, distance metrics
- Verdict: good if we already have postgres; we don't

### 5. sqlite-vec — recommended winner
- Pure python package, zero containers
- Single sqlite file (we already use sqlite for hindsight)
- Good to ~100k memories
- Perfect scale for single-user companion
- Aligns with user's no-bloat rule
- Verdict: leanest path, start here, migrate to mem0 only if limits hit

## Reference Implementation Found
- Repo: github.com/Shubhamsaboo/awesome-llm-apps
- Path: advanced_llm_apps/llm_apps_with_memory_tutorials/local_chatgpt_with_memory/
- Stack: mem0 + qdrant + ollama (nomic-embed-text) + streamlit
- Shows exact pattern: store message → embed → retrieve relevant → inject into context

## Implementation Details (July 24, 2026 — BUILT)

### Plugin: vector-memory
- Location: `~/.hermes/hermes-agent/plugins/memory/vector-memory/`
- Entry: `__init__.py:VectorMemoryProvider`
- Dependencies: `sqlite-vec`, `sentence-transformers` (installed via uv pip)

### Architecture
1. Extract memories from each turn (user + assistant messages)
2. Embed with `all-MiniLM-L6-v2` (384-dim, ~23MB, loads in ~1s, local, free)
3. Store in sqlite with `vec_f32(384)` column via sqlite-vec extension
4. On each turn: embed the query, search top-k most similar via cosine distance
5. Inject only those top-k memories into context

### Schema
```sql
CREATE TABLE memories (
    id INTEGER PRIMARY KEY,
    content TEXT NOT NULL,
    embedding vec_f32(384),
    metadata TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
```

### Query Pattern (working syntax)
```sql
SELECT content, metadata, vec_distance_cosine(embedding, vec_f32(?)) as dist
FROM memories ORDER BY dist LIMIT ?
```
- `distance` pseudo-column from MATCH syntax does NOT work with sqlite-vec — returns no rows silently
- Use `vec_distance_cosine(embedding, vec_f32(?))` instead
- Order by the distance column alias — sqlite-vec sorts by similarity automatically with ORDER BY
- Embeddings must be passed as JSON string `[1.0, 2.0, ...]`

### PITFALL: MATCH + distance pseudo-column fails silently
This pattern (found in early docs) returns empty results:
```sql
SELECT content, metadata, distance
FROM memories
WHERE embedding MATCH ?
ORDER BY distance
LIMIT ?
```
Use the explicit `vec_distance_cosine()` function instead.

### PITFALL: Hermes config.yaml is agent-protected
The agent CANNOT auto-edit `~/.hermes/config.yaml` to switch memory providers. The tool returns: "Refusing to write to Hermes config file: Agent cannot modify security-sensitive configuration."
User must edit `memory.provider` manually or use `hermes config` CLI.

### Key Configs
- `vector_memory_top_k` (default: 8) — memories retrieved per query
- `vector_memory_model` (default: `all-MiniLM-L6-v2`) — embedder model

### Testing Results
- 3 test memories stored and retrieved successfully
- Query "what music does Arriq like?" → correctly returned Nirvana memory as top result (distance: 0.416)
- Query "tell me about Arriqs projects" → returned BlueBubbles + homelab memories ranked
- Full roundtrip: initialize → add_memory → search → prefetch → shutdown, all working
- Embedding model loads from HuggingFace on first use (~23MB download)
- **MIGRATED 45 memories from hindsight into vector db (July 24, 2026)** — see "Migration Steps" below

### Migration Steps (from hindsight to vector-memory)
1. Build vector-memory plugin (see above)
2. Extract all memories from hindsight via `hindsight_recall` tool or direct DB query
3. Store them in vector-memory with `add_memory()` (each gets auto-embedded and stored)
4. Verify search works: `search("what music does Arriq like", top_k=3)`
5. Edit `~/.hermes/config.yaml`: change `memory.provider: hindsight` → `memory.provider: vector-memory`
6. `/restart` Hermes to activate
7. Confirm: only top-8 relevant memories appear in system prompt block per turn instead of all 80+

### Activation Config (config.yaml)
```yaml
memory:
  provider: vector-memory
  vector_memory_top_k: 8      # memories per query
  vector_memory_model: all-MiniLM-L6-v2
```

### Why These Choices
- sqlite-vec over mem0/Letta/pgvector: zero containers, single file, scales well for personal use
- Local embeddings over API: free, no network dependency, fast enough
- `all-MiniLM-L6-v2` over larger models: quality is sufficient, 23MB is tiny, loads instantly
- 384-dim is the sweet spot: good retrieval quality without massive storage overhead

## Embedding Model Options
- `all-MiniLM-L6-v2` (current): 384-dim, 23MB, fast, good quality
- `nomic-embed-text` via Ollama: larger but better for long documents
- `snowflake-arctic-embed`: newer, better performance
- API alternatives (OpenAI, etc.): faster but cost per embedding

## PITFALL: Old MemoryStore Still Gates Writes (Aug 2026)

When `memory.provider: vector-memory` is configured, the **old text-based `MemoryStore` is still loaded alongside the vector provider**. The vector provider only receives writes *after* the old store succeeds. This means:

- If the old store hits `memory_char_limit` (default 2200), it blocks the write
- The vector db never sees the new entry, even though vector memory is "unlimited"
- The `memory` tool returns: `"Memory at X/Y chars. Adding this entry would exceed the limit"`

**Root cause:** The `memory` tool's `memory_tool.py` instantiates `MemoryStore` directly, and `MemoryStore.add()` checks `_char_limit()` before writing. The vector provider's `on_memory_write()` hook only fires after `notify_memory_tool_write()` succeeds.

**Fix:** Bump `memory_char_limit` and `user_char_limit` in `~/.hermes/config.yaml` to values larger than your expected total memory size:

```yaml
memory:
  memory_char_limit: 500000
  user_char_limit: 250000
  provider: vector-memory
```

**Important:** The MemoryStore reads config at agent startup and caches the limit. After editing config.yaml, **restart the Hermes session** (`/restart`) for the new limits to take effect. The store does NOT re-read config mid-session.

**Verification:**
```bash
# Check config is saved
grep "memory_char_limit" ~/.hermes/config.yaml

# Check vector db is receiving writes
python3 -c "
import sqlite3, os
conn = sqlite3.connect(os.path.expanduser('~/.hermes/vector_memory.db'))
count = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
print(f'vector entries: {count}')
"
```

## Next Steps / Future Enhancements
1. **Periodic memory compression** — summarize old clusters into denser facts
2. **Memory tiering** — hot (injected), warm (searchable), cold (archived/summarized)
3. **LLM-based extraction** — use fast model to extract key facts from turns instead of storing raw text
4. **Hybrid retrieval** — combine vector similarity with recency and importance weighting
5. **Integration with hermes-model-router** — detect when a conversation needs memory vs. doesn't

## Ethical Boundaries (July 24, 2026 — BlueBubbles Session)

### Context
User asked for help with BlueBubbles iMessage server, specifically generating/finding Apple serial numbers to activate iMessage on a VM. The BlueBubbles docs describe this as "spoofing the required items to disguise your VM as a real Mac."

### What the agent CAN and CANNOT help with

**✅ Safe to help:**
- BlueBubbles server software setup (open source, legitimate)
- Docker compose configuration
- Networking, VPN, port forwarding
- systemd service setup
- General server management
- Explaining what BlueBubbles docs say (neutral information)

**❌ Will NOT help with:**
- Finding, scraping, or buying Apple serial numbers
- Generating fake Apple hardware IDs
- Walking through SMBIOS/serial spoofing steps
- Any step that involves tricking Apple's iMessage activation servers

### Why
- Apple's iMessage activation is tied to real hardware identifiers
- Using spoofed serials on non-Apple hardware violates Apple's Terms of Service
- Apple can and does ban Apple IDs for this
- The user is 15 years old — getting locked out of their Apple ID is disproportionate harm
- The docs themselves call this "spoofing" and "unofficial Mac" — they know what it is

### How to handle future similar requests
1. Acknowledge the user's goal neutrally
2. Clarify the boundary clearly but respectfully
3. Offer what you CAN help with (the safe parts)
4. Point to official docs if they want to proceed themselves
5. Never provide step-by-step guidance for the spoofing itself
6. Frame it as risk protection, not moralizing — "getting your Apple ID locked at 15 is not worth it"

### Alternative approaches to suggest
- Beeper Mini (paid, works on Android without spoofing)
- Using a real Mac (even old hardware) for legitimate serials
- Web-based chat bridges that don't touch Apple infrastructure
- Just using iPhone/Mac directly for iMessage

### Key phrase that works
"I'm not trying to be annoying twin, but I'm not helping you skirt Apple's auth systems. Getting your Apple ID locked at 15 is worse than whatever we're trying to build here."

This respects the user's autonomy (they can follow the docs themselves) while protecting them from preventable harm.
