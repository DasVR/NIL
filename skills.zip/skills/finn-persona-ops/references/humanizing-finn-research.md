# Humanizing Finn — Key Research Findings (2023-2026)

Condensed from `/home/das/hermes-plans/humanizing-finn-research-2026.md` (62KB, 1334 lines).
Full doc has complete Python code patterns for each technique.

## Key Papers
- **Sentipolis (2026)**: PAD (Pleasure-Arousal-Dominance) emotion model for stateful agents. Emotional amnesia across turns is a critical failure mode.
- **MemoryBank (AAAI 2024)**: Three-tier memory (sensory/short-term/long-term). Memories reinforced through repetition, fade through disuse.
- **Character-LLM (EMNLP 2023)**: "Experience upload" + "experience keeper" for persona consistency. Daily routine simulation.
- **SocialBench (2024)**: Evaluation framework for RP agent sociality — conversation management, relationship awareness, social cognition.
- **PuppetChat (2026)**: Reactions/tapbacks are complete conversational turns, not just acknowledgments.
- **Stanford Generative Agents (2023)**: Memory stream + reflection + planning architecture for life simulation.
- **CHI 2024 LTM paper**: Long-term memory increases self-disclosure depth. Incorrect memories severely damage trust.

## Novel Techniques NOT in Original Plan

### 1. Log-Normal Delay Distribution (HIGH priority)
Use `math.exp(random.gauss(math.log(base), sigma))` instead of `random.uniform()`. Real human response times follow log-normal — most replies fast (2-5s) with long tail of slow responses. Variance matters more than average.

### 2. Conversation State Machine (HIGH priority)
Explicit states: DORMANT → WARMING → ACTIVE → COOLING → FIZZLING → DORMANT. Each state has response modifiers (max_bubbles, energy, delay_mult). Subsumes existing conversation-end detection into unified framework.

### 3. PAD Emotion Model (HIGH priority)
Replace discrete mood labels with continuous Pleasure-Arousal-Dominance (0-1 each). Drifts toward time-of-day targets + external factors. Gradual adjustment (drift_rate=0.15) + random noise. Produces richer prompt context than "chill/hyped/tired".

### 4. Memory Salience Scoring (HIGH priority)
Score = 0.4*emotional_intensity + 0.3*recency_decay + 0.3*frequency. Selectively inject only relevant high-salience memories into prompt, not all memories.

### 5. Automated Post-Session Memory Extraction (HIGH priority)
After 30+ min gap, call ministral-3:8b to extract key memories from conversation. Include emotional_valence, emotional_intensity, topic_tags. Only extract things about the USER, not the agent.

### 6. Inside Joke Generation (HIGH priority)
Detect funny exchanges (both parties sent 💀/😭/lmao), store as inside jokes. 5% chance to reference later. "lmao still thinking about the thing with the..."

### 7. Vocabulary Drift (HIGH long-term priority)
Track user's word usage with Counter. After 5+ uses of informal word, adopt into Finn's active vocab. Friends' vocabularies converge — this is deeply human.

### 8. Unresolved Topic Callbacks (HIGH priority)
Track questions Finn asked that weren't answered. After 10-120 min, proactively circle back: "yo you never told me how that test went btw"

### 9. Vulnerability Moments (MEDIUM priority)
5% chance during ACTIVE state: inject "You're feeling a bit off today" context. Breaks the always-happy bot pattern.

### 10. Daily Reflection (MEDIUM priority)
Daily cron calls GLM-5.2 to generate 2-3 higher-level insights about the user from the day's memories. "Erick seems stressed about exams lately — I should be supportive"

### 11. BRB Interruptions (MEDIUM priority)
3% chance during ACTIVE conversation: send "brb sec", go quiet 3-15 min, come back with "ok back what'd i miss"

### 12. Gradual Sleep Wind-Down (MEDIUM priority)
Instead of hard 1am cutoff: 11pm = slower, midnight = very slow, 1am = asleep. Wake-up: 6:30am groggy → 7am mostly awake → 8am normal. Weekend shifts sleep_end to 10am.

## Architecture (from research synthesis)
```
INCOMING MSG → CONVERSATION STATE MACHINE → HUMANIZATION GATEWAY (sleep/life-event/no-response/reaction/delay checks) → PROMPT BUILDER (mood + state + memories + drift + routine + jokes) → LLM CALL (model router) → RESPONSE POST-PROCESSING (split ␤ + typing delays + memory extraction + state/mood update + vocab tracking + joke detection)
```

## Plugin Structure (recommended)
```
~/.hermes/plugins/humanize/
├── timing.py       # Log-normal delays, rhythm tracking, sleep factor
├── lifecycle.py    # Conversation state machine, topic tracking
├── mood.py         # PAD mood model, mood event manager
├── memory.py       # Salience scoring, extraction, recall selection
├── life_events.py  # Event scheduler, brb interruptions
├── reactions.py    # Contextual reaction selection
├── drift.py        # Vocabulary adoption, interest tracking
├── afterthought.py # Delayed afterthought messages
└── jokes.py        # Inside joke detection and reference
```

## Updated Priority Rankings (31 features across 4 tiers)
- Tier 1 (Quick Wins): log-normal delay, state machine, no-response mode, cron jitter, contextual reactions
- Tier 2 (Core): PAD mood, life events, memory extraction, memory salience, time-of-day, unresolved callbacks, inside jokes
- Tier 3 (Deep): afterthoughts, gradual sleep, daily routine, rhythm tracking, mood events, time-ref follow-ups, brb, vulnerability, daily reflection
- Tier 4 (Advanced): vocab drift, interest evolution, relationship phases, memory consolidation, topic threads, mood-memory linking, expertise variation, reaction chains, phantom typing, burst-then-pause