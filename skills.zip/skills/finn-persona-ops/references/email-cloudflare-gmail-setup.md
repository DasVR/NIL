# Discord Message Truncation Fix

**Problem**: Discord adapter hardcodes max_message_length=2000 at line ~7849 in ~/.hermes/hermes-agent/plugins/platforms/discord/adapter.py. Long messages get silently chopped off mid-sentence.

**Fix**: Change to 4000 (Discord supports up to 4000 for bots).

**Restart required**: /restart from Discord.

## Himalaya Email via Cloudflare + Gmail

**Architecture**: Cloudflare Email Routing forwards @dasdev.net to Gmail, then Gmail SMTP sends with custom domain as From. Avoids residential IP blacklisting.

**Setup**:
1. Cloudflare: Email → Email Routing → add hello@dasdev.net → user@gmail.com
2. Gmail: Generate app password at myaccount.google.com/apppasswords
3. GPG key needed for pass: error "WKD: no data" means no GPG key
4. Store password: pass init user@gmail.com; pass insert email/gmail-app-password
5. Himalaya config: IMAP to Gmail, SMTP to Gmail, folder aliases for [Gmail]/Sent Mail
6. Send: himalaya message send --account dasdev < raw_email.txt

**Pitfalls**:
- himalaya message send takes raw RFC822 on stdin, NOT --to flags
- Missing [Gmail]/Sent Mail alias causes duplicate sends on retry
- No GPG key = pass fails with WKD error
- Residential IP direct send gets blacklisted, always relay through Gmail
