# Advanced Hermes Setup — Feature Reference

Condensed reference of advanced Hermes Agent v0.18.0 features researched for Finn's phased upgrade.
Full plan lives at /home/das/hermes-plans/ADVANCED-SETUP-PLAN.md.

## MCP Servers (Native Client)
- Config: `mcp_servers:` block in config.yaml, each entry is command+args (stdio) or url (HTTP)
- Tools auto-discovered at startup, registered as `mcp_{server}_{tool}`
- Auto-injected into all platform toolsets
- Env filtering: only explicit `env:` vars passed to subprocess (no credential leakage)
- Requires: `pip install mcp`, Node.js for npx servers, uv for uvx servers
- GitHub server: `command: npx, args: [-y, @modelcontextprotocol/server-github], env: GITHUB_PERSONAL_ACCESS_TOKEN`
- Add Tool Search when MCP tools > 10% of context: `tools.tool_search.enabled: auto`

## Fallback Providers
- Config: `fallback_providers:` list in config.yaml, each entry has `provider` + `model`
- Triggers on: 429 rate limit, 529 overload, 503 service error, connection failures
- Credential pools (same-provider rotation) tried FIRST, then fallback providers
- Setup: `hermes fallback` interactive, or edit config.yaml directly

## Event Hooks
- Gateway hooks: `~/.hermes/hooks/<name>/HOOK.yaml` + `handler.py`
- Events: gateway:startup, session:start/end/reset, agent:start/step/end, command:*
- `handler.py` must have `async def handle(event_type, context)` or `def handle(...)`
- Errors caught and logged, never crash the agent
- BOOT.md pattern: startup checklist read by a gateway:startup hook

## Webhooks
- Enable: `platforms.webhook.enabled: true` in config.yaml, set port + secret
- Create: `hermes webhook subscribe <name> --prompt "..." --events "..." --deliver discord`
- Prompt templates support `{dot.notation}` for nested payload fields
- `--deliver-only` flag = direct delivery, no LLM, zero token cost
- HMAC-SHA256 signature validation on every POST

## Persistent Goals (/goal)
- Standing objective that survives across turns
- Judge model checks after each turn: "done" or "continue"
- Default budget: 20 continuation turns
- `/goal draft <text>` — auto-expands to full completion contract
- `/subgoal <text>` — add criteria mid-loop
- `/goal wait <pid>` — park on background process, auto-resume on exit
- Works on CLI and all gateway platforms

## Mixture of Agents (MoA)
- Virtual provider: reference models run first, aggregator writes response
- Config: `moa.presets.<name>` with reference_models + aggregator
- Usage: `/model <preset> --provider moa` or `/moa <prompt>` (one-shot)
- Reference models run WITHOUT tool schemas (cheaper, no strict-provider rejections)

## Tool Search (Progressive Disclosure)
- Replaces MCP/plugin tool schemas with 3 bridge tools (~300 tokens)
- Bridge: `tool_search(query)`, `tool_describe(name)`, `tool_call(name, args)`
- `auto` mode: activates when deferrable tools > 10% of context
- Config: `tools.tool_search.enabled: auto, threshold_pct: 10`

## Deliverable Mode
- Gateway scans agent responses for absolute file paths
- Supported: .png .jpg .pdf .csv .xlsx .mp3 .mp4 .zip etc.
- Paths in code blocks/backticks are ignored (code samples not mutilated)
- Mention absolute path in response → gateway uploads natively to chat
- No `MEDIA:` tag needed from agent side — gateway auto-detects

## Kanban (Multi-Agent Board)
- Durable SQLite task board at ~/.hermes/kanban.db
- Tasks: triage → todo → ready → running → blocked → done → archived
- Links: parent → child dependencies, dispatcher promotes when parents done
- Comments: inter-agent protocol, workers read full thread on spawn
- Workspaces: scratch (ephemeral), dir:<path> (persistent), worktree (git)
- Dispatcher runs in gateway, auto-reclaims stale/crashed workers
- vs delegate_task: Kanban = durable queue; delegation = RPC call

## Multi-Profile
- Each profile = separate ~/.hermes/profiles/<name>/ with own config, memory, sessions
- `hermes profile create <name> --clone` copies config+skills+SOUL
- Auto-creates command alias at ~/.local/bin/<name>
- Each profile gets own systemd service: hermes-gateway-<name>.service
- Gateway multiplexing option: single process serves all profiles (opt-in)

## Gateway Hardening
- Linger: `sudo loginctl enable-linger $USER` (survive SSH logout)
- systemd: `hermes gateway install` → auto-restart on crash
- Verify: `systemctl --user status hermes-gateway`
- Logs: `~/.hermes/logs/gateway.log`

## Cron Advanced Patterns
- Context chaining: `--context-from <job-id>` injects upstream job output
- Script-only: `--script <path> --no-agent` (zero tokens, empty stdout = silent)
- Workdir: `--workdir /path` runs job in specific directory with AGENTS.md loaded
- Model override: `--model '{"model":"...","provider":"..."}'`
- Attach-to-session: `--attach-to-session` makes replies continuable