# Discord Message Cutoff Fix (August 13 2026)

## Problem
Long assistant responses to Discord fail with:
```
HTTPException: 400 Bad Request (error code: 50035): Invalid Form Body
In content: Must be 2000 or fewer in length.
```
Also: responses feel cut off, user says "you keep fucking getting cutoff".

## Root Causes (Three Things Stacking)

1. **No `model.max_tokens`** — Responses grow past what the model/router respects as a hard ceiling, so content is already truncated before it reaches Discord.
2. **`humanize` plugin still enabled** — Even with delays tuned to zero, it fires `pre_llm_call_memory` hooks and stores assistant messages as memories (known bug). Adds latency and noise.
3. **Text-batch split delay too long** — `DiscordAdapter._text_batch_split_delay_seconds` defaults to 2.0s. When a response chunk is near the split threshold, it waits 2 seconds. If another chunk arrives in that window, the prior flush task gets cancelled and the timer resets. Chunks get dropped or arrive very late.

## Fixes Applied (August 13 2026)

### Config (`~/.hermes/config.yaml`)
- Added `model.max_tokens: 4096`
- Tuned `humanize:` block: kept plugin enabled, but turned off `auto_memory_extraction` and `episodic_memory` temporarily while debugging. User later corrected: "those two are needed, patch dont remove". Restored both to `true`. The actual fix was the Discord adapter split delay, not disabling memory features.

### Discord Adapter (`plugins/platforms/discord/adapter.py`)
- Default `_text_batch_split_delay_seconds` changed from `2.0` → `0.3`
  (env var `HERMES_DISCORD_TEXT_BATCH_SPLIT_DELAY_SECONDS` still overrides it)

### What NOT to do
- Do NOT bump `MAX_MESSAGE_LENGTH` to 4000. Discord's API enforces 2000 for this bot. The July 2024 "patch to 4000" advice is outdated and will cause immediate 400s.
- Do NOT disable `humanize` memory features as a debugging shortcut. If they have a bug, patch the actual code in `~/.hermes/plugins/humanize/__init__.py` instead.
- Do NOT rely on `/restart` in Discord — it only clears conversation state, not plugin code. The gateway needs a full `systemctl --user restart hermes-gateway` from an external shell.

## Verification
After restart, send a message that forces a >2000 char reply. The adapter should split into ≤2000 char chunks and deliver them all without chunks getting eaten by the batch timer.

## Files touched
- `~/.hermes/config.yaml`
- `~/.hermes/hermes-agent/plugins/platforms/discord/adapter.py`
