# Voice Agent Webhook Integration

Pattern for wiring a Discord voice bot to Hermes webhooks + Ollama Cloud for fast TTS replies with background delegation.

## Architecture

```
Discord VC → Whisper STT → bridge_server.py (port 8765)
                                    ├── Ollama Cloud (nemotron-3-nano:30b) → TTS reply (0.7s)
                                    └── Hermes webhook (port 8644) → delegate_task agents
```

## Key Components

### 1. Bridge Server (FastAPI)

- Receives `{text, user}` from Discord bot at `/ask`
- Queries Ollama Cloud for fast voice reply
- Fire-and-forgets to Hermes webhook for delegation

```python
import hmac, hashlib

body = json.dumps({"text": text, "user": user}).encode()
sig = "sha256=" + hmac.new(
    HERMES_WEBHOOK_SECRET.encode(), body, hashlib.sha256
).hexdigest()
await client.post(
    HERMES_WEBHOOK_URL,
    content=body,
    headers={"Content-Type": "application/json", "X-Hub-Signature-256": sig},
)
```

> ⚠️ **Critical:** The HMAC signature must be computed from the raw body bytes. Sending the raw secret as the signature header will fail with `{"error": "Invalid signature"}`.

### 2. Ollama Cloud (not local Ollama)

User prefers Ollama Cloud for voice — faster and smarter than local models.

- Endpoint: `https://ollama.com/v1/chat/completions`
- Auth: `Authorization: Bearer <OLLAMA_API_KEY>`
- Fastest model for voice: `nemotron-3-nano:30b` (0.7s per reply)
- Disable reasoning for direct replies: `reasoning_effort: "none"`

```python
await client.post(
    "https://ollama.com/v1/chat/completions",
    headers={"Authorization": f"Bearer {OLLAMA_API_KEY}"},
    json={
        "model": "nemotron-3-nano:30b",
        "messages": [{"role": "user", "content": text}],
        "max_tokens": 60,
        "temperature": 0.8,
        "reasoning_effort": "none",
    },
)
```

### 3. Hermes Webhook (Delegation Path)

Create a webhook subscription that receives voice input and can spawn `delegate_task` agents:

```bash
hermes webhook subscribe voice \
  --prompt "Voice input from Discord VC: {text}. User: {user}. Respond naturally as Finn..."
```

### 4. Discord Bot

Uses `py-cord[voice]` for voice channel connectivity:
- `!join` / `!leave` commands
- `WaveSink` for audio capture
- `faster-whisper` for STT
- `pyttsx3` for offline TTS

## Pitfalls

### HMAC signature must be computed, not passed raw
The Hermes webhook adapter expects `sha256=<hex(hmac(secret, body))>`. Passing the raw secret string as the signature header always fails.

### Reasoning models leak chain-of-thought
Most Ollama Cloud models default to reasoning mode. The response goes into `message.reasoning` instead of `message.content`. Set `reasoning_effort: "none"` for direct voice replies.

### Ollama Cloud ≠ local Ollama
Local Ollama (`http://localhost:11434`) has different models than Ollama Cloud. Don't assume a model available locally works on cloud, or vice versa.

### Gateway restart required after webhook config changes
`hermes gateway restart` is blocked from inside the gateway process. Use `systemctl --user restart hermes-gateway` from a separate shell.

## Model Comparison (voice latency)

| Model | Latency | Notes |
|-------|---------|-------|
| `nemotron-3-nano:30b` | ~0.7s | Fastest, natural replies |
| `kimi-k2.6` | ~0.9s | Good quality, slightly slower |
| `deepseek-v4-flash:preview` | ~0.8s | Good but occasionally verbose |
| `minimax-m2.7` | ~1.3s | Slower, more formal tone |
| `gpt-oss:20b` | ~1.1s | Smaller but not faster |

All tested with `reasoning_effort: "none"`, `max_tokens: 30`, warm connection.

## Files

- `bot.py` — Discord bot (voice connection, commands)
- `bridge_server.py` — FastAPI bridge (ollama + hermes)
- `stt.py` — Whisper transcription
- `tts.py` — pyttsx3 speech synthesis
- `audio_handler.py` — WaveSink capture + playback
