# Webhook Setup — Quick Pattern

Enable external services (GitHub, CI/CD, monitoring) to trigger Finn agent runs.

## Enable Platform

```bash
hermes config set platforms.webhook.enabled true
hermes config set platforms.webhook.extra.host "0.0.0.0"
hermes config set platforms.webhook.extra.port 8644
hermes config set platforms.webhook.extra.secret "$(openssl rand -hex 32)"
```

Verify it's not already enabled:
```bash
hermes webhook list    # should show "not enabled" or existing subs
```

## Restart Gateway

**Critical:** webhooks won't listen until the gateway restarts. But restarting from inside the gateway process is blocked. Run from a separate shell:

```bash
systemctl --user restart hermes-gateway
```

Then verify the listener:
```bash
curl http://localhost:8644/health
```

## Create Subscriptions

GitHub issues → Finn triage:
```bash
hermes webhook subscribe github-issues \
  --events "issues" \
  --prompt "New GitHub issue #{issue.number}: {issue.title}\nAction: {action}\nAuthor: {issue.user.login}\nBody:\n{issue.body}\n\nPlease triage this issue." \
  --deliver origin
```

GitHub PRs → Finn code review:
```bash
hermes webhook subscribe github-prs \
  --events "pull_request" \
  --prompt "PR #{pull_request.number} {action}: {pull_request.title}\nBy: {pull_request.user.login}\nBranch: {pull_request.head.ref}\n\n{pull_request.body}" \
  --skills "github-code-review" \
  --deliver origin
```

`--deliver origin` sends the response back to where the webhook came from (Discord, if that's where Finn lives).

## Configure GitHub

In each repo → Settings → Webhooks → Add webhook:
- Payload URL: `http://YOUR_SERVER_IP:8644/webhooks/github-issues`
- Content type: `application/json`
- Secret: the secret printed when you created the subscription
- Events: Issues / Pull requests (match what you subscribed to)

If the server is behind NAT, use a Cloudflare Tunnel or ngrok to expose port 8644.

## Pitfalls

### Gateway restart is required but blocked internally
`hermes gateway restart` from inside the gateway process fails with a safety block. Always use `systemctl --user restart hermes-gateway` from a separate terminal session.

### No agent delivery for simple forwarding
If you want zero LLM cost (just forward the webhook payload), use `--deliver-only`. But this requires a real delivery target like telegram or discord — `log` is rejected.

### Subscriptions hot-reload
Webhook subscriptions are written to `~/.hermes/webhook_subscriptions.json` and the adapter hot-reloads on each request (mtime-gated). No gateway restart needed after creating new subscriptions.

### Port conflicts
Port 8644 is the default. If something else uses it, change in config before enabling.
