# MCP Server Setup — Quick Pattern

Fast path for adding MCP servers to Finn (Hermes Agent).

## Prerequisites

```bash
# Check what's available
which npx && npx --version    # needed for npm-based servers
which uvx && uvx --version    # needed for python-based servers
python3 -c "import mcp"       # verify mcp package installed
```

Install/update the SDK:
```bash
pip install --break-system-packages --upgrade mcp
```

## Add Servers (Non-Interactive)

The `hermes mcp add` command has an interactive confirmation prompt. Pipe `echo "y"` to auto-confirm:

```bash
echo "y" | hermes mcp add github \
  --command "npx" \
  --args "-y" "@modelcontextprotocol/server-github" \
  --env "GITHUB_PERSONAL_ACCESS_TOKEN=$(gh auth token)" \
  --timeout 60
```

Common servers to add:

| Server | Command | Tools | Use For |
|--------|---------|-------|---------|
| **GitHub** | `npx -y @modelcontextprotocol/server-github` | 26 | Issues, PRs, repos, search |
| **Filesystem** | `npx -y @modelcontextprotocol/server-filesystem /home/das/projects` | 14 | Read/write/edit files |
| **Time** | `uvx mcp-server-time` | ~3 | Timezone-aware queries |

## Verify

```bash
hermes mcp list          # show all configured servers
hermes mcp test NAME     # test a specific connection
```

## Pitfalls

### "MCP 2.0.0 breaks uvx-based servers"
`mcp-server-time` (and some other uvx servers) fail with `ImportError: cannot import name 'McpError'` after upgrading `mcp` to 2.x. The server package was built against mcp 1.x. Solutions:
1. Skip time server for now (use built-in `datetime` if needed)
2. Or downgrade: `pip install --break-system-packages 'mcp<2.0'`
3. Or find a fork/updated version of the server

### Gateway restart blocked from inside
After adding MCP servers, a gateway restart is needed for tools to appear. But `hermes gateway restart` is blocked when running inside the gateway process. Use:
```bash
systemctl --user restart hermes-gateway   # from a separate shell
```

### No hot-reload
Adding/removing MCP servers requires a full gateway restart. No live reload.

### Token source
`gh auth token` is the fastest way to get a working GitHub token for the GitHub MCP server. It uses the `gh` CLI's existing OAuth session. No need to create a new PAT manually.
