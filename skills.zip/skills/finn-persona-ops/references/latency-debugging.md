# Latency Debugging — Ollama Cloud Models (July 13 2026)

## Root Cause: Context Size, Not Model Speed

The #1 latency factor is **input token count**, not model size or speed.

### Data (from agent.log analysis, July 13 2026)

| Model | Avg Input Tokens | Avg Latency | Fast (<10s) | Slow (≥10s) |
|-------|-----------------|-------------|-------------|-------------|
| glm-5.2 | 147,292 | 7.6s | 1,399 calls (avg 140K tokens) | 290 calls (avg 183K tokens) |
| ministral-3:8b | 187,793 | 13.1s | 134 calls (avg 185K tokens) | 61 calls (avg 194K tokens) |
| nemotron-3-super | 19,077 | 17.5s | 1 call | 2 calls |

### Key Insight
- Slow calls correlate with HIGHER input token counts across ALL models
- ministral-3:8b is hit hardest because the model router sends it simple messages BUT the full conversation history (200K+ tokens) is still attached
- ministral-3:8b has a smaller context window — some calls exceed it entirely: `HTTP 400: "prompt too long; exceeded max context length by 31652 tokens"`
- Even glm-5.2 slows down significantly above 180K tokens

### How to Analyze Latency
```bash
# Extract all API call latencies from logs
grep "API call.*in=" ~/.hermes/logs/agent.log | python3 -c "
import sys, re
from collections import defaultdict

by_model = defaultdict(list)
for line in sys.stdin:
    m = re.search(r'model=(\S+).*in=(\d+)\s+out=(\d+)\s+total=(\d+)\s+latency=([\d.]+)s', line)
    if m:
        model, inp, out, total, lat = m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4)), float(m.group(5))
        by_model[model].append((inp, lat))

for model, calls in by_model.items():
    lats = [c[1] for c in calls]
    inps = [c[0] for c in calls]
    fast = [c for c in calls if c[1] < 10]
    slow = [c for c in calls if c[1] >= 10]
    print(f'{model}: avg={sum(lats)/len(lats):.1f}s, avg_input={sum(inps)//len(inps)}, fast={len(fast)}, slow={len(slow)}')
"
```

### Fixes Applied (July 13 2026)
1. **Auto session reset**: `session_reset.mode=both, idle_minutes=180, at_hour=4` — resets after 3h idle OR at 4am daily. Hindsight memory preserves all important facts across resets.
2. **More aggressive compression**: `threshold=0.50` (was 0.80), `target_ratio=0.15` (was 0.20), `protect_last_n=15` (was 20). Compresses sooner and more aggressively.
3. **Context-aware model routing**: Patched `hermes-model-router/__init__.py` with `_get_context_size()` — if context >100K tokens, forces glm-5.2 instead of routing to ministral (which chokes on 200K+ token contexts).
4. **Start new session**: `/new` in Discord drops context from 220K → ~5K tokens. Instant 10x speedup.
5. **Tool router**: The `hermes-tool-router` plugin narrows tool schemas, which reduces token count per call. Ensure it's enabled and configured with `floor_toolsets` minimal.

### Config Changes Applied
```python
# session_reset (in config.yaml)
config['session_reset'] = {'mode': 'both', 'idle_minutes': 180, 'at_hour': 4}

# compression (in config.yaml)
config['compression'] = {
    'enabled': True, 'threshold': 0.50, 'target_ratio': 0.15,
    'protect_last_n': 15, 'protect_first_n': 3,
}
```

### Model Router Patch (hermes-model-router/__init__.py)
Added `_get_context_size(agent)` function that estimates context size from conversation history length. In `_route_model()`, if `context_size > 100000`, forces main model (glm-5.2) regardless of message simplicity. This prevents ministral-3:8b from receiving 200K+ token contexts that cause 28-42s latency and HTTP 400 errors.

### Model Router Config
Located at `~/.hermes/plugins/hermes-model-router/config.yaml`:
- `fast_model: "ministral-3:8b"` — routes simple messages here
- `short_message_threshold: 80` — messages < 80 chars use fast model
- `escalate_keywords` — list of keywords that force main model (glm-5.2)
- `simple_patterns` — patterns that are simple enough for fast model

### Model Speed Benchmarks (comprehensive, July 13 2026)
Tested via `curl -s -H "Authorization: Bearer $OLLAMA_API_KEY" https://ollama.com/v1/chat/completions` across 5 prompt types (greeting, sentiment, persona, tool-use, longer context):

| Model | Speed Range | Consistency | Quality | Recommendation |
|-------|------------|-------------|---------|----------------|
| ministral-3:3b | 720-1822ms | Consistent | OK | ✅ Best classifier |
| gemma3:4b | 1002-1990ms | Consistent | GOOD | ✅ **Best fast chat model** |
| ministral-3:8b | 754-2156ms | Consistent | OK | ✅ Memory extraction |
| ministral-3:14b | 847-1851ms | Consistent | GOOD | ✅ Better quality alt |
| gpt-oss:20b | 1068-1775ms | Consistent | EMPTY ❌ | ❌ Unreliable |
| gemini-3-flash-preview | 1646-6390ms | Inconsistent | EMPTY ❌ | ❌ Unreliable |
| deepseek-v4-flash | 1032-6868ms | Inconsistent | OK when works | ⚠️ Too inconsistent |
| glm-5.2 | 1058-3004ms | Consistent | BEST | ✅ Main model |

**KEY FINDING**: Previous test said "gemma3:4b too slow" — that was WRONG. Comprehensive benchmarks show gemma3:4b is the hidden gem: consistent 1.1-2.0s with good Finn persona quality. Recommended switching fast_model from ministral-3:8b to gemma3:4b.

See `finn-humanize-plugin/references/ollama-cloud-model-benchmarks.md` for full per-test breakdown.

These are raw API latencies. Real conversation latency = API latency + context processing time (which scales with input tokens).