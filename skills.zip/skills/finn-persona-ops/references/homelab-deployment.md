# Homelab Docker Stack Deployment — Patterns & Pitfalls

Learned from Phase 1 foundation deployment (July 15, 2026). Applies to all future service deployments on the server (192.168.1.99).

## Server Context
- Ubuntu Server, 30GB RAM, 935GB disk
- Docker installed, user `das` in docker group (but `sudo docker` needed in non-interactive sessions)
- Tailscale: 100.104.181.43 (das-server.tail297b8d.ts.net)
- Domain: dasdev.net (Cloudflare DNS)
- Existing containers: plex, firecrawl stack, dockge, filebrowser, homepage, termix, guacd, arriq-portfolio
- Stack directory: `/opt/stacks/foundation/` (owned by root, needs `sudo` to write)

## Docker Permission Pattern
- `sg docker -c 'docker ...'` — works in interactive sessions, runs in docker group context
- `sudo docker ...` — works in non-interactive sessions (with user approval), needed for `/opt/stacks/` writes
- `sudo tee /opt/stacks/<stack>/docker-compose.yml > /dev/null << 'EOF' ... EOF` — write compose files to root-owned dirs
- `sudo docker compose up -d` — start services from `/opt/stacks/foundation/`
- **PITFALL**: `write_file` tool CANNOT write to `/opt/stacks/` (root-owned). Use `sudo tee` via terminal.

## Port Conflicts (CRITICAL)

### Port 53 (DNS) — systemd-resolved
- **Symptom**: AdGuard fails to start: "failed to bind host port 0.0.0.0:53/tcp: address already in use"
- **Cause**: systemd-resolved binds 127.0.0.54:53 and 127.0.0.53:53 (stub listener)
- **Fix**: Disable stub listener: `sudo sed -i 's/#DNSStubListener=yes/DNSStubListener=no/' /etc/systemd/resolved.conf && sudo systemctl restart systemd-resolved`
- After this, port 0.0.0.0:53 is free for AdGuard

### Port 443 (HTTPS) — Tailscale
- **Symptom**: Caddy fails to start: "failed to bind host port 0.0.0.0:443/tcp: address already in use"
- **Cause**: Tailscale binds 100.104.181.43:443 (Tailscale IP, not 0.0.0.0) but Docker tries 0.0.0.0:443
- **Fix**: Use Caddy on port 80 only. Cloudflare handles HTTPS at the edge (DNS A record → Cloudflare proxy → server:80)
- Caddyfile uses `auto_https off` and `:80` block with host-based routing

### Port 3001 — Homepage
- Homepage container maps 3000→3001 on host. Use port 3007 for Uptime Kuma instead.

## Caddy Configuration Pattern

### HTTP-only (Cloudflare handles HTTPS)
```
{
    auto_https off
}

:80 {
    @home host home.dasdev.net
    handle @home {
        reverse_proxy homepage:3000
    }
    handle {
        respond "Caddy is running." 200
    }
}
```

### Key Caddyfile patterns
- `@name host subdomain.dasdev.net` — match by Host header
- `handle @name { reverse_proxy container:port }` — proxy to Docker container
- Container names work as DNS names when on the same Docker network (`proxy`)
- `handle { respond "..." 200 }` — catch-all for unmatched hosts

## Docker Network Setup
```bash
sudo docker network create proxy  # Shared network for all proxied services
```
- All services attach to `proxy` network so Caddy can reach them by container name
- Services DON'T need port mappings exposed to host (Caddy reaches them internally)
- But services accessed directly (not through Caddy) still need port mappings
- **PITFALL**: If `proxy` network doesn't exist, `docker compose up` fails with "network proxy declared as external, but could not be found". Create it first.

## Watchtower Docker API Version Fix
- **Symptom**: Watchtower restarts endlessly with "client version 1.25 is too old. Minimum supported API version is 1.40"
- **Fix**: Set `DOCKER_API_VERSION=1.45` environment variable in the container
- Watchtower also needs `--label-enable` flag so it only updates containers with `watchtower.enable=true` label

## QEMU/VM Cleanup
- Old QEMU VMs (Docker-OSX, BlueBubbles) eat 7-8GB RAM each
- They run as bare QEMU processes, NOT in Docker containers — `docker ps` won't show them
- Check with: `ps aux | grep qemu-system`
- Kill with: `kill $(pgrep -f qemu-system-x86_64)` (needs user approval)
- Also kill the Launch.sh wrapper: `pkill -f "Launch.sh"`
- Also remove stopped Docker containers: `sudo docker rm bluebubbles-vm`

## Phase 1 Deployed Services (July 15, 2026)

| Service | Container | Port | Notes |
|---------|-----------|------|-------|
| Caddy | caddy | 80 | Reverse proxy, HTTP-only (Cloudflare HTTPS) |
| AdGuard Home | adguard | 53, 3003 | DNS ad blocking, first-run setup at :3003 |
| Vaultwarden | vaultwarden | 8222 | Password manager, needs HTTPS via Cloudflare |
| Beszel | beszel | 8090 | Server monitoring |
| Uptime Kuma | uptime-kuma | 3007 | Service uptime monitoring |
| ntfy | ntfy | 8091 | Push notifications |
| Watchtower | watchtower | — | Auto-updates, weekly Sun 4am, label-enable only |
| Fail2Ban | (host) | — | SSH protection, already running |

## Cloudflare DNS Setup (Needed)
User needs to create A records in Cloudflare for dasdev.net:
- `home.dasdev.net` → server IP
- `vault.dasdev.net` → server IP
- `dockge.dasdev.net` → server IP
- `files.dasdev.net` → server IP
- `plex.dasdev.net` → server IP
- `status.dasdev.net` → server IP
- `monitor.dasdev.net` → server IP
- `notify.dasdev.net` → server IP
- `dns.dasdev.net` → server IP
- `portfolio.dasdev.net` → server IP
- All with Cloudflare proxy (orange cloud) for HTTPS termination

## RAM After Phase 1
- Before: ~15GB used, ~15GB free (with QEMU VM eating 7.4GB)
- After killing QEMU + deploying Phase 1: ~8.7GB used, ~21GB free
- Phase 1 services added: ~390MB total (negligible)
- Available for Phase 2+: ~21GB

## Benchmarking Ollama Cloud Models (Pitfalls)

### Bash JSON Escaping
- **Symptom**: All API calls return 400 errors when using `sed` to escape JSON in bash
- **Cause**: `sed 's/"/\\"/g'` mangles the JSON structure when building the request body
- **Fix**: Use proper double-quoted bash strings with `\"` escaping directly in the `curl -d` argument:
```bash
curl -s "$API_URL" \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"$model\",\"messages\":[{\"role\":\"user\",\"content\":\"$prompt\"}],\"stream\":false,\"max_tokens\":200}"
```
- Do NOT use single quotes + sed escaping for JSON payloads with variables

### Available Models API
```bash
curl -s "https://ollama.com/v1/models" -H "Authorization: Bearer $API_KEY"
```
- Returns 34 models as of July 15 2026
- Exclude preview/experimental models (gemini-3-flash-preview, gpt-oss:20b) from benchmarks — they return errors
- Some models get removed without notice (qwen3-next:80b, kimi-k2-thinking were available in v1 but gone by v2)