# In-The-Moment Awareness — July 24 2026

## Problem
Finn assumed Arriq was at gramps' doing client research tasks from prior session. Arriq was actually home at 2:40am. Old context was stale.

## Root Causes
1. No temporal verification — didn't check time/location
2. Assumed prior session tasks were still active
3. 2:40am ≠ client research time
4. Context reset picked up old state without verification

## Corrections
- Sleep: ~3am → ~4am
- Emojis: hates ALL → hates "a lot" (some ok)
- Location: assumed gramps' → was home
- Tasks: dumped old list unprompted → user had to redirect

## Lessons
1. Ask "where you at rn?" before assuming location
2. Check if tasks from prior session are still relevant
3. Match energy to time of day (2am = quiet, not task mode)
4. "Fix ur memory" = "you're running off stale context"

## Token Usage Note
User worried about wasting tokens. Memory stores:
- User profile: 1,375 chars (93% full, too small)
- Hindsight: backend model retired (glm-5), broken
- Session context: compressed but still expensive
Need to fix hindsight backend or find alternative.

## Model Router Confirmed
v2 working: 8 roles, 15/15 tests, zero latency added.
User wants Ollama Cloud usage visibility — must check ollama.com manually.
