# Hindsight Local Embedded Setup (Finn Persona)

## Packages
- `hindsight-client` (0.8.4) — API client, installed via uv
- `hindsight-embed` (0.8.4) — local daemon manager, installed via uv
- Install: `uv pip install --python ./venv/bin/python "hindsight-client>=0.6.1" "hindsight-embed"`

## Config File: ~/.hermes/hindsight/config.json
```json
{
  "mode": "local_embedded",
  "bank_id": "finn",
  "bank_id_template": "finn-{profile}",
  "recall_budget": "high",
  "auto_recall": true,
  "auto_retain": true,
  "retain_every_n_turns": 1,
  "memory_mode": "hybrid",
  "llm_provider": "openai_compatible",
  "llm_base_url": "https://ollama.com/v1",
  "llm_model": "glm-4-flash",
  "recall_types": "observation,world,experience"
}
```

## Env Vars (in ~/.hermes/.env)
- `HINDSIGHT_LLM_API_KEY` — copied from `OLLAMA_API_KEY` (same key, used for memory extraction LLM)
- `HINDSIGHT_MODE` — optional override; config.json `mode` takes precedence

## Config: ~/.hermes/config.yaml
- `memory.provider: hindsight` (set via `hermes config set memory.provider hindsight`)

## Critical Patches (plugins/memory/hindsight/__init__.py)

### Patch 1: `_check_local_runtime()` import fix (line ~127)

`_check_local_runtime()` tries `importlib.import_module("hindsight")` which fails — there is no `hindsight` pip package (the pypi `hindsight==0.1.7` is an unrelated broken package from 2016 that fails with `use_2to3 is invalid`). The `hindsight_embed` package provides the daemon manager, and `hindsight_client` provides the API client, but neither provides a top-level `hindsight` module.

**Patch**: fall back to `importlib.import_module("hindsight_client")` if `hindsight` raises ImportError:

```python
# Before:
try:
    importlib.import_module("hindsight")
    importlib.import_module("hindsight_embed.daemon_embed_manager")
    return True, None
except Exception as exc:
    return False, str(exc)

# After:
try:
    try:
        importlib.import_module("hindsight")
    except ImportError:
        importlib.import_module("hindsight_client")
    importlib.import_module("hindsight_embed.daemon_embed_manager")
    return True, None
except Exception as exc:
    return False, str(exc)
```

### Patch 2: `HindsightEmbedded` → `DaemonEmbedManager` + `Hindsight` client (line ~1034)

The `_get_client()` method for `local_embedded` mode tries `from hindsight import HindsightEmbedded` — this class does not exist in ANY pip package (`hindsight`, `hindsight-client`, `hindsight-embed`, `hindsight-api` all don't have it). `HindsightEmbedded` was part of the full hindsight application (not pip-installable — the github repo has a flat layout that breaks setuptools).

**Patch**: replaced the `HindsightEmbedded` import + construction with `DaemonEmbedManager.ensure_running()` + `hindsight_client.Hindsight` HTTP client pointed at the local daemon:

```python
# Before:
from hindsight import HindsightEmbedded
HindsightEmbedded.__del__ = lambda self: None
kwargs = dict(profile=..., llm_provider=..., llm_api_key=..., llm_model=..., ...)
self._client = HindsightEmbedded(**kwargs)

# After:
from hindsight_client import Hindsight as _HindsightClient
from hindsight_embed.daemon_embed_manager import DaemonEmbedManager
_dem = DaemonEmbedManager()
_profile_name = self._config.get("profile", "hermes")
_llm_provider = self._config.get("llm_provider", "")
if _llm_provider in {"openai_compatible", "openrouter"}:
    _llm_provider = "openai"
_daemon_config = {
    "HINDSIGHT_LLM_API_KEY": (... or "") or "",
    "HINDSIGHT_LLM_PROVIDER": _llm_provider,
    "HINDSIGHT_LLM_MODEL": self._config.get("llm_model", "") or "",
}
if self._llm_base_url:
    _daemon_config["HINDSIGHT_LLM_BASE_URL"] = self._llm_base_url
_dem.ensure_running(_daemon_config, _profile_name)
_local_url = _dem.get_url(_profile_name) or "http://localhost:8888"
self._client = _HindsightClient(base_url=_local_url, timeout=float(self._timeout or _DEFAULT_TIMEOUT))
```

### Patch 3: `hindsight-api` binary installation

The `DaemonEmbedManager._find_api_command()` looks for a `hindsight-api` binary in the venv's scripts dir. Without it, it falls back to `uvx hindsight-api@<version>` which downloads ~2.5GB of CUDA/torch deps every run. To avoid this, install `hindsight-api` directly into the venv:

```bash
uv pip install --python /home/das/.hermes/hermes-agent/venv/bin/python "hindsight-api"
```

This installs the `hindsight-api` binary at `venv/bin/hindsight-api` plus all heavy deps (torch, numpy, pg0-embedded, etc) permanently in the venv (~2.5GB disk). The daemon manager finds the binary and starts the API server locally.

### Re-applying Patches After hermes-agent Update
If the repo updates and overwrites `plugins/memory/hindsight/__init__.py`:
1. Re-apply Patch 1 at line ~135 (the `_check_local_runtime` function)
2. Re-apply Patch 2 at line ~1034 (the `_get_client` method, local_embedded branch)
3. Verify `hindsight-api` binary still exists at `venv/bin/hindsight-api` — if not, reinstall per Patch 3

## Diagnosis Steps
1. Check `~/.hindsight/` dir exists (created on first daemon start)
2. Check `~/.hermes/logs/hindsight-embed.log` for daemon logs
3. If both empty/missing, `is_available()` returned False
4. Test imports: `python -c "import hindsight_client; import hindsight_embed.daemon_embed_manager"`
5. If imports work but hindsight not activating, check the patch wasn't reverted

## Daemon Lifecycle
- Auto-starts on first message after gateway restart
- Auto-stops after 5 min idle (HINDSIGHT_IDLE_TIMEOUT, default 300s)
- Built-in PostgreSQL (no external DB needed)
- Web UI: `hindsight-embed -p hermes ui start`

## Verification After Restart

### Primary: Direct Python Test (most reliable)
The gateway log may NOT show "Memory provider 'hindsight' activated" even when the provider is working correctly. Use this direct test instead:
```bash
~/.hermes/hermes-agent/venv/bin/python -c "
import sys, os
sys.path.insert(0, '/home/das/.hermes/hermes-agent')
os.environ['HERMES_HOME'] = '/home/das/.hermes'
from plugins.memory import load_memory_provider
mp = load_memory_provider('hindsight')
if mp and mp.is_available():
    mp.initialize(session_id='test', platform='discord', hermes_home='/home/das/.hermes', agent_context='primary')
    print('OK:', mp.system_prompt_block()[:100])
else:
    print('FAIL: not available')
"
```
If this prints `OK: # Hindsight Memory\nActive. Bank: finn...`, the provider is working regardless of what the gateway log says.

### Secondary: Log/Dir Checks (less reliable)
- `~/.hindsight/` directory should appear after first message (daemon startup)
- `~/.hermes/logs/hindsight-embed.log` should have daemon startup output
- **PITFALL**: "Memory provider 'hindsight' activated" log line at INFO level may NOT appear in gateway.log even when the provider is active. Do NOT use the absence of this log line as proof of failure — use the direct Python test above.
- Finn should have hindsight_retain, hindsight_recall, hindsight_reflect tools available

### Diagnosing "provider set but nothing happens"
1. Run the direct Python test above — if `is_available()` returns False, the import patch was reverted
2. Check `~/.hindsight/` exists — if not, daemon didn't start (LLM key issue?)
3. Check `~/.hermes/hindsight/config.json` exists and has `"mode": "local_embedded"`
4. Check `~/.hermes/.env` has `HINDSIGHT_LLM_API_KEY` set
5. Check `~/.hermes/config.yaml` has `memory.provider: hindsight`
6. If all correct, gateway restart is needed — user must `/restart` from Discord