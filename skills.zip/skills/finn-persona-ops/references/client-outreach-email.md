# Local Client Outreach via Email (Himalaya + Web Search)

Workflow for finding and reaching out to local small businesses via hello@dasdev.net.

## 1. Lead Scouting Criteria
- **Target:** Largo FL, Clearwater FL, Seminole FL, Pinellas County
- **Business type:** Handyman, landscaping, lawn care, cleaning, pressure washing, painting, moving, small retail
- **Must NOT have:** A professional website already (Facebook-only, Yelp-only, or no web presence)
- **Must have:** A real email address (Gmail, Yahoo, business domain) or phone number for follow-up
- **Avoid:** Chains, franchises, businesses with polished sites

## 2. Email Draft Style (Non-Salesy)
- Subject: casual, lowercase, no "web design" or "offer" language
- Tone: "local kid building sites for local businesses"
- Never compare to competitors or pitch hard
- Mention seeing them specifically (not a template blast)
- Link to dasdev.net as portfolio
- Always "no pressure" sign-off
- Keep under 5 sentences + signature

Example subject patterns:
- "hey from a local kid"
- "quick note from largo"
- "hey from a local"

## 3. Sending via Himalaya CLI
**Only reliable method** — stdin pipe to `template send`:
```bash
cat << 'EOF' | himalaya template send
From: hello@dasdev.net
To: recipient@example.com
Subject: hey from a local kid

Email body here.

arriq
EOF
```

**CRITICAL PITFALL:** `himalaya message write -H "To:..." -H "Subject:..." "body"` fails with "cannot get editor from env var" even with arguments. Always use `template send` with piped input.

## 4. Cron Job Setup Pattern
- **Nightly email check:** Scan inbox for human replies only (filter newsletters, noreply, automated). Use script at `~/.hermes/scripts/check_email_replies.sh`. Silent when nothing found.
- **Every-3-days scout:** Search for 3-5 new leads, report back with business name, service, location, contact info, why they need a site.

**User preference:** Background work cron jobs (email checking, lead scouting) are fine. Scheduled text check-ins to the user feel "so botted" and are NOT allowed.

## 5. Script: Email Reply Filter
```bash
#!/bin/bash
himalaya envelope list --output json 2>/dev/null | jq -r '
  .[] | select(.from | test("noreply|no-reply|automated|newsletter|marketing|@dasdev\\.net"; "i") | not)
  | "From: \(.from) | Subject: \(.subject) | Date: \(.date)"
' | head -20
```

## Session Reference
- July 26 2026: First batch of 5 emails sent (Carr's Landscape, Yeti Handyman, TSL Landscaping, More Than A Store, Trying To Think Handyman)
- Both cron jobs created: email-reply-check (9pm nightly), client-scout (9am every 3 days)
