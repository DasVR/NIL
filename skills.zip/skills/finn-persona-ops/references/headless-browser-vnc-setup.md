# Headless Browser + VNC Setup (July 13 2026 — UPDATED July 13)

Pattern for interactive browser sessions (X login, OAuth, captcha) on a headless server.

## Problem
Puppeteer's `headless: false` mode needs an X server. On a headless server, there's no display. The user needs to manually interact with the browser (enter credentials, solve captcha, click OAuth buttons) — can't be automated.

## Solution
Xvfb (virtual framebuffer) + x11vnc (VNC server bridging the Xvfb display) + VNC viewer app on user's phone/computer. Optionally add a noVNC container for browser-based access.

## Architecture
```
Xvfb :99 (virtual display)
  └── chromium-browser (launched with DISPLAY=:99)
       └── x11vnc (bridges :99 → VNC port 5998)
            └── User connects via VNC viewer app (bVNC, RealVNC Viewer)
                 OR via noVNC web client (browser, no app needed)
```

## Setup Steps

### 1. Install packages
```bash
sudo apt-get install -y xvfb chromium-browser x11vnc
```
- `xvfb` installs in seconds
- `x11vnc` installs in seconds — THIS IS THE CRITICAL MISSING PIECE
- `chromium-browser` on Ubuntu is a snap stub — the snap download takes 5+ minutes. Use `timeout=120` minimum.
- If `sudo` needs a password and you're in a non-interactive terminal, ask the user to configure passwordless sudo:
  ```bash
  echo "das ALL=(ALL) NOPASSWD: ALL" | sudo tee /etc/sudoers.d/das
  ```
- If a previous apt install was interrupted (snap download timed out), run `sudo dpkg --configure -a` first

### 2. Start Xvfb (MUST use background=true)
```
terminal(command="Xvfb :99 -screen 0 1920x1080x24", background=true)
```
- Do NOT use `&` in foreground mode — the terminal tool blocks it
- Do NOT use `nohup` or bash wrappers — just `background=true`
- Verify: `process(action='poll', session_id='...')` should show status=running
- Verify: `pgrep Xvfb` should return a PID

### 3. Start x11vnc (bridges Xvfb display → VNC port)
```
terminal(command="x11vnc -display :99 -forever -shared -rfbport 5998 -nopw", background=true)
```
- MUST use `background=true` — x11vnc is a long-running server
- `-nopw` = no password (for simplicity; user is on Tailscale VPN)
- `-forever` = keep running after client disconnects
- `-shared` = allow multiple simultaneous connections
- Port 5998 (not 5999 — 5999 is used by Docker-OSX VNC on this server)
- Verify: `pgrep x11vnc` should return a PID
- Logs show "The VNC desktop is: das-server:98" when ready

### 4. Launch chromium on the virtual display
```
terminal(command='DISPLAY=:99 chromium-browser --no-sandbox --start-maximized "https://x.com/i/flow/login" --user-data-dir=/path/to/session', background=true)
```
- MUST use `background=true` — chromium is long-running
- `--no-sandbox` required when running as non-root without proper sandboxing
- `--user-data-dir` persists cookies/session for future headless runs
- WebGL errors ("WebGL1 blocklisted") are harmless — chromium works fine without GPU
- AppArmor/DBus errors are cosmetic on headless servers — chromium still works

### 5. User connects via VNC viewer
**Option A — Direct VNC viewer app (SIMPLER, RECOMMENDED):**
- User installs bVNC (Android) or RealVNC Viewer (Android/iOS)
- Connect to: `<tailscale-ip>:5998` (e.g. `100.104.181.43:5998`)
- No password needed
- Sees the chromium window, interacts with it directly

**Option B — noVNC web client (browser-based, no app install):**
```bash
newgrp docker << 'ENDGRP'
docker run -d --name novnc -p 8083:6080 -e REMOTE_HOST=<host-ip> -e REMOTE_PORT=5998 dougw/novnc:latest
ENDGRP
```
- User opens browser: `http://<tailscale-ip>:8083`
- CRITICAL: the noVNC container must be configured to connect to the x11vnc port (5998), not run its own VNC server
- The `dougw/novnc` image's default behavior may not auto-connect to an external VNC — check container logs
- Port conflicts: 8081/8082 used by Docker-OSX noVNC, use 8083+
- The noVNC container runs Alpine 3.6 — can't install packages inside it

**Option A is preferred** — less bloat (no extra Docker container), simpler setup, user just needs a VNC viewer app.

### 6. After login
- Chromium session cookies are saved in `--user-data-dir` path
- For puppeteer: use the same `--user-data-dir` with `headless: true` — no VNC needed for future runs
- Kill chromium: `pkill chromium-browser` or `process(action='kill', session_id='...')`
- Kill x11vnc: `pkill x11vnc` or `process(action='kill', session_id='...')`
- Optionally kill Xvfb: `pkill Xvfb` or `process(action='kill', session_id='...')`
- Optionally stop noVNC: `docker stop novnc`

## Pitfalls

### CRITICAL: noVNC container alone CANNOT see Xvfb display
The `dougw/novnc:latest` container runs its own VNC server internally. It does NOT automatically connect to an Xvfb display running on the host. You MUST install `x11vnc` on the host to bridge the Xvfb display to a VNC port, THEN either:
- Have the user connect directly to the x11vnc port with a VNC viewer app, OR
- Configure the noVNC container to proxy to the x11vnc port

Without x11vnc, the user sees a black screen or connection refused.

### `dpkg --configure -a` needed before apt install
If a previous apt install was interrupted (e.g. snap download timed out), dpkg may be in a half-configured state. Run `sudo dpkg --configure -a` first, then retry the install. This was the key to getting Xvfb installed — `apt-get install -y xvfb` failed silently until dpkg was reconfigured.

### Chromium snap download is very slow
The `chromium-browser` package on Ubuntu is a stub that triggers a snap install. The snap download (~70MB core22 + ~50MB chromium + dependencies) can take 5-10 minutes on slow connections. Use `timeout=120` minimum for the apt command. The download progress is shown in the terminal output as spinning slashes.

### Port 5999 is used by Docker-OSX
On this server, Docker-OSX VNC uses port 5999. Use port 5998 (or another available port) for x11vnc to avoid conflicts. Check with `ss -tlnp | grep 599` before starting.

### X/Twitter (and React SPAs) require JavaScript — curl cannot scrape them
X/Twitter is a React SPA. `curl` with session cookies returns the HTML shell (webpack chunks, CSS, loading placeholder) but NO actual content. The `guest_id` cookies visible in the SQLite database are tracking cookies, not auth tokens. The real auth (`auth_token`, `ct0`) is stored encrypted in Chromium's cookie database and cannot be extracted via `sqlite3` for use in curl. To scrape X/Twitter content, you MUST use a headless browser (puppeteer/playwright) that executes JavaScript. The session cookies saved by chromium's `--user-data-dir` can be reused by puppeteer with `headless: true`.

### Chromium cookie values are encrypted
`sqlite3 session/Default/Cookies` shows cookie names but values appear empty/binary. Chromium encrypts cookie values using OS-level keyrings. You cannot extract `auth_token` values via sqlite3 and use them in curl. Use puppeteer with the saved `--user-data-dir` instead.

### AppArmor/DBus errors are cosmetic
Chromium on Ubuntu snap shows AppArmor/DBus errors ("An AppArmor policy prevents this sender from sending this message"). These are cosmetic on headless servers — chromium still works fine for browsing. Don't try to fix AppArmor policies.

## Files Used
- `/home/das/x-bookmarks/login.js` — puppeteer script that opens X login page
- `/home/das/x-bookmarks/session/` — saved chromium profile with session cookies
- Xvfb display: `:99` (convention)
- x11vnc port: `5998` (5999 taken by Docker-OSX)
- noVNC container: `novnc` on ports 8083/8084 (optional, only if user prefers browser-based access)