# Discord Message Truncation Fix

## Problem (July 24 2026)
Discord adapter hardcodes `MAX_MESSAGE_LENGTH = 2000` which causes messages to cut off mid-sentence. User repeatedly complained: "i hate when u cut off", "randomly ur message just ends", "u keep getting cut off bruuuu".

## Root Cause
Three places hardcode 2000:
1. `~/.hermes/hermes-agent/plugins/platforms/discord/adapter.py` line ~750: class attr `MAX_MESSAGE_LENGTH = 2000`
2. Same file line ~751: `_SPLIT_THRESHOLD = 1900` (when to start splitting)
3. Same file line ~7849: `max_message_length=2000` (platform registry entry)

## Fix Applied (July 24 2026)
All three changed to 4000:
- `MAX_MESSAGE_LENGTH = 4000`
- `_SPLIT_THRESHOLD = 3800`
- `max_message_length=4000`

## OUTDATED — August 13 2026
Discord still enforces 2000 for bots. The 4000 patch causes immediate 400 Bad Request.
Current fixes are in `references/discord-cutoff-fix-2026-08-13.md`:
- Add `model.max_tokens: 4096`
- Remove `humanize` plugin
- Lower `_text_batch_split_delay_seconds` default from 2.0 → 0.3


## Activation
Gateway must be `/restart`ed from Discord for changes to take effect.

## Workaround (until restart)
Split all long messages manually into smaller bubbles using `␤` (U+2424) sentinel. Keep each bubble under 2000 chars.

## User Preference: NEVER cut off mid-thought
User explicitly hates when messages randomly end. Prioritize completing thoughts even if it means splitting into more bubbles. Never leave a sentence unfinished.
