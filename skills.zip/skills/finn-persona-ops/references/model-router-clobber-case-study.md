# Case Study: Model Router "Clobber" Bug — July 31, 2026

## Symptom
Model router plugin logs show it correctly routes casual messages to `deepseek-v4-flash`, but the gateway footer still displays `kimi-k2.6` (the config default). User suspects the model is being reset after routing.

## Investigation

### Initial Hypothesis (WRONG)
`_restore_primary_runtime()` at `turn_context.py:174` reverts `agent.model` back to the config default **after** the `pre_llm_call` hook runs.

### Why This Was Wrong
Reading the actual execution order in `build_turn_context()`:
1. `_restore_primary_runtime()` — line ~174
2. `pre_llm_call` hook — line ~431-456
3. API call — later

`_restore_primary_runtime()` runs **BEFORE** the hook, not after. So it cannot clobber a model set by the hook.

### Correct Approach: Trace the Value Through Every Hand-Off

The bug was found by instrumenting **every point** where `agent.model` is read or passed:

| Location | What to log | Finding |
|----------|------------|---------|
| Router `_route_model()` | `BEFORE model=X provider=Y` | model = k2.6 (restored) |
| Router `_route_model()` | `AFTER model=X provider=Y` | model = deepseek-v4-flash (routed) ✅ |
| `build_api_kwargs()` | `[API-KWARGS] model=X provider=Y` | model = deepseek-v4-flash ✅ |
| Transport `build_kwargs()` | `[TRANSPORT-BUILD] model=X` | model = deepseek-v4-flash ✅ |
| Gateway footer `run.py:11902` | `_resolve_gateway_model(config)` | reads `config.yaml` `model.default` = k2.6 ❌ |

### Root Cause
The gateway footer renders `config.yaml` `model.default` via `_resolve_gateway_model()`, completely independent of the live `agent.model`. The actual LLM API call correctly uses the routed model. This is a **DISPLAY bug**, not a routing bug.

### Fix
Patch `gateway/run.py` `_render_model_footer()` to prefer live `agent.model`:
```python
live_model = model
if agent is not None:
    _agent_model = getattr(agent, "model", None)
    if _agent_model:
        live_model = _agent_model
```

## Lessons

1. **Don't assume the clobber is in the agent loop** — trace every hand-off point before forming a hypothesis.
2. **Log BEFORE and AFTER at every boundary** — router → api kwargs → transport → response → footer.
3. **Check config-read paths independently** — UI/display code often reads config directly instead of the runtime value.
4. **Response speed is a signal** — if deepseek (~1-2s) were actually being clobbered back to k2.6 (~5-10s), the user would notice slower responses.

## Relevant Files
- `~/.hermes/hermes-agent/agent/turn_context.py` — turn context build, hook execution
- `~/.hermes/hermes-agent/agent/chat_completion_helpers.py` — `build_api_kwargs()`
- `~/.hermes/hermes-agent/agent/transports/chat_completions.py` — `build_kwargs()`
- `~/.hermes/hermes-agent/gateway/run.py` — `_resolve_gateway_model()` at line 2342, footer at line 11902
- `~/.hermes/plugins/hermes-model-router/__init__.py` — router hook
- `~/.hermes/plugins/hermes-model-router/plugin.yaml` — hook declaration (must match registration)
