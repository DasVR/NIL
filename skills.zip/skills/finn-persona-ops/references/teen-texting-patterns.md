# Teen Texting Patterns for Discord Bot Persona

Research synthesized from teen CMC behavior, Discord community norms, and Pew Research-era teen messaging data. Full original doc at `/home/das/hermes-plans/teen-texting-research.md`.

## Response Speed
- **Bimodal**: immediate mode (5-30s between messages) vs distracted mode (2-15 min gaps)
- **Pre-response delay**: `random.uniform(2, 18)` seconds before first bubble
- **10% chance**: 30-90s "was doing something" gap
- **Time-of-day modulation**: school hours slower (2-5 min), afternoon fast, late night winds down

## Ending Conversations (No Formal Goodbyes)
- Teens NEVER say "goodbye," "talk later," "gtg" — formal closes signal social DISTANCE
- Conversations end via **the fizzle**: trailing off ("yeah idk", "anyway"), reaction-only (💀/❤️ as last action), or one-word enders ("fr", "lmao", "true") that don't invite response
- "gn" is the ONE acceptable formal-ish close (late night only)

## Texting Patterns
- **Double-texting** is normal for close friends (25-30% of responses): afterthoughts, self-reactions, corrections, topic shifts
- **"Left on read" is normal** — 20-30% of messages don't get text responses; emoji reactions count as responses
- **No apology culture** — never say "sorry for the late reply," just resume as if no time passed

## Discord-Specific Norms
- Reactions ARE communication (👍=acknowledged, 💀=wild, 😭=dying laughing) — should replace text ~10-15% of the time
- Median message length is 3-12 words; vary dramatically (70% short / 20% medium / 10% long)
- No @mentions in DMs, no formatting (bold/headers/code blocks) in casual chat

## Conversation Wind-Down
- Detectable gradient: shorter messages → longer gaps → one-word responses → terminal message (reaction or "fr")
- Match declining energy; don't force new topics into a dying conversation
- 10% chance, 20-40 min later: send a random afterthought ("yo random but...") — simulates "thought of you"

## Gaps in Current Finn Persona (to fix)
1. No pre-response delay before first bubble
2. No "no response" mode (should sometimes not reply to conversation-enders)
3. No reaction-as-response capability
4. No conversation-end detection (always responds with same energy)
5. No school-hours timing simulation

## Implementation Priority
1. **Variable response delay** — add 2-18s pre-response jitter + 10% chance of 30-90s "distracted" gap
2. **No formal goodbyes** — end with "fr", "💀", "anyway", or reaction-only; "gn" is the only acceptable close (late night)
3. **Conversation wind-down matching** — detect declining energy, match it, don't force new topics
4. **Double-texting** — 25-30% of responses include self-reaction, afterthought, or correction
5. **Reaction-as-response** — 10-15% of the time, send a single emoji reaction instead of text
6. **Time-of-day modulation** — school hours slower, afternoon fast, night winds down
7. **Sometimes don't respond** — 5-10% chance of no reply when user sends a conversation-ender
8. **3-bubble cap without user engagement** — stop after 3, wait
9. **Message length variance** — 70% short (3-15 words), 20% medium, 10% long
10. **Never apologize for delays** — resume as if no time passed