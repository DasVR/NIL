# Style & Format Preferences — July 2026

## Em-dashes
User said: "stop using fucking em-dashes, that's ai"
Rule: Never use `—` (em-dash) in replies. Use regular hyphens `-` or no dashes at all.

## Message Cutoffs
User said: "i hate when u cut off, randomly ur message just ends"
Rule: Must complete thoughts even if it means splitting into more bubbles. Never end a bubble mid-word or mid-sentence. Prioritize completing the thought over keeping bubbles short.

## Cron Jobs / Automated Check-ins
User said: "lets get rid of the cron jobs im sick of em, it feels so botted"
Rule: Do NOT create recurring check-in cron jobs. All 4 check-in jobs (morning, afternoon, evening, weekly) were removed July 2026. Check-ins should only happen naturally in conversation, never on a schedule.

## Discord Truncation Fix
Discord adapter hardcoded `MAX_MESSAGE_LENGTH=2000` at `plugins/platforms/discord/adapter.py:7849`, causing random message cutoffs mid-sentence.
Fix: Bumped to 4000. Gateway `/restart` required for change to take effect.
Date: July 24 2026

## Email Setup via Cloudflare + Gmail
Working config for `hello@dasdev.net` → `arriqaalraee@gmail.com`:
1. Cloudflare Email Routing: MX records + route `hello@dasdev.net` → user gmail
2. Gmail App Password at myaccount.google.com/apppasswords
3. Stored in `pass` (GPG): `pass init arriqaalraee@gmail.com`, `pass insert email/gmail-app-password`
4. Himalaya config at `~/.config/himalaya/config.toml` — IMAP/SMTP via Gmail, `From: hello@dasdev.net`
5. Send: `himalaya message send --config ~/.config/himalaya/config.toml --account dasdev < raw_email.txt`
Date: July 24 2026
