# Model Router — Semantic Scoring (v4, July 31, 2026)

Reference for the semantic embedding layer added to the model router in this session.

## Why Semantic Scoring Was Needed

Lexical keyword analysis was fragile:
- "set up docker compose with nginx" → lexical saw "compose" in creative markers → wrongly scored as creative
- "got ur plugins?" → lexical saw "plugins" in tool markers → wrongly scored as coding
- "write a landing page" → lexical score was low (29) → borderline, could fall through to main model

Semantic scoring fixes these by comparing the full message meaning against category centroids.

## Architecture

```
User message
    ↓
_strip_reply_context()   ← removes Discord quoted context
    ↓
_lexical_analysis()       ← keywords, patterns, regex (v2)
    ↓
_semantic_score()         ← embed via nomic-embed-text → cosine sim to centroids
    ↓
_fusion()                 ← combine lexical + semantic signals
    ↓
_category + model
```

## Embedding Setup

- **Model**: `nomic-embed-text:latest` via Ollama at `localhost:11434`
- **Dimensions**: 768
- **Latency**: ~5-20ms per message (local, no network)
- **Cost**: zero (local inference)

```python
def _get_embedding(text: str) -> list[float]:
    data = json.dumps({"model": "nomic-embed-text", "input": text}).encode()
    req = urllib.request.Request(
        "http://localhost:11434/api/embed",
        data=data,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=5) as resp:
        result = json.loads(resp.read().decode())
        return result["embeddings"][0]
```

## Category Centroids

Computed once at runtime from 5 example phrases per category:

| Category | Example Phrases |
|----------|-----------------|
| casual | "yo what's up twin", "bet fr", "lol that's fire", "gn bro", "sup how you been" |
| coding | "write a python function to sort a list", "debug this error in my docker compose", "how do i fix this import", "create a class for user authentication", "patch this file to add logging" |
| reasoning | "analyze the pros and cons of this approach", "why does this algorithm have O(n log n) complexity", "compare these two solutions", "explain step by step how this works", "what would happen if we changed this" |
| creative | "write a landing page for my portfolio", "design a logo concept", "compose a short story", "create a blog post about cybersecurity", "draft an email to a client" |
| complex | "set up a docker compose with nginx postgres and redis", "deploy this to my server and configure ssl", "create a multi-agent workflow with cron jobs", "plan the architecture for this system", "configure the plugin with multiple fallbacks" |

Centroid = mean of 5 embeddings per category. Cached after first computation.

## Decision Fusion

```python
semantic_scores = _semantic_score(message)
top_semantic_cat = max(semantic_scores, key=semantic_scores.get)
top_semantic_score = semantic_scores[top_semantic_cat]

semantic_override = False

# Strong override: semantic is very confident
if top_semantic_score > 0.72:
    if category == "unknown" or score < 50:
        category = top_semantic_cat
        semantic_override = True
    elif top_semantic_cat == "casual" and category != "casual":
        category = "casual"
        score -= 30
        semantic_override = True

# Moderate nudge: bump score directionally
if top_semantic_score > 0.60:
    if top_semantic_cat in ("coding", "complex", "reasoning"):
        score += 15
    elif top_semantic_cat == "casual":
        score -= 20

# Re-evaluate category (skip if semantic was confident)
if not semantic_override:
    # ... lexical re-evaluation ...
```

## Test Results (July 31, 2026)

| Message | Lexical Category | Semantic Top | Final | Correct? |
|---------|-----------------|------------|-------|----------|
| "yo what's up twin" | casual | casual:0.75 | casual | ✅ |
| "write a python function to sort a list" | coding | coding:0.66 | coding | ✅ |
| "set up docker compose with nginx postgres and redis" | creative | complex:0.75 | complex | ✅ (fixed) |
| "bet fr" | casual | casual:0.74 | casual | ✅ |
| "analyze the tradeoffs between postgres and mysql" | reasoning | reasoning:0.62 | reasoning | ✅ |
| "fix my nginx config pls" | coding | complex:0.63 | coding | ✅ |
| "write a landing page for my portfolio" | creative | creative:0.78 | creative | ✅ (boosted) |
| "how do i configure ssl on my server" | coding | complex:0.69 | coding | ✅ |

## Files

- Plugin code: `~/.hermes/plugins/hermes-model-router/__init__.py`
- Config: `~/.hermes/plugins/hermes-model-router/config.yaml`
- Plugin manifest: `~/.hermes/plugins/hermes-model-router/plugin.yaml`

## Pitfalls

- **Ollama must be running**: If `localhost:11434` is down, `_get_embedding()` returns `[]`, semantic scores all zero, router falls back to pure lexical. Safe degradation.
- **Centroid cache**: `_CATEGORY_CENTROIDS` is a module-level dict. First message after restart triggers 5 embedding calls (~100ms total). All subsequent messages use cached centroids.
- **Short messages**: "bet fr" (2 words) → embedding still works fine. "ok" (1 word) → embedding works but casual lexical detection is faster and already catches it.
- **Quoted context**: Discord replies prepend quoted text. `_strip_reply_context()` removes this before both lexical and semantic analysis. Critical — without it, a casual reply to a coding message would embed to coding.

## Future Improvements

- Per-user centroids: learn from user's own message history, not generic examples
- Sentiment/energy embedding: route low-energy messages to more forgiving models
- Conversation history: use last N messages as context, not just current message
- Auto-rebuild centroids: if user disagrees with a route, add message to correct category's centroid set
