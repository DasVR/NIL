# iMessage Integration — BlueBubbles vs Photon

Reference for setting up iMessage integration with Hermes Agent.
Full plan: /home/das/hermes-plans/DISCORD-CHANGES-AND-IMESSAGE-PLAN.md

## Two Options

### Photon (Recommended Starting Point)
- No Mac needed — managed service handles Apple layer
- Free tier: 5K messages/day, 50 new conversations/day
- Setup: `hermes photon setup --phone +1YOUR_NUMBER`
- Uses persistent gRPC stream (no webhook, no public URL)
- Node sidecar runs locally, Python adapter talks to it over loopback
- Inbound attachments: metadata-only for now (filename + MIME, no bytes)
- Outbound attachments: fully supported (images, voice, video, docs)
- No tapbacks/typing indicators/read receipts yet
- Gets a dedicated iMessage number you text to reach Finn

Photon env vars:
- `PHOTON_PROJECT_ID` / `PHOTON_PROJECT_SECRET` — set by setup
- `PHOTON_ALLOWED_USERS=+1NUMBER` — pre-authorize your number
- `PHOTON_HOME_CHANNEL` — default space for cron deliveries

Photon user authorization:
- DM pairing (default): unknown sender gets pairing code, approve with `hermes pairing approve photon <CODE>`
- Pre-authorize: `PHOTON_ALLOWED_USERS=+1NUMBER` in .env
- Open access (dev): `PHOTON_ALLOW_ALL_USERS=true`

Prerequisites: Node.js 18.17+, a phone number that can receive iMessage, Photon account at app.photon.codes

### BlueBubbles (Full Self-Hosted)
- Requires always-on Mac running Messages.app (or macOS VM)
- Fully self-hosted — no third party sees messages
- Full feature set: tapbacks, typing indicators, read receipts (with Private API helper)
- Free, open source

BlueBubbles env vars:
- `BLUEBUBBLES_SERVER_URL=http://<ip>:<port>` — server URL
- `BLUEBUBBLES_PASSWORD=<password>` — server password
- `BLUEBUBBLES_ALLOWED_USERS=email@icloud.com,+1NUMBER` — authorized users
- `BLUEBUBBLES_HOME_CHANNEL` — phone/email for cron delivery
- `BLUEBUBBLES_REQUIRE_MENTION=false` — mention gating for group chats

BlueBubbles setup:
1. Install BlueBubbles Server on Mac/VM
2. Sign in with Apple ID in Messages.app
3. Configure connection method (Tailscale recommended)
4. Install Private API helper for tapbacks/typing/read receipts
5. Note Server URL and Password
6. `hermes gateway setup` → select BlueBubbles → enter URL + password
7. `hermes gateway restart`

## macOS VM Setup (for BlueBubbles)

### Docker-OSX Method (Recommended)
```bash
sudo apt install qemu-system qemu-utils ovmf
docker pull sickcodes/docker-osx:latest
docker run -d --name macos-vm --device /dev/kvm -p 5999:5999 \
  -e RAM=8 -e CPU_PATH=host \
  -v "$HOME/docker-osx:/home/arch/OSX" sickcodes/docker-osx:latest
```
- Connect via VNC: `vnc://localhost:5999`
- Install macOS (Ventura/Sonoma recommended)
- ~8GB RAM, ~256GB qcow2 disk, 4 CPU cores
- Install Tailscale in VM for secure connectivity to host

### Docker-OSX First-Time Setup (Observed July 9 2026)
When running Docker-OSX for the first time with no existing BaseSystem.img:
1. Auto-downloads Sequoia Recovery image (~843MB) from Apple CDN (default is now Sequoia, not Ventura)
2. Converts BaseSystem.dmg → BaseSystem.img (qemu-img convert)
3. Creates 256GB qcow2 virtual disk (`mac_hdd_ng.img`)
4. Builds OpenCore bootloader (clones OpenCorePkg, compiles)
5. Boots into macOS installer

**PITFALL — volume mounts critical**: Without `-v /home/das/docker-osx:/home/arch/OSX`, the container won't persist the disk image. Each restart re-downloads everything from scratch (wasting ~20+ min). ALWAYS mount a host directory for the VM files.
**PITFALL — container names auto-generated**: Docker-OSX with `docker run -d` (no `--name`) gets random names. Use `--name bluebubbles-vm` or find with `docker ps -a | grep osx`.
**PITFALL — default is now Sequoia (15)**: Docker-OSX auto-downloads Sequoia by default as of July 2026. Sonoma (14) is recommended by the docker-osx project. Override with `--env SHORTNAME=sonoma` or `SHORTNAME=ventura`.
**PITFALL — VNC port is 5900 inside container, NOT 8000.** Docker-OSX runs VNC on port 5900 inside the container via qemu. The image exposes both 8000 and 1234, but VNC listens on 5900. You MUST map `-p 8000:5900` (host 8000 → container 5900). If you map `-p 8000:8000`, VNC won't connect because nothing listens on 8000 inside. Verify with `docker exec <name> ss -tlnp | grep 5900` — look for `qemu-system-x86` listening on 5900.
**PITFALL — `--privileged` flag required.** Without `--privileged`, `docker port` returns empty and ports don't actually map. Always include `--privileged`.
**PITFALL — image verification failure**: The `BaseSystem.chunklist` verification may fail with "Inappropriate ioctl for device" in Docker. This is cosmetic — the download itself is fine, proceed anyway.
**PITFALL — GTK init failure WITHOUT EXTRA env var is FATAL (July 14 2026).** If you do NOT pass `-e EXTRA="-display none -vnc 0.0.0.0:99,password=off"`, QEMU defaults to the GTK display backend. On a headless server (no X11), QEMU crashes with `gtk initialization failed` and the container EXITS. This is NOT cosmetic — the VM never starts. The "cosmetic" note below only applies when EXTRA is already set with `-display none`. ALWAYS pass EXTRA on headless servers.
**PITFALL — GTK init failure WITH EXTRA set is cosmetic.** When EXTRA includes `-display none`, headless servers may still show "gtk initialization failed" in logs — but QEMU continues running because display is redirected to VNC. VNC server works on the configured port. Ignore this error in that case.
**PITFALL — RealVNC Viewer may reject connection.** RealVNC Viewer closes connection immediately to Docker-OSX's raw VNC server. Use TigerVNC, TightVNC, or noVNC (web-based) instead. To set up noVNC web access: `sg docker -c 'docker run -d --name novnc --network host -e VNC_SERVER_HOST=127.0.0.1 -e VNC_SERVER_PORT=8000 -p 8082:8080 dougw/novnc:latest'` then access at `http://YOUR_IP:8082`.
**PITFALL — Recreating container re-downloads macOS.** Each `docker rm` + `docker run` cycle re-downloads the ~843MB Recovery image unless the volume mount already has `BaseSystem.img`. Avoid recreating — fix issues by stopping/starting instead.
**PITFALL — Don't kill Docker-OSX during bloat cleanup.** `docker rm` of stopped containers + `docker image prune` will delete the Docker-OSX image and stopped container. Always exclude `bluebubbles-vm` from cleanup or ensure it's running before cleanup.

### BlueBubbles Inside Docker-OSX (After macOS Boots)
1. Connect to VM via VNC at `vnc://localhost:5999`
2. Complete macOS installer (select language, format disk, install)
3. Sign in with Apple ID in Messages.app
4. Download and install BlueBubbles Server from bluebubbles.app
5. Complete BlueBubbles setup wizard — sign in with Apple ID, configure connection method
6. Note Server URL (likely `http://<vm-ip>:1234`) and Password
7. Install Private API helper for tapbacks/typing indicators/read receipts
8. On host: `hermes gateway setup` → select BlueBubbles → enter URL + password
9. `hermes gateway restart`

**Network**: The VM needs to be reachable from the host. Docker-OSX uses a bridge network by default — the VM gets its own IP. Use `docker inspect <container> | grep IPAddress` or install Tailscale in both VM and host for reliable connectivity.

### Resource Requirements (Das Server)
- 30GB RAM total → 8GB for VM → 22GB remaining
- 856GB free disk → 100GB for VM → 756GB remaining
- KVM available (/dev/kvm) ✅
- Docker installed ✅
- Tailscale already running ✅

### Security Notes
- Use a secondary Apple ID for the VM (Apple may flag automation)
- Use Tailscale for VM connectivity (no public exposure)
- BlueBubbles password-protected API

## Docker-OSX VNC Fixes (Researched July 10 2026)

### Root Cause: VNC Connection Closes Immediately
The original `start-bluebubbles.sh` used:
```
-e EXTRA="-display none -vnc 0.0.0.0:99,password-secret=secvnc0 -object secret,id=secvnc0,data=vncpass"
```
**Problem:** QEMU 6+ `password-secret` with `-object secret` requires the VNC client to supply a **username AND password**. Most VNC clients (macOS Screen Sharing, RealVNC Viewer) only send a password → immediate rejection/close. This is separate from the RealVNC incompatibility noted above — even compatible clients fail with this auth mode.

### Fix A: Disable VNC Password (easiest, LAN only)
```bash
-e EXTRA="-display none -vnc 0.0.0.0:99,password=off"
```
Any VNC client connects without password. Use TigerVNC (`sudo apt install tigervnc-viewer`) or RealVNC Viewer (NOT macOS Screen Sharing — QEMU VNC doesn't implement all RFB extensions macOS Screen Sharing expects).

### Fix B: `password=on` with QEMU Monitor
```bash
docker run -i ... -e EXTRA="-display none -vnc 0.0.0.0:99,password=on" ...
# Press Enter for (qemu) prompt, then:
# change vnc password yourpassword
```
Must use `-i` (not `-it`) to interact with QEMU console. Kill with `docker kill <id>`.

### Fix C: SSH Tunnel + VNC (secure remote)
```bash
# Start with VNC (password=off)
# From local machine:
ssh -N -L 5999:127.0.0.1:5999 das@<server-ip>
# Then connect VNC to localhost:5999
```

### noVNC (Browser-Based VNC — Best for Remote)
Run alongside Docker-OSX for web-based access — no VNC client installation needed:
```bash
docker run -d --name novnc --network host \
  -e REMOTE_HOST=127.0.0.1 -e REMOTE_PORT=5999 \
  dougw/novnc
# Access at http://<server-ip>:8081
```

**PITFALL — noVNC crashes if VNC server isn't ready yet.** The `dougw/novnc` container exits with status 1 and enters FATAL state in supervisord if the VNC server (port 5999) isn't accepting connections yet (e.g. macOS still downloading/installing). Check `docker logs novnc` — if you see "exited: novnc (exit status 1; not expected)" repeating, the VNC server isn't up. Wait for the macOS VM to finish downloading + booting, then restart noVNC: `docker restart novnc`. The noVNC container does NOT auto-reconnect — it gives up after ~5 retries.

**PITFALL — RealVNC Viewer still rejects even with `password=off`.** RealVNC Viewer's protocol negotiation is incompatible with QEMU's raw VNC implementation in some versions. Even after fixing the `password-secret` auth issue, RealVNC may close the connection immediately. Use TigerVNC (`sudo apt install tigervnc-viewer`), TightVNC, or the browser-based noVNC approach instead. Do NOT spend time troubleshooting RealVNC — switch clients.

**PITFALL — noVNC `REMOTE_HOST` must be reachable from inside the container.** With `--network host`, the noVNC container can reach `127.0.0.1:5999` on the host. Without `--network host`, you need the host's docker bridge IP or `host.docker.internal`. If noVNC keeps crashing, check network connectivity first.

### SPICE Protocol (Alternative to VNC, Better Performance)
```bash
-e EXTRA="-monitor telnet::45454,server,nowait -nographic -serial null -spice disable-ticketing,port=3001"
# Connect: remote-viewer spice://<server-ip>:3001
```

## Headless / SSH-Only Operation (No VNC Needed After Initial Setup)

VNC is only needed for: (1) initial macOS installation, (2) Apple ID sign-in in Messages.app, (3) granting Full Disk Access + Accessibility permissions to BlueBubbles Server. After that, run headless via SSH only.

### Phase 1: Initial Install (VNC Once)
```bash
qemu-img create -f qcow2 maindisk.qcow2 64G
docker run -d --name macos-vm --device /dev/kvm \
  -p 5999:5999 -p 50922:10022 -p 1234:1234 \
  -v $PWD/maindisk.qcow2:/image \
  -e IMAGE_PATH="/image" -e GENERATE_UNIQUE=true \
  -e SHORTNAME=ventura \
  -e EXTRA="-display none -vnc 0.0.0.0:99,password=off" \
  sickcodes/docker-osx:latest
# Connect via VNC or noVNC to install macOS
```

### Phase 2: Enable SSH Inside macOS (Via VNC, one-time)
- System Settings → General → Sharing → Remote Login → ON
- `sudo passwd user` → set to `alpine`
- `sudo pmset -a sleep 0 disksleep 0 displaysleep 0`
- Optional: `sudo defaults write /Library/Preferences/com.apple.loginwindow autoLoginUser -string "user"`

### Phase 3: Switch to Headless (No VNC)
```bash
docker stop macos-vm && docker rm macos-vm
docker run -d --name macos-vm --device /dev/kvm \
  -p 50922:10022 -p 1234:1234 \
  -v $PWD/maindisk.qcow2:/image \
  -e IMAGE_PATH="/image" -e GENERATE_UNIQUE=true \
  -e NOPICKER=true \
  sickcodes/docker-osx:naked
# SSH: ssh user@localhost -p 50922 (password: alpine)
```

### SSH Access Details
- **Port**: 50922 (host) → 10022 (container internal)
- **Credentials**: user / alpine
- **Default SSH is OFF** — must enable Remote Login inside macOS first (via VNC)
- Enable via terminal: `sudo systemsetup -setremotelogin on`
- File sharing: `sshfs user@localhost: -p 50922 ~/mnt/osx`
- `naked-auto` variant auto-configures SSH with `-e USERNAME=user -e PASSWORD=alpine`
- QEMU monitor via telnet: add `-e EXTRA="-monitor telnet::45454,server,nowait -nographic -serial null"` and `-p 45454:45454`

### Headless Telnet Monitor (QEMU Console Without VNC)
```bash
docker run -d --name macos-vm --device /dev/kvm \
  -p 50922:10022 -p 45454:45454 \
  -v $PWD/maindisk.qcow2:/image \
  -e IMAGE_PATH="/image" -e GENERATE_UNIQUE=true -e NOPICKER=true \
  -e EXTRA="-monitor telnet::45454,server,nowait -nographic -serial null" \
  sickcodes/docker-osx:naked
# telnet localhost 45454 → QEMU monitor console
```

### BlueBubbles Without macOS VM
**Not possible.** BlueBubbles Server requires macOS (Messages.app + iMessage frameworks + IMCore/IdentityServices). There is no Linux-native build. Alternative: Photon (managed, no Mac needed).

### Updated start-bluebubbles.sh Script
The script at `/home/das/bluebubbles/start-bluebubbles.sh` now supports two modes:
- `./start-bluebubbles.sh vnc` — VNC + noVNC for initial macOS install (password=off, port 5999, noVNC on 8081)
- `./start-bluebubbles.sh headless` — SSH-only, no VNC (uses `sickcodes/docker-osx:naked`, port 50922)

### BlueBubbles-Specific Docker-OSX Guide
The `pdubbbbbs/docker-osx-proxmox` GitHub repo is specifically designed for BlueBubbles on Docker. While targeting Proxmox, the Docker commands work on any Linux. Key pattern:
```bash
docker run -d --name macos --dns=1.1.1.1 --device /dev/kvm \
  -p 5999:5999 -p 50922:10022 -p 1234:1234 \
  -v /opt/docker-osx/maindisk.qcow2:/image \
  -e IMAGE_PATH=/image \
  -e 'EXTRA=-display none -vnc 0.0.0.0:99,password=off' \
  -e WIDTH=1920 -e HEIGHT=1080 -e GENERATE_UNIQUE=true \
  sickcodes/docker-osx:latest
```
Port 1234 is pre-mapped for BlueBubbles API.

## Docker-OSX VNC Port Conflict Fix (July 15 2026)

### Root Cause: `hostfwd` port 5900 conflicts with `-vnc :0`

The Launch.sh script includes `hostfwd=tcp::${SCREEN_SHARE_PORT:-5900}-:5900` which maps port 5900 inside the container for macOS Screen Sharing. When you also pass `EXTRA="-vnc :0"` (which binds QEMU's VNC to port 5900), there's a **port conflict**: QEMU binds the VNC listener to 5900, but the `hostfwd` mapping also tries to use 5900. The result: VNC accepts TCP connections but sends **empty RFB version string** (0 bytes) and then closes the connection after a few seconds. No VNC client can connect.

**Symptoms:**
- `ss -tulnp` shows port 5900 LISTENING inside container (QEMU process)
- `vncviewer` connects ("Connected to host 127.0.0.1 port 5999") but gets no data
- Python socket: `s.recv()` returns `b''` (empty) or times out
- TigerVNC: "End of stream" / "connection was dropped by the server before the session could be established"

### Fix: Use `-vnc :1` (port 5901) instead of `-vnc :0` (port 5900)

```bash
docker run -d \
    --name bluebubbles-vm \
    --device /dev/kvm \
    -p 50922:10022 \
    -p 5999:5901 \
    -e NOPICKER=true \
    -e GENERATE_SPECIFIC=true \
    -e DEVICE_MODEL="iMac15,1" \
    -e SERIAL="C02PV08WFY14" \
    -e BOARD_SERIAL="C02PV08WFY14JG36UE" \
    -e UUID="d5854b28-6f14-4606-aebc-89ea4146b981" \
    -e MAC_ADDRESS="A8:5C:2C:40:A4:98" \
    -e WIDTH=1920 -e HEIGHT=1080 \
    -e RAM=8 \
    -e AUDIO_DRIVER=none \
    -e SCREEN_SHARE_PORT=5900 \
    -e MASTER_PLIST_URL='https://raw.githubusercontent.com/sickcodes/osx-serial-generator/master/config-custom.plist' \
    -e "EXTRA=-vnc :1" \
    -v /home/das/bluebubbles/maindisk.qcow2:/home/arch/OSX-KVM/mac_hdd_ng.img \
    -v /home/das/bluebubbles/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img \
    sickcodes/docker-osx:latest
```

Key differences from previous configs:
- `-p 5999:5901` — maps host 5999 to container port 5901 (NOT 5900)
- `-e "EXTRA=-vnc :1"` — VNC on display :1 = port 5901, avoiding conflict with hostfwd 5900
- `-e AUDIO_DRIVER=none` — disables ALSA audio (see below)
- Individual file mounts (NOT whole directory mount, see below)

This was the ONLY config that produced a working VNC handshake (`RFB 003.008`, 1920x1080, auth=0, name="QEMU").

### PITFALL — `-display vnc=:0` FAILS while `-vnc :1` WORKS

Using `EXTRA="-display vnc=:0"` instead of `EXTRA="-vnc :1"` causes QEMU to error: "Failed to find an available port: Address already in use" because `-display vnc=:0` tries to bind port 5900 which is already used by hostfwd. Always use `-vnc :1` (standalone flag) NOT `-display vnc=:0`.

### PITFALL — `AUDIO_DRIVER=none` required on headless servers

The Launch.sh script hardcodes `-audiodev ${AUDIO_DRIVER:-alsa},id=hda -device ich9-intel-hda -device hda-duplex,audiodev=hda`. On a headless server with no sound card, `alsa` crashes with:
```
ALSA lib confmisc.c:855:(parse_card) cannot find card '0'
alsa: Could not initialize DAC
audio: Could not create a backend for voice `dac'
```
Previously, this was fixed by stripping audio lines from Launch.sh via `sed`. The cleaner fix: `-e AUDIO_DRIVER=none` makes QEMU use `-audiodev none,id=hda` which creates the audio devices but with no actual audio backend — no crash.

### PITFALL — Mounting whole directory overwrites container scripts

Mounting `-v /home/das/bluebubbles:/home/arch/OSX-KVM` overwrites ALL the container's built-in scripts (Launch.sh, serial generators, OpenCorePkg, etc.) because the host directory doesn't have them. The container then fails with:
```
sed: can't read Launch.sh: No such file or directory
./Docker-OSX/osx-serial-generator/generate-specific-bootdisk.sh: No such file or directory
```

**Fix**: Mount individual disk image files instead:
```bash
-v /home/das/bluebubbles/maindisk.qcow2:/home/arch/OSX-KVM/mac_hdd_ng.img \
-v /home/das/bluebubbles/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img
```
This preserves the container's scripts while using the host's pre-built disk images. `GENERATE_SPECIFIC=true` works correctly with this approach because the serial generator scripts remain available inside the container.

### PITFALL — VNC framebuffer empty during early boot (NOT a VNC bug)

After the VNC handshake succeeds (RFB version, security, screen 1920x1080, name "QEMU"), the server sends `SetColourMapEntries` (RFB message type 1) but does NOT send `FramebufferUpdate` (type 0) for **many minutes** while macOS is in the OpenCore/EFI boot phase. This is NOT a VNC incompatibility — the display simply isn't rendering yet.

**Symptoms:**
- VNC handshake works (version, auth, screen size all correct)
- Server sends 1542 bytes of `SetColourMapEntries` data
- After requesting FramebufferUpdate, no data comes back
- `docker stats` shows CPU at 30-40% (VM IS running)
- After 5-10 minutes, framebuffer updates begin

**Diagnostic**: Check `docker stats bluebubbles-vm` — if CPU > 10% and memory > 2GB, the VM is actively booting. Just wait longer. macOS in QEMU can take 5-15 minutes to reach the installer screen.

**CONFIRMED July 15 2026**: After 20+ minutes of VNC connection, the server was STILL only sending SetColourMapEntries (type 1) — no FramebufferUpdate (type 0). CPU usage pattern: started at 100-180%, dropped to ~12% after ~25 minutes. Memory steady at ~7.9GB. Despite the raw Python VNC client not receiving FramebufferUpdate, the USER connected with a real VNC client and confirmed the VM was visible ("its good i saw it"). This means full VNC clients (TigerVNC, TightVNC, macOS Screen Sharing, etc.) can negotiate the display properly even when a minimal Python RFB client cannot — the issue is the client implementation, not the VNC server. **Do NOT assume VNC is broken just because a Python script can't get FramebufferUpdate — always test with a real VNC client first.**

### QEMU 10.1.2 VNC handshake details (confirmed working)

Working Python VNC client handshake for QEMU 10.1.2:
1. Connect to port 5999 (or whatever host port maps to container 5901)
2. Read 12 bytes: `b'RFB 003.008\n'`
3. Send `b'RFB 003.008\n'`
4. Read 1 byte (num_security_types), then that many bytes (types list — typically `[1]` = None)
5. Send `\x01` (select None auth)
6. Read 4 bytes (auth result — `\x00\x00\x00\x00` = success)
7. Send `\x01` (shared flag)
8. Read 24 bytes: width (2), height (2), name_len (4), then name bytes (typically `b'QEMU'`)
9. Set pixel format with true-color=1 (16 bytes after 4-byte header)
10. Set encoding to raw
11. Request FramebufferUpdate — but don't expect data until the display is ready

**Key**: Set `true-color=1` (NOT 0) in the pixel format to avoid receiving color map data instead of raw pixels. QEMU VNC sends `SetColourMapEntries` (type 1) when true-color is 0 or unset.

**PITFALL — Python raw VNC client may NEVER get FramebufferUpdate, but real VNC clients work fine.** A minimal Python socket-based VNC client successfully completes the RFB handshake (version, auth, screen 1920x1080, name "QEMU") and receives SetColourMapEntries (1542 bytes), but FramebufferUpdate (type 0) never arrives even after 20+ minutes with true-color=1 set. Meanwhile, a real VNC client (TigerVNC Viewer, macOS Screen Sharing, etc.) connects and displays the VM screen immediately. This is a client implementation issue — QEMU's VNC server uses extensions/encodings that minimal Python clients don't negotiate properly. **Always test VNC with a real VNC client (tigervnc-viewer, vncsnapshot, or noVNC) — do NOT assume VNC is broken based on a Python socket script alone.**

### PITFALL — Container crash loop vs stable boot — check `docker ps` status duration

If the container shows "Up X seconds" repeatedly (dying within 30-60s), it's a crash loop — check `docker logs` for the crash cause (usually ALSA audio or GTK display). If it shows "Up X minutes" steadily, the VM is booting. CPU usage pattern is a good diagnostic:
- **100-180% CPU** = OpenCore/EFI phase or macOS actively installing (heavy)
- **30-40% CPU** = macOS boot sequence (moderate)
- **10-15% CPU** = macOS idle/waiting (light — may be at installer screen waiting for input)

Memory should climb from ~3GB to ~7-8GB as macOS loads. If memory plateaus at <2GB, the VM likely failed to boot.

### Working Docker Run Command (CONFIRMED July 15 2026 — VNC handshake verified, real VNC client confirmed display)

## Hermes Integration (Both)

### BlueBubbles
```bash
hermes gateway setup  # select BlueBubbles
# or manual .env: BLUEBUBBLES_SERVER_URL, BLUEBUBBLES_PASSWORD
hermes gateway restart
```

### Photon
```bash
hermes photon setup --phone +1YOUR_NUMBER  # one command
hermes gateway start
```

### Running Both (Hybrid)
- Both adapters can run simultaneously
- BlueBubbles for full features, Photon as fallback
- Both deliver to the same Finn agent

## Architecture Comparison

BlueBubbles: iMessage ↔ Messages.app (Mac/VM) ↔ BlueBubbles Server ↔ Hermes
Photon: iMessage ↔ Photon managed service ↔ gRPC stream ↔ Node sidecar ↔ Hermes

## Recommendation
1. Start with Photon (5 min, no Mac, free)
2. Add BlueBubbles VM later if full self-hosting desired
3. Run both for redundancy

## Photon Status Check
```bash
hermes photon status
# Shows: device token, dashboard project, spectrum project, assigned number, sidecar health
```