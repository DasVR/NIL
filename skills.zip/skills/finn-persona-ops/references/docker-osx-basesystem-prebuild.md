# Docker-OSX: Host-Side BaseSystem.img Pre-Build

When the Docker-OSX container keeps crashing/restarting before the macOS Recovery download finishes, pre-build `BaseSystem.img` on the HOST instead of fighting the container's restart loop.

## When to Use This

- Container logs show `No BaseSystem.img available, downloading ventura` repeating every 1-2 minutes
- The download gets 30-80% done then the container dies and restarts from zero
- `docker ps` shows the container as "Up X seconds" (recently restarted) repeatedly
- No restart policy is set (`docker inspect --format '{{.HostConfig.RestartPolicy.Name}}'` returns `no`) — the container's entrypoint script itself is exiting

## Root Cause

The docker-osx entrypoint script runs `make` + `fetch-macOS-v2.py` + `qemu-img convert` in sequence. If any step fails or the container is OOM-killed mid-download, the whole script restarts from scratch. The 678MB Ventura download (~843MB for Sequoia) at ~1MB/s takes 10+ minutes, and repeated restarts never let it finish.

## Solution: Pre-Build on Host

### Step 1: Extract the fetch script from the Docker image
```bash
sg docker -c "docker create --name osx-fetch sickcodes/docker-osx:latest"
sg docker -c "docker cp osx-fetch:/home/arch/OSX-KVM/fetch-macOS-v2.py /home/das/bluebubbles/fetch-macOS-v2.py"
sg docker -c "docker rm osx-fetch"
```

### Step 2: Download BaseSystem.dmg on the host
```bash
cd /home/das/bluebubbles
pip3 install --user tqdm  # fetch script needs tqdm
python3 fetch-macOS-v2.py --shortname=ventura
# Downloads BaseSystem.dmg (~678MB) + BaseSystem.chunklist (~2.7KB) to CWD
```

### Step 3: Convert to qcow2 on the host
```bash
qemu-img convert BaseSystem.dmg -O qcow2 -p -c BaseSystem.img
# qemu-img is already installed on the host at /usr/bin/qemu-img
# Produces BaseSystem.img (~743MB qcow2, compressed)
```

### Step 4: Cache for container reuse
```bash
mkdir -p /home/das/bluebubbles/osx-cache
cp BaseSystem.img /home/das/bluebubbles/osx-cache/BaseSystem.img
```

### Step 5: Start the VM with cached image
```bash
cd /home/das/bluebubbles
sg docker -c "bash start-bluebubbles.sh vnc"
# Script detects osx-cache/BaseSystem.img and bind-mounts it into the container
# Container skips download entirely, goes straight to OpenCore setup → QEMU boot
```

## What Happens After (Default Entrypoint)

With the cached BaseSystem.img mounted and the default entrypoint, the container:
1. Skips the download step entirely (detects BaseSystem.img exists)
2. Runs `generate-unique-machine-values.sh` (clones OpenCorePkg, compiles macserial — ~30s)
3. Uses libguestfs to inject serial numbers into OpenCore boot disk (~2-3 min, shows `guestfsd: receive_file` spam in logs)
4. Launches the actual QEMU VM with VNC

**BUT**: Step 3 (libguestfs/supermin) can crash-loop on some hosts, preventing the VM from ever booting. If this happens, use the **Entrypoint Bypass** below.

## Entrypoint Bypass (✅ WORKING — July 11 2026)

If `GENERATE_UNIQUE=true` causes libguestfs/supermin to crash in a loop (container keeps restarting, `docker logs` shows `supermin: warning` / `guestfsd:` lines then exit), bypass the entire entrypoint:

```bash
docker run -d \
  --name macos-vm2 \
  --device /dev/kvm \
  -p 5999:5999 -p 50922:10022 -p 1234:1234 \
  -v /home/das/bluebubbles/maindisk.qcow2:/image \
  -v /home/das/bluebubbles/osx-cache/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img \
  -e IMAGE_PATH=/image \
  -e EXTRA='-display none -vnc 0.0.0.0:99,password=off' \
  --entrypoint /bin/bash \
  sickcodes/docker-osx:latest \
  -c 'sudo chown -R $(id -u):$(id -g) /dev/kvm /dev/snd /image 2>/dev/null || true; cd /home/arch/OSX-KVM && exec ./Launch.sh'
```

### Why This Works

- **Skips ALL entrypoint steps**: No download, no OpenCore rebuild, no serial generation, no libguestfs
- **Goes straight to QEMU**: `Launch.sh` just runs `qemu-system-x86_64` with the existing OpenCore.qcow2 + BaseSystem.img + maindisk
- **Boots in ~10 seconds** (vs 5+ min with entrypoint, or infinite loop if libguestfs crashes)
- **Default OpenCore boot disk works fine**: The pre-built `OpenCore.qcow2` in the container image has working defaults — serial numbers aren't needed for first-time macOS install
- **Container name `macos-vm2`**: Avoids conflicts with any auto-recreating `macos-vm` containers from previous attempts

### Monitoring for VM Boot

After starting with entrypoint bypass, QEMU starts within ~10s. Verify:
```bash
# Check QEMU is running (should show 1 process with -vnc in args)
docker exec macos-vm2 bash -c 'pgrep -la qemu'

# Check VNC is serving (port 5999)
docker exec macos-vm2 bash -c 'ss -tlnp | grep 5999'

# Container should be stable (Up for minutes, not seconds)
docker ps --filter name=macos-vm2 --format '{{.Status}}'
```

## Key Details

- **qemu-img is on the host**: `/usr/bin/qemu-img` — no need to run conversion inside a container
- **fetch-macOS-v2.py needs tqdm**: `pip3 install --user tqdm` before running
- **Do NOT mount a host dir over `/home/arch/OSX-KVM`**: This overwrites the container's built-in Makefile, scripts, OpenCore, serial-generator, etc. Only bind-mount the specific cached file: `-v "$CACHE/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img"`
- **Container still needs to run OpenCore setup** (default entrypoint only): Even with cached BaseSystem.img, the container still builds OpenCore + generates serial numbers (~3-5 min). This is normal — wait for it. If it crashes, use the entrypoint bypass above.
- **libguestfs QEMU is not the VM** (default entrypoint only): During OpenCore setup, a temporary QEMU process runs (libguestfs) to modify the boot disk. This shows up in `pgrep qemu` but is NOT the macOS VM. The real VM starts after this step completes.
- **With entrypoint bypass, there's no libguestfs step** — QEMU starts immediately with the default OpenCore.qcow2

## Files

- `start-bluebubbles.sh` — Updated script with cache detection + entrypoint bypass as default
- `osx-cache/BaseSystem.img` — Cached recovery image (743MB)
- `osx-cache/env` — Optional: cached serial number env file (if generated)
- `BaseSystem.dmg` — Original download (can be deleted after conversion)
- `fetch-macOS-v2.py` — Extracted fetch script (can be kept for re-use)