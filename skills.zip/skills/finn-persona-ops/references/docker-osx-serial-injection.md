# Docker-OSX Serial Number Injection for iMessage

## Problem
iMessage falls back to SMS (green bubbles) when Apple's servers don't recognize the Mac's hardware identifiers (serial number, board serial, hardware UUID, MAC address). The default OpenCore boot disk has placeholder values that Apple rejects. This is the #1 issue with Hackintosh/Docker-OSX iMessage activation.

## When This Applies
- Docker-OSX VM is running and macOS is installed
- iMessage shows green bubbles (SMS) instead of blue (iMessage)
- `GENERATE_UNIQUE=true` was skipped (to avoid libguestfs crash loop)
- You need valid serial numbers without re-enabling the full entrypoint

## Prerequisites
- Docker-OSX container running (e.g. `bbubbles`)
- `osx-serial-generator` directory extracted from the container image
- `guestfish` available inside the container (NOT on host)

## Step-by-Step

### 1. Extract serial generator scripts (one-time)
```bash
docker create --name osx-temp sickcodes/docker-osx:latest
docker cp osx-temp:/home/arch/OSX-KVM/Docker-OSX/osx-serial-generator ./osx-serial-generator
docker rm osx-temp
```

### 2. Generate serial numbers on the host
```bash
cd /home/das/bluebubbles
bash osx-serial-generator/generate-unique-machine-values.sh \
  --count 1 \
  --tsv ./serial.tsv \
  --model iMacPro1,1
```
This clones OpenCorePkg, builds `macserial`, and outputs:
- DEVICE_MODEL: iMacPro1,1
- SERIAL: C02GDGYJHX87
- BOARD_SERIAL: C02137700QXJG368C
- UUID: 01B5E200-7C3B-4BBA-9FA5-965DA9D4540F
- MAC_ADDRESS: AC:90:85:E5:BC:08

To generate multiple sets (recommended — some serials don't pass Apple's check):
```bash
bash osx-serial-generator/generate-unique-machine-values.sh \
  --count 10 \
  --tsv ./serial_sets.tsv \
  --model iMacPro1,1
```

### 3. Build custom OpenCore boot disk (INSIDE the running container)
The `generate-specific-bootdisk.sh` script requires `guestfish` (libguestfs), which is only available inside the Docker-OSX container, NOT on the host.

```bash
docker exec bbubbles bash -c 'cd /home/arch/OSX-KVM && \
  ./Docker-OSX/osx-serial-generator/generate-specific-bootdisk.sh \
  --model iMacPro1,1 \
  --serial C02GDGYJHX87 \
  --board-serial C02137700QXJG368C \
  --uuid 01B5E200-7C3B-4BBA-9FA5-965DA9D4540F \
  --mac-address AC:90:85:E5:BC:08 \
  --width 1920 \
  --height 1080 \
  --output-bootdisk /home/arch/OSX-KVM/OpenCore-custom.qcow2 \
  --output-env /env'
```

**CRITICAL**: Write to a NEW file (`OpenCore-custom.qcow2`), NOT the default `OpenCore.qcow2` — the default is locked by the running QEMU process. Attempting to overwrite it gives: `Failed to get "write" lock Is another process using the image?`

### 4. Copy custom boot disk to host
```bash
docker cp bbubbles:/home/arch/OSX-KVM/OpenCore-custom.qcow2 \
  /home/das/bluebubbles/OpenCore-custom.qcow2
```

### 5. Stop VM and restart with custom boot disk
```bash
docker kill bbubbles; docker rm -f bbubbles

docker run -d \
  --name bbubbles \
  --device /dev/kvm \
  -p 5999:5999 -p 50922:10022 \
  -v /home/das/bluebubbles/maindisk.qcow2:/image \
  -v /home/das/bluebubbles/osx-cache/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img \
  -v /home/das/bluebubbles/OpenCore-custom.qcow2:/home/arch/OSX-KVM/OpenCore/OpenCore.qcow2 \
  -e IMAGE_PATH=/image \
  -e EXTRA='-display none -vnc 0.0.0.0:99,password=off' \
  --entrypoint /bin/bash \
  sickcodes/docker-osx:latest \
  -c 'sudo chown -R $(id -u):$(id -g) /dev/kvm /image 2>/dev/null || true; cd /home/arch/OSX-KVM && sed -i "/audiodev/d; /ich9-intel-hda/d; /hda-duplex/d" Launch.sh && exec ./Launch.sh'
```

Key difference from the standard start command: the `-v OpenCore-custom.qcow2:/home/arch/OSX-KVM/OpenCore/OpenCore.qcow2` mount replaces the default boot disk with the custom one containing valid serials.

### 6. Verify iMessage activation
1. VNC in (192.168.1.99:5999 or http://192.168.1.99:8081)
2. Sign in with Apple ID in System Settings
3. Open Messages app, send a test to a real phone number
4. Check if the bubble is BLUE (iMessage) not GREEN (SMS)
5. If still green, the serial may be flagged by Apple — generate a new set and try again

## Serial Validation via checkcoverage.apple.com (CRITICAL — do this BEFORE injection)

macserial generates random serials with valid FORMAT but they may not exist in Apple's production database. Apple's iMessage activation servers verify the serial against their database — if it's not a real produced Mac, iMessage falls back to SMS (green bubble) and shows "Please enter valid serial number" errors.

**Verification workflow (do this BEFORE injecting serials into the boot disk):**

1. Generate 10+ serials: `bash osx-serial-generator/generate-unique-machine-values.sh --count 10 --tsv ./serial_sets.tsv --model iMacPro1,1`
2. For each serial, go to https://checkcoverage.apple.com and enter it
3. If it says "Please enter a valid serial number" → that serial does NOT exist in Apple's database → SKIP IT
4. If it says "Valid Purchase Date" or shows warranty info → that serial IS in Apple's database → USE IT
5. Only inject serials that pass the checkcoverage validation

**CONFIRMED July 12 2026**: Serial C02GDGYJHX87 (generated by macserial for iMacPro1,1) was entered at checkcoverage.apple.com and returned "The serial number you've entered isn't valid. Please try again." — confirming it's NOT in Apple's production database. iMessage activation failed with this serial (green bubble / SMS fallback). The serial C02G12345678 was also tried and likely also invalid.

**Key insight**: The macserial tool creates serials with the correct FORMAT for the model (e.g. C02 prefix for iMacPro1,1) but they're random combinations that were never assigned to a real Mac. Apple's servers check if the serial was actually manufactured. You need a serial from a REAL iMacPro1,1 that's no longer in active use, or you need to get lucky with random generation and verify via checkcoverage first.

## GENERATE_SPECIFIC Pitfall (CONFIRMED July 15 2026)

**GENERATE_SPECIFIC=true does NOT reliably use provided env vars.** When passing `GENERATE_SPECIFIC=true` with `DEVICE_MODEL="iMac15,1"`, `SERIAL="C02PV08WFY14"`, `BOARD_SERIAL="C02PV08WFY14JG36UE"`, the container's entrypoint ran `generate-specific-bootdisk.sh` but the resulting `config.plist` inside the OpenCore qcow2 contained DIFFERENT values:
- SystemProductName: `iMacPro1,1` (should be `iMac15,1`)
- SystemSerialNumber: `C02FPBZPHX87` (random, not our `C02PV08WFY14`)
- MLB: `C02119700QXJG36JC` (random, not our `C02PV08WFY14JG36UE`)
- SystemUUID: `213FA768-A62C-4299-8598-47AA666E436F` (random)

The env vars were either ignored or overridden by the script's internal logic. **DO NOT trust GENERATE_SPECIFIC to inject serials correctly — ALWAYS verify the config.plist after generation.**

**Fix**: Use the `qemu-nbd` host-mount method (see "Failed Approaches" section, method B) to manually edit the config.plist with the correct values, then restart the container WITHOUT `GENERATE_SPECIFIC` (so it doesn't overwrite your edits).

## iMessage Activation Error "Unknown Error" (July 15 2026)

When iMessage shows "An unknown error occurred" during Apple ID sign-in, it means the serial/MLB combination is being rejected by Apple's activation servers. The serial C02PV08WFY14 IS a real iMac serial (confirmed by user finding it on a Mac sold for parts), but:
1. The MLB (board serial) was guessed as `C02PV08WFY14JG36UE` — this is almost certainly WRONG. Apple cross-references serial + MLB together. If the MLB doesn't match what Apple has on file for that serial, activation fails.
2. The Mac may still be registered to someone else's Apple ID, which could block activation.

**To fix**: Need the actual MLB from the physical Mac. Ask the seller to run `system_profiler SPHardwareDataType` and provide the "Board Serial Number" (that's the MLB). Without the correct MLB, iMessage activation will fail even with a valid serial number.

**To verify serial is correctly injected in macOS**: Open Terminal inside the VM and run `system_profiler SPHardwareDataType` — check that the serial number and model identifier match what was set in config.plist.

## Apple checkcoverage.apple.com API Research (July 12 2026)

**Programmatic serial checking NO LONGER WORKS** — Apple added captcha protection.

API findings:
- Endpoint: `POST https://checkcoverage.apple.com/api/v1/captchaValidate?locale=en_US`
- CSRF header: `X-Apple-Csrf-Token` (from `<meta name="csrf-token" content="...">` in HTML)
- Token is a JWT (~227 chars)
- Body: `{"serialInput": "<serial>", "answer": "<captcha_answer>", "captchaType": "IMAGE"}`
- Without a valid captcha answer, returns 400: `{"error":{"token":"CCW400","message":"Please enter the valid captcha."}}`
- Without the CSRF header, returns 403: `{"error":"No CSRF header found in API request","errorCode":"API_NO_CSRF_HEADER"}`
- Old endpoint `/api/v1/check` returns 403: `{"error":"Unhandled Path: /api/v1/check"}`

The JS bundles reveal: the page is a Next.js app, captcha is required before serial validation, the CSRF token comes from `document.querySelector('meta[name="csrf-token"]')`.

**A Python script was written** at `/home/das/bluebubbles/serial-checker.py` to batch-check serials, but it cannot bypass the captcha. Would need a captcha-solving service to work. Left in place for future reference.

## Serial Number Strategy (UPDATED July 14 2026)

### Best Approach: Real Serial from a Physical Mac
The most reliable path to iMessage activation is using a serial number from a REAL Mac that was actually manufactured. Random macserial serials are syntactically valid but NOT in Apple's production database — iMessage silently fails with "not delivered" and NO customer code popup.

**Sources for real serials:**
- eBay/Craigslist listings for Macs "sold for parts" — the serial is often visible in listing photos
- Old/dead Macs you or friends/family own
- Mac repair shops that have dead logic boards

**Example (July 14 2026)**: User found a Mac Mini being sold for parts with serial `C02PV08WFY14` visible in the listing. This serial IS in Apple's database because it was a real manufactured Mac.

### To inject a real serial:
Use the same `generate-specific-bootdisk.sh` + guestfish method (Step 3 above), but pass the real serial instead of a macserial-generated one:
```bash
docker exec bbubbles bash -c 'cd /home/arch/OSX-KVM && \
  ./Docker-OSX/osx-serial-generator/generate-specific-bootdisk.sh \
  --model iMacPro1,1 \
  --serial C02PV08WFY14 \
  --board-serial <derived_board_serial> \
  --uuid <generated_uuid> \
  --mac-address <mac> \
  --width 1920 --height 1080 \
  --output-bootdisk /home/arch/OSX-KVM/OpenCore-custom.qcow2'
```

Note: The board serial, UUID, and MAC can still be generated — only the main SystemSerialNumber needs to be the real one from the physical Mac.

## Failed Approaches to Editing OpenCore Config (July 14 2026)

**DO NOT attempt these — they do NOT work:**

1. **`qemu-nbd --connect` + `mount` inside container**: Requires root + nbd kernel module. Even as root inside the container, mount fails. The qcow2 format + FAT16 EFI partition + container environment makes this unreliable.

   **HOWEVER — `qemu-nbd` on the HOST works (CONFIRMED July 15 2026)**: Running `sudo modprobe nbd max_part=8` + `sudo qemu-nbd --connect=/dev/nbd0 <qcow2>` + `sudo mount /dev/nbd0p1 /tmp/opencore-mount` on the HOST successfully mounts the EFI partition (partition 1, 145MB, type ESP). The config.plist at `/tmp/opencore-mount/EFI/OC/config.plist` can be edited with `sed`, verified with `grep`, then `sudo umount /tmp/opencore-mount` + `sudo qemu-nbd --disconnect /dev/nbd0`. This is now the PREFERRED method for manual config.plist editing. After editing, mount the qcow2 as a Docker volume (`-v /tmp/OpenCore-nopicker.qcow2:/home/arch/OSX-KVM/OpenCore/OpenCore-nopicker.qcow2`) when restarting the container.

   **Full working sequence**:
   ```bash
   # Stop the VM
   docker stop bluebubbles-vm
   # Copy qcow2 out
   docker cp bluebubbles-vm:/home/arch/OSX-KVM/OpenCore/OpenCore-nopicker.qcow2 /tmp/OpenCore-nopicker.qcow2
   # Mount on host
   sudo modprobe nbd max_part=8
   sudo qemu-nbd --connect=/dev/nbd0 /tmp/OpenCore-nopicker.qcow2
   sleep 2
   sudo mkdir -p /tmp/opencore-mount
   sudo mount /dev/nbd0p1 /tmp/opencore-mount
   # Edit config.plist
   sudo sed -i 's|iMacPro1,1|iMac15,1|g' /tmp/opencore-mount/EFI/OC/config.plist
   sudo sed -i 's|OLD_SERIAL|C02PV08WFY14|g' /tmp/opencore-mount/EFI/OC/config.plist
   # Verify
   sudo grep -A1 "SystemProductName\|SystemSerialNumber\|MLB\|SystemUUID" /tmp/opencore-mount/EFI/OC/config.plist
   # Cleanup
   sudo umount /tmp/opencore-mount
   sudo qemu-nbd --disconnect /dev/nbd0
   # Restart container with edited qcow2 as volume (NO GENERATE_SPECIFIC)
   docker rm -f bluebubbles-vm
   docker run -d --name bluebubbles-vm --device /dev/kvm \
     -p 50922:10022 -p 5999:5901 \
     -e NOPICKER=true -e RAM=8 -e AUDIO_DRIVER=none \
     -e SCREEN_SHARE_PORT=5900 -e "EXTRA=-vnc :1" \
     -v /home/das/bluebubbles/maindisk.qcow2:/home/arch/OSX-KVM/mac_hdd_ng.img \
     -v /home/das/bluebubbles/BaseSystem.img:/home/arch/OSX-KVM/BaseSystem.img \
     -v /tmp/OpenCore-nopicker.qcow2:/home/arch/OSX-KVM/OpenCore/OpenCore-nopicker.qcow2 \
     sickcodes/docker-osx:latest
   ```

   **PITFALL — `docker cp` to stopped container may not persist.** `docker cp /tmp/OpenCore-nopicker.qcow2 bluebubbles-vm:/home/arch/OSX-KVM/OpenCore/OpenCore-nopicker.qcow2` appeared to succeed but the file inside the container still showed old timestamp and values. Always use `-v` volume mount instead of `docker cp` for swapping boot disks.

2. **`sed` on `config-custom.plist` template**: The template at `/home/arch/OSX-KVM/config-custom.plist` has `{{SERIAL}}` placeholders. Editing these with `sed` does NOT change the running config — the actual config is baked into the `OpenCore.qcow2` disk image. The template is only used by the entrypoint script during initial generation (which we bypass with `--entrypoint /bin/bash`).

3. **`docker exec` with nested quoting**: `newgrp docker << 'ENDGRP' ... docker exec bbubbles bash -c "grep 'serial' ..."` fails with `unexpected EOF while looking for matching quote` due to triple-layer shell quoting (newgrp → docker exec → bash -c). See the nested quoting pitfall in the main SKILL.md.

4. **Mounting qcow2 while VM is running**: The file is locked by QEMU. You get `Failed to get "write" lock Is another process using the image?`. Must stop the VM first.

**THE ONLY WORKING METHOD**: `generate-specific-bootdisk.sh` inside the container (uses guestfish/libguestfs which IS available there). This creates a NEW OpenCore-custom.qcow2 with the serial baked into config.plist. Then stop the VM, mount the new boot disk, and restart.

## Pitfalls

- **guestfish not on host**: The `generate-specific-bootdisk.sh` script calls `guestfish` which is only in the container. Running it on the host fails with `guestfish: command not found`. Must run inside the container via `docker exec`.

- **OpenCore.qcow2 locked**: Can't overwrite the boot disk while QEMU is running. Always write to a new file and swap after stopping the VM.

- **Random serials may not pass Apple's check**: Generated serials are random combinations of valid format. Apple may reject some. **ALWAYS verify at checkcoverage.apple.com BEFORE injecting.** Generate 10+ and try different ones if the first doesn't work. See "Serial Validation" section above.

- **`--output-env` flag**: The `generate-specific-bootdisk.sh` script doesn't support `--output-env` (shows "Invalid option"). The env file is optional — the serials are baked into the boot disk qcow2 itself.

- **Container name conflicts**: Old containers (`macos-vm`, `macos-vm2`) may keep respawning. Use a unique name like `bbubbles`. Check `docker ps --format '{{.Names}} {{.Ports}}' | grep 5999` for port conflicts.

- **macOS install persists in maindisk.qcow2**: The serial injection only affects the OpenCore boot disk (hardware identifiers). The macOS installation, user accounts, and apps live in `maindisk.qcow2` which is unchanged. You don't need to reinstall macOS after swapping boot disks.

- **NESTED SHELL QUOTING — THE #1 GOTCHA (confirmed July 12 2026)**: Running `sg docker -c "docker exec bbubbles bash -c '...'"` with ANY double quotes inside the inner bash command causes `eval: line N: unexpected EOF while looking for matching` quote. This caused a 15x+ tool loop trying to inspect config.plist inside the container. **ALWAYS use `docker cp` to copy files OUT of the container and inspect them on the host with `read_file` or `search_files` instead of grepping inside the container through nested shells.** If you MUST exec into the container, write a script file, `docker cp` it in, and run `docker exec bbubbles bash /tmp/script.sh`.

## Verifying Serial Numbers Are Injected (CONFIRMED WORKING July 12 2026)

After injecting serials, verify they are actually in the config.plist by reading it back using guestfish inside the container. **Do NOT try to grep inside the container through nested shells** — use the provided script instead.

### Using the verification script (recommended)

```bash
# Copy the script into the container
docker cp ~/.hermes/skills/autonomous-ai-agents/finn-persona-ops/scripts/extract-opencore-config.sh bbubbles:/tmp/extract-config.sh

# Run it and filter for serial-related keys
docker exec bbubbles bash /tmp/extract-config.sh 2>/dev/null | grep -A1 "SystemSerialNumber\|MLB\|SystemUUID\|SystemProductName"
```

Expected output (if serials are correctly injected):
```
<key>MLB</key>
    <string>C02137700QXJG368C</string>
<key>SystemProductName</key>
    <string>iMacPro1,1</string>
<key>SystemSerialNumber</key>
    <string>C02G12345678</string>
<key>SystemUUID</key>
    <string>01B5E200-7C3B-4BBA-9FA5-965DA9D4540F</string>
```

### How it works

The script uses `guestfish --ro` to read the qcow2 boot disk:
1. Opens the qcow2 read-only (no lock conflict with running QEMU)
2. Boots a mini guestfs VM to mount the qcow2 partitions
3. Mounts `/dev/sda1` (the EFI partition, labeled "EFI")
4. Reads `/EFI/OC/config.plist` and prints to stdout

The OpenCore boot disk has two partitions:
- `sda1` (145MB, FAT16, label "EFI", type ESP) — contains `EFI/OC/config.plist`
- `sda2` (236MB, FAT16, label "OpenCore") — additional OpenCore data

**CONFIRMED July 12 2026**: This technique successfully verified that serials C02G12345678 and C02GDGYJHX87 were both correctly injected into the config.plist. The iMessage activation issue was NOT an injection problem — it was that the serials are not in Apple production database (confirmed via checkcoverage.apple.com).

## Files
- `/home/das/bluebubbles/serial.tsv` — generated serial numbers
- `/home/das/bluebubbles/osx-serial-generator/` — serial generation scripts (extracted from container)
- `/home/das/bluebubbles/OpenCore-custom.qcow2` — custom boot disk with valid serials
- `/home/das/bluebubbles/maindisk.qcow2` — macOS install target (unchanged by serial injection)
- `/home/das/bluebubbles/osx-cache/BaseSystem.img` — cached macOS recovery image (unchanged)