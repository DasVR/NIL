# Model Router v4 — Semantic + Lexical Complexity Detection

Rebuilt July 31, 2026. Replaces the old keyword-only router with real complexity analysis, multi-role model assignment, and **semantic embedding scoring** for category-aware routing.

## What Changed

### Old Router (v1)
- Keyword matching only: if message contains "code" → escalate to main model
- Binary routing: fast model (ministral-3:8b) or main model (glm-5.2)
- No task category detection, no complexity scoring

### Router v2 (lexical complexity)
- **Complexity scoring (0-100)** based on: word count, code detection, multi-step indicators, tool requirements, math/research markers, creative intent, casual patterns
- **6 task categories**: casual, coding, reasoning, creative, complex, unknown
- **Zero added latency** — all analysis is pure Python string ops

### Router v4 (semantic + lexical) — Current
- **Semantic scoring** via nomic-embed-text embeddings against category centroids (Ollama localhost:11434)
- **Dual-signal routing**: lexical score + semantic confidence combine for category selection
- **Override system**: strong semantic matches (>0.72) override lexical decisions; moderate matches (>0.60) nudge the score
- **Same zero-LLM-call guarantee** — embeddings are cheap local calls to Ollama, no cloud LLM needed for classification
- **Context size check** — won't route to small models if context >100K tokens

## Model Role Assignments (July 31, 2026 — current)

| Role | Model | Provider | Why |
|------|-------|----------|-----|
| Casual chat | deepseek-v4-flash | ollama-cloud | Fast, natural, consistent |
| Coding | kimi-k2.7-code | ollama-cloud | Best code quality on ollama-cloud |
| Reasoning | nemotron-3-ultra | ollama-cloud | Fast research, efficient |
| Creative | deepseek-v4-pro | ollama-cloud | Good writing/creative |
| Complex | kimi-k2.6 | ollama-cloud | Best tool calling, fast |
| Classifier | deepseek-v4-flash | ollama-cloud | Quick intent detection |
| Memory | deepseek-v4-flash | ollama-cloud | Fast, consistent |
| Default fallback | kimi-k2.6 | ollama-cloud | Main model |

### v3 → v4 Changes
- **Casual**: deepseek-v4-flash (replaces glm-5.2 — better persona consistency)
- **Coding**: kimi-k2.7-code (replaces qwen3-coder-next — not available on ollama-cloud)
- **Reasoning**: nemotron-3-ultra (replaces devstral-2:123b — not available on ollama-cloud)
- **Complex**: kimi-k2.6 (replaces qwen3-coder-next — not available on ollama-cloud)

---

### Plugin YAML Hook Name Mismatch (July 31, 2026 — THIS SESSION)
**Symptom:** Router code exists, complexity analysis works, logs show nothing. Casual messages always hit main model.

**Root cause:** `plugin.yaml` declared `provides_hooks: [pre_turn_context_build]` but `__init__.py` calls `ctx.register_hook("pre_llm_call", on_pre_llm_call)`. The hook name in the manifest must match the hook name in the registration call exactly. Mismatch = Hermes never wires the hook = plugin code never runs.

**Fix:** Align `plugin.yaml` with the code:
```yaml
provides_hooks:
  - pre_llm_call
```

**Verification:** After `/restart`, grep `~/.hermes/logs/gateway.log` for `hermes-model-router: REGISTERING` and `hermes-model-router: routed to`. If you see registration but no routing, the hook name mismatch is the culprit.

### Model Gets Clobbered After Routing — REVISED (July 31, 2026 session)
**Symptom:** Logs show `routed to deepseek-v4-flash (category=casual, score=0, ...)` but the footer shows `kimi-k2.6`.

**Initial hypothesis (WRONG):** `_restore_primary_runtime()` at `turn_context.py:174` was suspected of reverting the model after the hook. **This is incorrect** — `_restore_primary_runtime()` runs **BEFORE** the `pre_llm_call` hook, not after.

**Corrected trace findings:**
1. Router hook fires → changes `agent.model` to target model (e.g., deepseek-v4-flash) ✅
2. `build_api_kwargs` reads `agent.model` → IS the routed model ✅
3. Transport `build_kwargs` receives the routed model → IS the routed model ✅
4. API call goes out with routed model ✅
5. **Gateway footer at `run.py:11902` reads `_resolve_gateway_model()` → reads `config.yaml` `model.default` = k2.6 ❌**

**Root cause:** The gateway footer is a **DISPLAY bug only**. It renders `config.yaml` `model.default` instead of the live `agent.model`. The actual LLM call correctly uses the routed model. Response speed confirms this — casual queries routed to deepseek-v4-flash return in ~1-2s vs k2.6's ~5-10s.

**Fix applied:** Patched `gateway/run.py` `_render_model_footer()` to prefer live `agent.model`:
```python
live_model = model
if agent is not None:
    _agent_model = getattr(agent, "model", None)
    if _agent_model:
        live_model = _agent_model
lines = [f"◆ Model: `{live_model}`", ...]
```

**Instrumentation added:**
- Router: `BEFORE model=X provider=Y` and `AFTER model=X provider=Y` logging
- `build_api_kwargs`: `[API-KWARGS] model=X provider=Y` logging
- Transport `build_kwargs`: `[TRANSPORT-BUILD] model=X` logging

**Verification after restart:**
```bash
grep -E "BEFORE model=|AFTER model=|\[API-KWARGS\]|\[TRANSPORT-BUILD\]" ~/.hermes/logs/agent.log
# Should show: BEFORE=k2.6 → AFTER=deepseek-v4-flash → API-KWARGS=deepseek-v4-flash → TRANSPORT-BUILD=deepseek-v4-flash
```

**If routing still doesn't work after hook-name fix:**
- Check that `pre_llm_call` is in `plugin.yaml` `provides_hooks` — must match registration exactly
- Check that the router plugin loads without import errors
- Add `logger.info("%s: REGISTERING", PLUGIN_NAME)` in `register()` to confirm plugin loads
- The hook receives `agent` via `kwargs.get("agent")` — if this is None, the router falls back to stack inspection which may find the wrong object

---

## July 31, 2026 Plugin Audit & Fixes

### Casual Detection Bug
**Symptom:** "got ur plugins?" (3 words, clearly casual) routed to `coding` because:
- `has_tools_hint` triggered on the "plugins" keyword (+15 score)
- `is_casual` was false: "ur" only matched as substring, not exact/prefix
- Score = 21, category = coding → burned `kimi-k2.7-code` tokens

**Fixes applied:**
1. Added `_contains_casual_marker()` helper that checks for casual markers **anywhere** in short messages (`word_count <= 8`), not just at start/exact match
2. Raised casual threshold: `is_casual and (score < 30 or (word_count <= 8 and not has_code))` — was `< 20`
3. Short casual messages now override weak tool hints (single keywords like "plugins" alone don't force coding)

### Invalid Hardcoded Fallback Models
**Symptom:** `model_map` in `__init__.py` contained models that don't exist on ollama-cloud:
- `gemma3:4b` → does NOT exist (only `gemma4:31b` exists)
- `qwen3-coder-next` → does NOT exist on ollama-cloud

**Fix:** Updated hardcoded fallbacks to verified models from July 30, 2026 cache:
- casual: `glm-5.2`
- coding: `kimi-k2.7-code`
- reasoning: `nemotron-3-ultra` (already valid)
- creative: `deepseek-v4-pro`
- complex: `gemma4:31b` (already valid)

Config-level overrides in `config.yaml` were already valid (deepseek-v4-flash, etc.). The bug only hit when config lacked an entry for a category.

### Ollama Cloud Live Model List (July 30, 2026)
18 models confirmed in cache (`~/.hermes/ollama_cloud_models_cache.json`):
`mistral-large-3:675b`, `gemma4:31b`, `nemotron-3-super`, `glm-5.1`, `kimi-k2.6`, `gpt-oss:120b`, `minimax-m3`, `nemotron-3-nano:30b`, `nemotron-3-ultra`, `gpt-oss:20b`, `kimi-k2.7-code`, `qwen3.5:397b`, `deepseek-v4-pro`, `deepseek-v4-flash`, `minimax-m2.5`, `glm-5.2`, `kimi-k2.5`, `minimax-m2.7`

### Token-Router Ollama-Cloud Provider Gap
**Symptom:** `hermes-token-router` logged `unknown router_provider 'ollama-cloud'` and fell back to deterministic rules (less accurate than LLM-based prediction).

**Root cause:** `_get_router_client()` in `policy.py` only supported `deepseek`, `openrouter`, `openai-codex`.

**Fix:** Added ollama-cloud support:
```python
elif router_provider == "ollama-cloud":
    api_key = os.environ.get("OLLAMA_API_KEY", "")
    base_url = os.environ.get("OLLAMA_BASE_URL", "https://ollama.com/v1")
    client = OpenAI(api_key=api_key, base_url=base_url, timeout=10, max_retries=0)
    return client, router_model
```

### Token-Router Config Bugs
- `router_model: glm-5` → invalid model (doesn't exist). Changed to `deepseek-v4-flash`.
- `short_message_bypass_chars: 0` → wrong key. Code reads `short_bypass_chars`. Fixed.

### Verification Path
After `/restart`, casual messages should route to `glm-5.2` or `deepseek-v4-flash` instead of burning `kimi-k2.7-code`. Check `~/.hermes/logs/gateway.log` for `hermes-model-router: routed to ...` entries.