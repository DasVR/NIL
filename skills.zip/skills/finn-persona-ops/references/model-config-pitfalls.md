# Model Config Pitfalls (July 2026)

Quick-reference for config-level issues that break the agent's output quality.

## Message Cutoff / Truncated Responses

**Symptom**: Agent stops mid-sentence, messages feel incomplete, user says "you keep getting cutoff".

**Root Cause**: LLM hits its default max output token limit and stops generating.

**Fix**: Add `max_tokens` under the `model:` section in `~/.hermes/config.yaml`:

```yaml
model:
  default: kimi-k2.6
  provider: ollama-cloud
  max_tokens: 4096
```

- `max_tokens` is OPTIONAL. If omitted, uses the model's default (often too low for long responses).
- 4096 is safe for most use cases. Can go higher if needed.
- If the agent still cuts off after this, verify Discord adapter config.
  Do NOT bump `MAX_MESSAGE_LENGTH` to 4000 — Discord enforces 2000 for bots
  and the July 2024 "patch to 4000" advice is outdated (causes 400 Bad Request).
  See `references/discord-cutoff-fix-2026-08-13.md` for current fixes.

**Tool Limitation**: The `patch` tool refuses to write to `~/.hermes/config.yaml` ("Refusing to write to Hermes config file: Agent cannot modify security-sensitive configuration."). Use `hermes config set` CLI instead, or use `terminal(command="python3 ...")` to modify it safely.

## Humanize Plugin

**Symptom**: User says "remove anything that would delay texting speed", or later explicitly says "remove the humanize plugin entirely".

**Correct Action (August 2026)**: Remove `humanize` from `plugins.enabled` and delete the entire `humanize:` block from config.yaml. The user has now explicitly asked for full removal multiple times. Do NOT suggest keeping it with delays off anymore.

**Why**: Even with `pre_response_delay: false`, the plugin fires `pre_llm_call_memory` hooks and stores assistant messages as memories (known bug). It also adds non-deterministic latency around large responses.

**Previous guidance (July 2026)**: Setting `pre_response_delay: false` inside the block was the recommended fix. That guidance is outdated.

```yaml
# BEFORE (remove these lines)
plugins:
  enabled:
    - humanize
humanize:
  enabled: true
  pre_response_delay: false
  ...

# AFTER (gone entirely)
```

## Memory Provider Switch

**Symptom**: User wants to switch from hindsight to vector-memory (or vice versa).

**Fix**: Edit `~/.hermes/config.yaml`:
```yaml
memory:
  provider: vector-memory
```

Then `/restart` from Discord (NOT `/restart` from within agent — blocked). Agent cannot auto-edit config.yaml for security reasons.
