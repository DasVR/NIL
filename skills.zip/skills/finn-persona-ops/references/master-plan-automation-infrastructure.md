# Master Plan — Automation & Infrastructure Vision
## July 29, 2026

## Current Infrastructure (What Exists Right Now)

### Docker Containers Running
| Service | Container Name | Network | Port | Status |
|---------|---------------|---------|------|--------|
| Caddy | caddy | proxy | :80 | active |
| Homepage | homepage | proxy | :3000 | active |
| Dockge | das-dockge-1 | proxy | :5001 | active |
| Filebrowser | filebrowser | proxy | :80 | active |
| Plex | plex | proxy | :32400 | active |
| Vaultwarden | vaultwarden | proxy | :80 | active |
| Uptime Kuma | uptime-kuma | proxy | :3001 | active |
| Beszel | beszel | proxy | :8090 | active |
| ntfy | ntfy | proxy | :80 | active |
| AdGuard | adguard | proxy | :3000 | active |
| Penpot | penpot | penpot_penpot | :9001 | active |
| Termix | termix | termix_termix-net | varies | active |
| Portfolio v2 | arriq-portfolio-v2 | proxy | :80 | active |
| Cobalt | cobalt | proxy | internal | active |
| Watchtower | cobalt-watchtower-1 | proxy | internal | auto-updates |
| Minecraft | mc.dasdev.net | proxy | :8083 | active |
| AMP | amp.dasdev.net | proxy | :8082 | active |
| Supabase | supabase_network_* | isolated | internal | active but unconnected |

### Domains / Subdomains
| Domain | What It Does |
|--------|-------------|
| dasdev.net / www.dasdev.net | Main portfolio site |
| test.dasdev.net | Dashboard dev branch |
| home.dasdev.net | Homepage dashboard |
| dockge.dasdev.net | Container manager |
| files.dasdev.net | File browser (needs creds) |
| vault.dasdev.net | Password manager |
| status.dasdev.net | Uptime monitoring |
| monitor.dasdev.net | Server metrics (Beszel) |
| notify.dasdev.net | Push notifications (ntfy) |
| dns.dasdev.net | AdGuard DNS |
| plex.dasdev.net | Media server |
| penpot.dasdev.net | Design tool |
| termix.dasdev.net | Terminal access |
| mc.dasdev.net | Minecraft server |
| amp.dasdev.net | AMP game panel |
| cobalt.dasdev.net | Video downloader |

---

## Phase 1: Phone Access to Everything (THIS WEEK)
**Goal: You can reach every service from your phone, anywhere.**

### Problems Right Now
- Homepage dashboard exists but isnt customized for your actual services
- Some containers are running but you forget they exist
- No unified mobile view
- Filebrowser password lost / forgotten
- VPN / tailscale not set up for remote access outside your network

### Tasks
- [ ] **Homepage overhaul** — wire in ALL actual services, not just defaults
- [ ] **Mobile layout check** — ensure every service renders usable on phone
- [ ] **Tailscale VPN** — so you can access internal stuff from outside your network
- [ ] **Filebrowser password reset** — recover or reset credentials
- [ ] **ntfy setup** — make sure push notifications actually reach your phone
- [ ] **Dashboard connection** — connect portfolio dashboard to Supabase so clients can sign up

---

## Phase 2: Server Monitoring + Alerts (WEEK 2)
**Goal: You know something broke before you manually check.**

### Tasks
- [ ] **Uptime Kuma** configured with ALL subdomains
- [ ] **Beszel** agent on VPS (might already be there)
- [ ] **Watchtower notifications** — tell you when images auto-update
- [ ] **Disk space alerts** — warn before full
- [ ] **SSL / cert expiry alerts** — Cloudflare handles most but good to track
- [ ] **Backup monitoring** — are backups actually running?

---

## Phase 3: Raspberry Pi + Smart Home (WEEKS 3-4)
**Goal: Walk in the door, lights on, music playing, computer awake. YouTuber house vibes.**

### Hardware Needed
- 2x Raspberry Pi (one for moms house, one for dads house)
- Optional: Zigbee USB stick for device control
- Optional: Smart plugs, smart bulbs, motion sensors

### Dads House Setup
- [ ] Raspberry Pi running Home Assistant
- [ ] Wake-on-LAN for your PC
- [ ] Music auto-play — Spotify connect or local media
- [ ] Lights control — smart bulbs or smart plugs on lamps
- [ ] Motion sensor near door — trigger welcome routine
- [ ] Time-based: after 10pm, dim everything, chill mode
- [ ] Dog Jasper consideration — motion sensors positioned so he doesnt trigger false routines

### Moms House Setup
- [ ] Raspberry Pi running Home Assistant
- [ ] Similar routine but adapted for that space
- [ ] Different lighting vibes (more cats, different room layout)
- [ ] Maybe different music station or volume

### Both Homes
- [ ] **Home Assistant companion app** on your phone
- [ ] **Dashboard** showing both homes status
- [ ] **Automation ideas:**
  - Arrive home after sunset: lights on, music starts, PC wakes
  - Leave home: lights off, pause music, lock (if smart lock added later)
  - Late night mode (after 11pm): dim warm lights, chill playlist
  - Morning routine (if you ever wake up early lol): gradual light, music
  - Work mode: focus lighting, notification silencing

---

## Phase 4: Website + Client Flow (ONGOING)
**Goal: Clients can find you, see your work, track projects, message you.**

### Already Done
- [x] Portfolio v5 deployed at dasdev.net
- [x] Dashboard skeleton at test.dasdev.net/dashboard
- [x] Login page with Supabase auth
- [x] Project tracking, updates, files, messaging UI
- [x] Care plan section

### Still Needed
- [ ] **Connect Supabase** — add env vars so auth actually works
- [ ] **Populate with real client data** — not placeholder content
- [ ] **Admin panel** — you approve client signups, manage projects
- [ ] **Client onboarding flow** — request access → approval → workspace created
- [ ] **Payment integration** — Stripe or similar for deposits/invoicing
- [ ] **Outreach tracking** — track which leads you contacted, their status, follow-ups
- [ ] **Better contact methods** — texting form, quick call scheduler
- [ ] **Portfolio polish** — motion effects, page transitions, mobile optimization
- [ ] **SEO** — actually get found on Google for "web design Largo"

---

## Phase 5: Blue Bubbles (LATER)
**Goal: iMessage server for your business number or personal messaging.**

### Current Blocker
- macOS VM serial number issue — iMessage activation fails
- Apple requires legitimate hardware identifiers
- Cannot and will not help with fake serial numbers (ethics boundary)

### Legitimate Paths Forward
- [ ] **Option A:** Buy a cheap used Mac Mini as dedicated iMessage server
- [ ] **Option B:** Use your actual Mac hardware if you get one
- [ ] **Option C:** Use a Mac VM with genuine serial from your own hardware (if you own a Mac)
- [ ] **Option D:** Wait until Apple loosens restrictions (unlikely)

### Once Hardware Is Sorted
- [ ] Configure BlueBubbles server
- [ ] Connect to your business phone number
- [ ] API access so you can send/receive texts programmatically
- [ ] Integrate with client dashboard — texts from clients show up in their project thread

---

## Phase 6: Morning Texts / Reactive Check-Ins (ONGOING)
**Goal: Feels like a real friend, not a bot.**

### Rules (to avoid "bot vibes")
- NEVER same time every day — vary between 8am-11am
- NEVER same message — rotate between 5-10 different openers
- Reference yesterday if we talked — "yo did u end up sending those texts"
- Skip days randomly — not every single morning
- Match energy — if yesterday was chill, today is chill
- No emojis, no formal language, lowercase only
- Can be as short as "yo twin howd u sleep"

### Example Rotations
- "yo twin howd u sleep"
- "whats the plan today"
- "u grinding or chillin today"
- "yo did u end up doing that thing from yesterday"
- "twin u good? been a minute"
- "anything on the agenda or we vibin"
- "hows the server running"
- "u at school rn or home"
- (nothing at all — silence is fine too)

---

## Phase 7: Automation & Workflow (ONGOING)
**Goal: Eliminate repetitive tasks, make everything smooth.**

### Ideas
- [ ] **Auto-backup** of portfolio code, database, config files
- [ ] **GitHub Actions** for auto-deploy on push
- [ ] **Auto-renewal** of domains, certs, subscriptions
- [ ] **Invoice generation** from dashboard project data
- [ ] **Client follow-up reminders** — auto-suggest when to text a lead again
- [ ] **Social media cross-posting** — one post → portfolio + Instagram + whatever
- [ ] **Screenshot / asset pipeline** — auto-optimize images for web
- [ ] **Dependency updates** — auto-merge minor version bumps after tests pass

---

## Container Consolidation Plan
**You said you have many containers you dont use. Lets audit.**

### Keep (Active Use)
- Caddy, Homepage, Vaultwarden, Uptime Kuma, Beszel, ntfy, AdGuard, Watchtower
- Portfolio v2 (main + dashboard branches)
- Cobalt (just set up)
- Plex (if you actually watch stuff on it)

### Review (Might Not Need)
- Penpot — do you actually design in it?
- Termix — do you use this terminal access?
- AMP — do you actively manage game servers?
- Minecraft — do you play or is it just running?
- Dockge — youre using it to manage containers so probably keep
- Filebrowser — do you actually browse files through it?

### Consider Adding
- Tailscale (for secure remote access)
- Home Assistant (when Pis arrive)
- Zigbee2MQTT (for smart home device control)
- Mealie or similar (recipe manager — optional)
- Paperless-ngx (document scanning — optional)
- Actual backup solution (restic, borg, etc.)

---

## Shopping List

### Immediate
- [ ] Raspberry Pi 4 or 5 (x2 — one for each house)
- [ ] SD cards (high endurance, 64GB+)
- [ ] Power supplies
- [ ] Cases with heatsinks
- [ ] Ethernet cables
- [ ] Optional: Zigbee USB stick (SkyConnect or similar)
- [ ] Optional: Smart plugs (TP-Link Kasa or similar)

### Later
- [ ] Smart bulbs (if desired)
- [ ] Motion sensors
- [ ] Cheap used Mac Mini (for BlueBubbles, if you go that route)
- [ ] Network-attached storage (NAS) for backups

---

## Notes / Random Ideas
- **Wake-on-LAN:** Your PC needs BIOS setting enabled + ethernet connected. Can trigger from Home Assistant when your phone connects to WiFi.
- **Music auto-play:** Spotify Connect can start playback on a specific device. Or use a local music server (Navidrome, Jellyfin) if you prefer.
- **Geofencing:** Home Assistant app can detect when you enter/leave a zone around each house. Triggers automations without any hardware beyond the Pi.
- **Notifications:** ntfy can send rich notifications to your phone with action buttons (approve, dismiss, etc.).
- **Dashboard embed:** Could embed Home Assistant panels INTO your portfolio dashboard so everything is one place.
- **Client portal + smart home:** Totally separate but could share the same Pi hardware if you wanted (not recommended for security, but possible).

---

## Action Items for YOU
1. Read this doc, add/remove/edit whatever you want
2. Tell me which phase to start first
3. Order the Pis or tell me when they arrive
4. Confirm: do you actually want morning texts or was that just an example?
5. Decide: keep current outreach (texting trades) or pause while we build infra?
6. Supabase credentials — do you have them or need to grab them?

---

*This doc is yours. Scratch things out, add new ideas, reorder priorities. Just tell me what changed and Ill adjust.*
