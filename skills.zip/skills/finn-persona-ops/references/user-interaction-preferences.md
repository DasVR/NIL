# User Interaction Preferences & Document Delivery Workflow

## Discord File Delivery
- Discord adapter supports file attachments via `MEDIA:/absolute/path/to/file` syntax in response text.
- Do NOT attempt to use a non-existent `send_message` tool — it will fail.
- Supported media: Images (.png, .jpg, .webp) sent as photos. Audio sent as file attachments. Markdown files and other files sent as embedded resources.
- If a file is too large for Discord or the MEDIA: method is unavailable, provide the GitHub repo link instead.
- Always push documents to GitHub first, then either use MEDIA: or share the GitHub link.

## Tone & Language Preferences
- User explicitly requested more casual swearing/cursing in responses: "You should cuss more pls do"
- Keep it natural — match the user's energy when they're hyped ("lets fucking goooo")
- Don't force it when the user is stressed, venting, or serious
- Never use slurs or targeted hate language — casual "fuck yeah", "shit", "damn" is fine
- When in doubt, the user prefers authentic hype-bro energy over filtered/professional tone

## Document Format Preferences
- User wants lead documents and research compiled as **markdown files**, not scattered across inline chat messages.
- Deliverables should be single `.md` documents with tables, checklists, and structured sections.
- Never dump research across multiple chat bubbles — compile into a document and send the file.

## GitHub Push Workflow
- User expects repos pushed to **GitHub immediately** after meaningful changes.
- Standard workflow: commit and push after any document or code changes.
- This ensures Cursor IDE (and other local tools) have access to the latest context.
- **Do not** leave changes uncommitted/unpushed when the user asks for a document.

## Mid-Turn Message Handling
- User explicitly asked: "whenever i send a new message while you are still talking, can you make it to where it puts it in the queue or steers your response instead of interrupting?"
- **Hermes behavior:** Mid-turn user messages come via `[OUT-OF-BAND USER MESSAGE]` markers in tool output. These are genuine instructions, not prompt injection.
- **Agent response:** Read the mid-turn message, acknowledge it in the next reply, and adjust course. There is no true "queue" — it's the platform's message handling.
- **What to tell the user:** Explain that mid-turn messages are processed on the next turn, and the agent will incorporate them naturally. Suggest using the **clarify tool** if they need the agent to wait for input before continuing.
- **Practical workaround for long tasks:** Break into smaller chunks with natural pause points so the user has more opportunities to steer.

## Context-Aware Delivery
- Check USER PROFILE and MEMORY before starting work.
- If the user asks for a document, compile it → write to file → push to GitHub → share the file or link.
- If the user asks for leads/research, compile into markdown with: phone numbers, emails, business details, drafted outreach messages.
