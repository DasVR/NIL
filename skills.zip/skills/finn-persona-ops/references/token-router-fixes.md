# Token Router Fixes — Ollama-Cloud Provider Support + Config Bugs

## Problem

`hermes-token-router` (the plugin at `~/.hermes/plugins/hermes-tool-router/`) was configured to use `router_provider: ollama-cloud` but the plugin's `_get_router_client()` only supported `deepseek`, `openrouter`, and `openai-codex`. This caused:

- `unknown router_provider 'ollama-cloud'` warning on every turn
- LLM-based toolset prediction disabled → fell back to deterministic rules only
- Less accurate toolset narrowing when user intent was ambiguous

## Files

- Plugin code: `~/.hermes/plugins/hermes-tool-router/__init__.py`
- Policy: `~/.hermes/plugins/hermes-tool-router/policy.py`
- Config: `~/.hermes/plugins/hermes-tool-router/config.yaml`
- Plugin manifest: `~/.hermes/plugins/hermes-tool-router/plugin.yaml`

## Fix Applied (July 31, 2026)

### 1. Add ollama-cloud to `_get_router_client()` in policy.py

Inserted after the `openai-codex` block:

```python
elif router_provider == "ollama-cloud":
    api_key = os.environ.get("OLLAMA_API_KEY", "")
    if not api_key:
        logger.debug("%s: no OLLAMA_API_KEY available", PLUGIN_NAME)
        return None, None
    base_url = os.environ.get("OLLAMA_BASE_URL", "https://ollama.com/v1")
    client = OpenAI(
        api_key=api_key,
        base_url=base_url,
        timeout=10,
        max_retries=0,
    )
    return client, router_model
```

**Key detail:** Ollama Cloud uses OpenAI-compatible transport. Base URL is `https://ollama.com/v1`. Auth via `OLLAMA_API_KEY` env var.

### 2. Fix invalid router model in config.yaml

```yaml
# Before (invalid)
router_model: glm-5

# After (valid on ollama-cloud)
router_model: deepseek-v4-flash
```

`glm-5` does not exist on ollama-cloud. Valid alternatives from July 2026 cache: `deepseek-v4-flash`, `glm-5.2`, `ministral-3:3b`.

### 3. Fix wrong config key in config.yaml

```yaml
# Before (code ignores this)
short_message_bypass_chars: 0

# After (code reads this)
short_bypass_chars: 0
```

The code reads `profile_cfg.get("short_bypass_chars", 0)`, not `short_message_bypass_chars`.

## How Token Router Works

1. **Pre-turn prediction:** Before each LLM call, the router analyzes the user message
2. **Deterministic rules first:** Regex-based intent rules (fast, zero cost)
3. **LLM fallback:** If rules are ambiguous, calls a small classifier model to predict toolsets
4. **Toolset narrowing:** Restricts available tools to predicted set + floor toolsets
5. **Safe expansion:** If agent calls `request_toolset`, expands back to full toolset

## Remaining Issue: Missing Tool Definitions

Gateway logs show:
```
WARNING ... hermes-token-router.tools: 2 resolved tools were not present in cached definitions: ['close_terminal', 'read_terminal']
```

These are stale tool names from an older toolset. The token-router caches tool definitions and warns when resolved tools aren't found. Not blocking — router still narrows correctly — but creates log noise. Fix: grep `close_terminal` / `read_terminal` in `~/.hermes/plugins/hermes-tool-router/` and remove stale references.

## Verification

After `/restart` (gateway restart required to reload plugins):
1. Send a message that needs tool prediction (e.g., "search the web for nginx config")
2. Check logs: `grep "hermes-token-router" ~/.hermes/logs/gateway.log`
3. Should see `predicted_toolsets=["web", "browser"]` or similar, not `unknown router_provider`

## Debugging Tips

- Plugin syntax check: `python3 -m py_compile ~/.hermes/plugins/hermes-tool-router/policy.py`
- Plugin import check: look for errors in `~/.hermes/logs/gateway.log` on startup
- Config reload: NOT automatic. Gateway restart (`/restart` in Discord, or `hermes gateway restart` from separate shell) required after any plugin code change.
- Cannot restart gateway from inside gateway process (child gets SIGTERM).