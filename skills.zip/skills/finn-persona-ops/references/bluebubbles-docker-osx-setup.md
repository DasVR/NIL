# BlueBubbles Docker-OSX Setup (July 2026)

Complete server-side scaffolding for a macOS VM running BlueBubbles iMessage bridge.
Built from scratch after previous VM was wiped. Does NOT include serial number generation — user handles that themselves.

## Directory Layout
```
/home/das/bluebubbles/
├── docker-compose.yml          # docker-osx VM config (auto image)
├── install.sh                  # one-shot install (creates dirs, installs systemd service)
├── bluebubbles.service         # systemd unit (Type=oneshot, RemainAfterExit=yes)
├── scripts/
│   ├── start-vm.sh             # validates KVM + docker, starts container, shows VNC info
│   ├── stop-vm.sh              # stops and removes containers cleanly
│   └── extract-bootdisk.sh     # copies bootdisk + serial state out of running container
├── macos-data/                 # persistent VM disk image mount
└── opencore/                   # opencore config mount (before extraction)
```

## Key Technical Decisions

### Audio disabled (line 20)
`AUDIO=none` environment variable prevents QEMU audio device crashes that killed the previous VM.

### Bootdisk extraction workflow
First boot uses `sickcodes/docker-osx:auto` with serials set via env vars. After macOS + BlueBubbles are configured, `extract-bootdisk.sh` copies `OpenCore.qcow2` out of the container. Then update `docker-compose.yml` to mount the extracted `bootdisk.qcow2` instead of the opencore folder — future boots preserve serials and boot state.

### Systemd service design
- Type=oneshot + RemainAfterExit=yes (NOT simple + Restart=always)
- Previous service used `Restart=always` which caused an infinite container creation loop
- Current design: systemd tracks whether the compose is "up" without restarting exited containers
- ExecStop/ExecStopPost cleanly stop and remove containers on shutdown

### Serial number placeholders
`docker-compose.yml` has 4 `REPLACE_ME` values:
- SYSTEM_SERIAL
- BOARD_SERIAL
- UUID
- MAC_ADDRESS

User must replace these with real values before first boot if iMessage activation is desired. Agent does NOT help find or generate serials. See `references/agent-memory-research.md` "Ethical Boundaries" section for why.

## Commands
```bash
cd /home/das/bluebubbles

# First time: manual start to see output
./scripts/start-vm.sh

# After extraction: auto-start via systemd
sudo systemctl enable --now bluebubbles

# Check status
docker compose ps

# Attach to VM console
docker attach macos-vm

# Stop
docker compose stop macos
# OR
./scripts/stop-vm.sh
```

## Ports Exposed
- 5999: VNC / noVNC (if enabled inside VM)
- 3000: BlueBubbles web server (if configured)

## Next Steps When User Is Ready
1. Replace REPLACE_ME serials in docker-compose.yml
2. Run `./scripts/start-vm.sh`
3. Install macOS inside VM (follow docker-osx prompts)
4. Download and install BlueBubbles inside macOS
5. Sign into iMessage
6. `./scripts/extract-bootdisk.sh`
7. Update compose to use extracted `bootdisk.qcow2`
8. `sudo systemctl enable --now bluebubbles`
