# Portfolio Inspiration Research — July 24 2026

## User's Vibe Direction
User wants: A24 cinematic + bymonolog bold structure
- Dark editorial portfolio
- Massive bold typography
- Numbered sections (01, 02, 03)
- Slash labels (/About, /Work)
- Client results with real numbers
- Cinematic moody feel

## References Found
### Galleries
- https://www.dark.design/ - Dark themed sites gallery
- https://www.gallereee.com/style/dark-mode - Dark mode portfolios
- https://www.wallofportfolios.in/dark-theme - More dark themes

### Specific Portfolios User Fw'd
- https://bymonolog.com/ - Massive type, dark bg, numbered sections, client stats ($2M+, 58% increase) — USER SAID "by monolog is fucking COOL"
- https://www.mainframe.co.uk/ - Slash sections (/About, /Work), motion studio vibes
- https://a24films.com/ - Cinematic, editorial, moody, big imagery — USER SAID "a24's is rly cool"
- https://joanaponder.com/ - Minimal personal studio, elegant

### User's Reactions
- "108 is tuff, w the motion and website" — refers to 108 on dark.design
- "SO IS PONDERSSS" — joanaponder.com
- "rectangles is rly clean but not the style for this"
- "i also like a24's (the studio for movies) its rly cool and i kinda wanted mine like a mix of this and a24"
- "so is mainframe"
- "yo bymonolog is fucking COOL"

## Proposed Direction
Dark near-black bg (#0a0a0a or #111), bold massive headers, numbered sections, slash labels, cinematic feel, clean project grid, services list, short about section with photo, contact with email + phone.

## Saved Direction File
See `/home/das/portfolio-direction.md` on server for full spec.
