# Arriq's Bookmarks Arsenal — Deep Dive Methodology & Tool Inventory

## Source
- 229 X/Twitter bookmarks exported via custom Chrome extension (July 14 2026)
- Original JSON (session 1): `~/.hermes/cache/documents/doc_bd886d46d643_x-bookmarks-1784011994151.json`
- Original JSON (session 2): `~/.hermes/cache/documents/doc_9ebd6ee35e38_x-bookmarks-1784011994151.json`
- Organized doc v1: `/home/das/x-bookmarks-arsenal.md` (88KB, 3516 lines, 13 categories)
- Organized doc v2: `/home/das/x-bookmarks-arsenal-v2.md` (108KB, 4264 lines, compiled by subagent, includes reply context, keyword-scored categories)
- Master upgrade guide: `/home/das/hermes-plans/finn-master-upguide.md` (46KB, 726 lines, 5-part guide: bookmarks explained, new features, teaching methods, doc reviews, action plan)
- Homelab master plan: `/home/das/hermes-plans/das-homelab-master-plan.md` (42KB, 1477 lines — combines server-upgrade-2026.md + ubuntu-server-toolkit.md, adds school/scheduling layer, Finn capability upgrades, 13 sections, RAM budget, port reference, Phase 1-4 deployment plan)
- Full text dump for categorization: `/tmp/bookmarks_full_dump.txt` (88KB, 2642 lines)

## Data Structure
Each bookmark JSON entry has: `id`, `url`, `author`, `handle`, `text`, `timestamp`, `metrics` (likes, retweets, replies, views), `media` (array of {type, url}), `isReply` (boolean), `replyingTo` (URL of parent tweet, only on 5 entries).

- Total bookmarks: 229
- Replies (isReply=true): 2 (#105 @dankuntz, #177 @uzairansar)
- Has replyingTo field: 5 (#69 @praveenisomer, #103 @ArchiveExplorer, #160 @weswinder, #185 @cjzafir, #208 @Atenov_D)
- Has media: 116
- Unique handles: 158
- Date range: Feb 11 2026 - Jul 13 2026
- GitHub repos found: 20

## Deep-Dive Methodology (User Correction — July 14 2026)
User said: "I dont think we should just rely on the bookmarks for everything, isnt there links to things inside most of the bookmarks? with cooler stuff?"

**LESSON**: When processing bookmark collections, surface categorization is NOT enough. Must:
1. Extract ALL URLs from tweet text (regex: `https?://[^\s…]+`)
2. Separate GitHub repos from websites
3. Fetch GitHub READMEs via API: `curl -sL "https://api.github.com/repos/{owner}/{repo}/readme" -H "Accept: application/vnd.github.v3.raw"`
4. Fetch website content: `curl -sL "$url" | sed 's/<[^>]*>//g' | sed '/^$/d' | head -30`
5. Extract nested tool names from tweet text (patterns: "called X", "Meet X", "Introducing X", numbered lists)
6. Read README content to find dependencies, related projects, MCP servers, and linked tools
7. Identify which tools can be INSTALLED on the server vs just referenced

## Processing Pipeline (Updated July 14 2026 — Session 2)
When user sends a fresh bookmarks JSON export:

1. **Parse JSON** with Python via terminal: load all 229 entries, print stats (replies, media, handles, dates, GitHub URLs)
2. **Build full text dump**: iterate all entries, format with metrics + URL + reply tags + media info, write to `/tmp/bookmarks_full_dump.txt`
3. **Read full dump** in chunks (read_file with offset/limit — 2642 lines, read in 4-5 batches of 200-500 lines)
4. **Categorize** into 13 categories (see below)
5. **Handle replies**: note isReply=true and replyingTo fields. Web extract CANNOT fetch X/Twitter parent tweets (React SPA, not static HTML). Note parent tweet URLs in the doc for user to click through manually.
6. **Compile doc**: for large compilations (229 entries, 88KB+), use `delegate_task` with file+terminal toolsets — the subagent reads the dump file and JSON, writes the final markdown doc. This keeps the main context clean.
7. **Output**: write to `/home/das/x-bookmarks-arsenal-v2.md`

### PITFALL: web_extract fails on X/Twitter URLs
`web_extract` returns "No web extract provider configured" or cannot extract X/Twitter tweet content because X is a React SPA (client-side rendered). Do NOT attempt to fetch replied-to parent tweets via web_extract. Instead, note the parent tweet URLs in the compiled doc and let the user click through manually.

### PITFALL: execute_code blocked in cron-mode sessions
If running in a cron session, `execute_code` returns "BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks)." Use `terminal` with inline `python3 -c "..."` instead for JSON parsing and data analysis.

## Tool Inventory (from deep dive)

### Installable on Server (Linux, no GPU)
| Tool | Install | Purpose |
|------|---------|---------|
| pocket-tts | `pip install pocket-tts` (CPU torch) | Free voice cloning, 100M params, 6x realtime |
| graphify | `uv tool install graphifyy` | Codebase knowledge graph, query instead of grep |
| tasteskill | `npx skills add https://github.com/Leonxlnx/taste-skill` | Anti-slop UI framework for AI agents |
| emilkowalski/skills | `npx skills@latest add emilkowalski/skills` | Design engineering skills (Vercel/Linear quality) |
| reicon | `npm install reicon` (has MCP server) | 2700+ SVG icons with AI agent MCP |
| blossom-carousel | `npm install @blossom-carousel/core` | 4.3KB slider lib, native scroll, zero abstraction |
| AutoSocial | clone from GitHub | TikTok/IG/YouTube automation dashboard |
| OpenHands | clone from GitHub | Autonomous coding agent |
| AnythingLLM | Docker | Chat with docs, AI agents, multi-user |
| mimic | clone from GitHub | Intercept app traffic, generate Python client |

### Reference Sites (not installable but useful)
- impeccable.style — design skills for AI agents
- lobehub.com — agent collaboration platform, 7×24 agent teams
- formscn.space — visual drag-and-drop shadcn form builder
- tripwire.sh/dither-kit — dither effect library
- walkinglabs.github.io — harness engineering course (free)
- tasteskill.dev — anti-slop frontend framework
- withmarble.com — landing page with easter eggs (inspiration)

### Cybersec Tools (research only, ethical use)
- Maigret — OSINT username search across 3000+ sites
- Stealth Browser MCP — 97 tools, Cloudflare bypass, antibot (MCP server)
- mimic — intercept app traffic, reverse engineer APIs

### Key GitHub Repos (20 total)
- https://github.com/All-Hands-AI/OpenHands — autonomous coding agent
- https://github.com/Graphify-Labs/graphify — codebase knowledge graph (YC S26)
- https://github.com/cobusgreyling/loop-engineering — agent loop design framework
- https://github.com/vibheksoni/stealth-browser-mcp — undetectable browser automation
- https://github.com/kyutai-labs/pocket-tts — CPU voice cloning
- https://github.com/ysharma3501/LuxTTS — 150x realtime voice cloning
- https://github.com/jespervos/blossom-carousel — 4.3KB slider
- https://github.com/dqev/reicon — 2700+ icons + MCP
- https://github.com/apple/container — native Docker for macOS
- https://github.com/Mintplex-Labs/anything-llm — chat with docs
- https://github.com/emilkowalski/skills — design engineering skills
- https://github.com/littledivy/mimic — app traffic interception
- https://github.com/egorshest/webgl-ascii-hero — ASCII WebGL hero section
- https://github.com/khanhduytran0/LiveContainer — run iOS apps without installing
- https://github.com/vdsm/virtual-dsm — Synology DSM in Docker
- https://github.com/kebo-ai/kebo — personal finance app (iOS/Android)
- https://github.com/Katzca/AutoSocial — social media automation dashboard
- https://github.com/ShadowHackrs/gmail-account-creator — Gmail account creator (ethical research only)
- https://github.com/haaarshsingh/www — portfolio site reference (Bun + Upstash)
- https://github.com/gummidot/VRCWorldDrop — VRChat world drop prefab

## Reply Context (5 bookmarks with replyingTo)
These bookmarks are replies to other tweets. Parent tweet URLs are noted but could not be fetched (X is a React SPA):

| # | Handle | Text excerpt | Replying to |
|---|--------|-------------|-------------|
| 69 | @praveenisomer | "More figma shaders magic" | x.com/praveenisomer/status/2070877311071916387 |
| 103 | @ArchiveExplorer | "met an anthropic engineer making $1.2M..." | x.com/ArchiveExplorer/status/2073137020633809004 |
| 160 | @weswinder | "this is definitely what got fable banned" | x.com/elder_plinius/status/2064776322979676227 |
| 185 | @cjzafir | "Here's a teaser of our Mac-1 model..." | x.com/cjzafir/status/2062928405344272880 |
| 208 | @Atenov_D | "FREE GPT 5.5 API from a Chinese provider..." | x.com/Atenov_D/status/2059221180536528950 |

## CPU-Only Torch Install Pattern (July 14 2026)
Server has no GPU. Full torch with CUDA is 526MB+ and times out during pip install.

```bash
# WRONG — downloads 526MB+ CUDA packages, times out
pip install torch

# RIGHT — CPU-only torch, much smaller
pip install torch --index-url https://download.pytorch.org/whl/cpu --no-cache-dir
pip install pocket-tts --no-cache-dir
```

**PITFALL**: pocket-tts import is `from pocket_tts import TTSModel`, NOT `from pocket_tts import PocketTTS`.
**INSTALLATION CONFIRMED (July 14 2026)**: Successfully installed at `/tmp/pocket_tts_env/` (venv). Steps: `python3 -m venv /tmp/pocket_tts_env && source /tmp/pocket_tts_env/bin/activate && pip install torch --index-url https://download.pytorch.org/whl/cpu --no-cache-dir && pip install pocket-tts --no-cache-dir`. Verify with `python -c "from pocket_tts import TTSModel; print('ready')"`. CPU-only, 100M params, ~200ms latency, 6x realtime. To use: `source /tmp/pocket_tts_env/bin/activate` first in any terminal session.

## Deep-Dive Results: GitHub README Fetching (July 14 2026)
Fetched and read all 20 GitHub repo READMEs via `curl -sL "https://api.github.com/repos/{owner}/{repo}/readme" -H "Accept: application/vnd.github.v3.raw"`. Also fetched 10 website homepages via `curl -sL "$url" | sed 's/<[^>]*>//g'`. Key findings from reading the actual READMEs:

- **Graphify** (YC S26): `uv tool install graphifyy` + `graphify install` → use `/graphify .` in any AI assistant. Maps codebase into knowledge graph. Has Discord, PyPI package.
- **Loop Engineering**: 8 npm packages (loop-init, loop-audit, loop-cost, loop-sync, loop-context, loop-mcp-server, loop-worktree). `npx @cobusgreyling/loop-init .` scaffolds agent loop files. Interactive showcase at cobusgreyling.github.io/loop-engineering.
- **Stealth Browser MCP**: 97 tools across 11 sections. Uses nodriver + Chrome DevTools Protocol + FastMCP. Cross-platform (Win/Mac/Linux/Docker). Works with Claude Code, Claude Desktop, Cursor.
- **Pocket TTS**: 100M params, CPU-only, 200ms first chunk, 6x realtime on M4. Voice cloning, multilingual (en/fr/de/pt/it/es). 24+ prebuilt voices on HuggingFace. CLI: `uvx pocket-tts generate`.
- **LuxTTS**: Zipvoice-based, 150x realtime, 48kHz, <1GB VRAM. Colab notebook available.
- **Blossom Carousel**: First carousel on native browser scrolling. 0KB on touch devices. React/Vue/Svelte/Web Component packages. Has "Agent Skills" for AI coding assistants.
- **Reicon**: 2700+ SVG icons, 24×24 grid, outline + filled weights. React/Vue/Svelte/CDN/Figma/VS Code/MCP packages.
- **LiveContainer**: iOS app launcher (not emulator). Runs iOS apps without installing. Bypasses 3-app free dev account limit.
- **Virtual DSM**: Synology DSM in Docker. KVM acceleration, NAT/macvlan networking. `DISK_SIZE` env var.
- **Apple Container**: Swift, Apple silicon only, macOS 26+. OCI-compatible.
- **Kebo**: React Native + Supabase + Expo. Personal finance app.
- **AutoSocial Studio**: Local Express dashboard + Playwright upload flows + yt-dlp + FFmpeg uniquifier. MIT license, Node 18+.
- **mimic**: mitmproxy → extract auth → Claude generates Python client. `sh install.sh` (installs uv if needed).
- **webgl-ascii-hero**: Next.js + React Three Fiber + Three.js + custom GLSL shader. ASCII conversion post-processing. CRT scanlines + vignette + glow.
- **AnythingLLM**: MIT license. All-in-one AI app. Discord, docs at anythingllm.com. Also working on "Open Computer" for AI agents.
- **emilkowalski/skills**: `npx skills@latest add emilkowalski/skills`. Design engineering skills from Vercel/Linear engineer. Prevents agents from choosing wrong easings, borders, etc.
- **haaarshsingh/www**: Bun-based portfolio site. Uses Upstash Redis for visitor tracking, Last.fm for music card. Good reference for portfolio design.
- **tasteskill.dev**: `npx skills add https://github.com/Leonxlnx/taste-skill --skill "design-taste-frontend"`. v2 is experimental default. 13 skills total (dark mode protocol, redesign protocol, block library schema, etc.). Sponsored by Vercel + animations.dev.

## Bookmarks Categories (229 total)

Two compilations exist with different category counts. V2 uses keyword scoring and is more accurate:

**V2 category counts (keyword-scored, from /home/das/x-bookmarks-arsenal-v2.md):**
1. AI Agents & Autonomous Systems (26)
2. LLMs & Local Models (43)
3. Design / UI / UX (39)
4. Development Tools & Frameworks (49)
5. Cybersecurity / Privacy / OSINT (10)
6. Self-Hosting & Infrastructure (3)
7. Hermes Agent Ecosystem (6)
8. Apple / iOS / macOS (7)
9. Content Creation & Media (5)
10. Open Source Projects & GitHub Repos (34)
11. Art / Aesthetics / Creative (1)
12. Minecraft / VRChat / Gaming (5)
13. Business / Side Hustles / Money (1)

Note: Categories overlap — a single bookmark can appear in multiple categories. V2 counts sum to >229 because of keyword overlap. V1 counts (13/32/72/32/6/12/4/2/.../43) were from manual categorization in session 1 and are less reliable.

## Master Upgrade Guide (July 14 2026)
A comprehensive master document was created at `/home/das/hermes-plans/finn-master-upguide.md` (46KB, 726 lines). It covers:
- Part 1: All 229 bookmarks explained in plain language (13 categories, best tools highlighted)
- Part 2: 14 new features for Finn ranked by impact/feasibility (Tier 1-3)
- Part 3: How to teach Finn to be better (self-improving loops, memory, Karpathy method, bookmarks as knowledge base)
- Part 4: Review of all 15 existing plan docs (relevance, overlap map, consolidation recommendations)
- Part 5: 5-phase action plan (quick wins → MCP servers → voice → automation → deep upgrades)

Key insight from the guide: "Finn doesn't need a better model. Finn needs better tools, better skills, and better loops." (Inspired by the $1.2M Anthropic engineer who ships like a full team with the same model.)

## Delegation Pattern for Large Doc Compilation (July 14 2026)
When compiling documents from 229 bookmarks (88KB+ source):

**What works:** Use `delegate_task` with file+terminal toolsets. The subagent reads the dump file and JSON, writes the final markdown doc. This keeps the main context clean.

**PITFALL: Subagent tool-call limits.** When the subagent needs to read MANY source files (e.g., 15 plan docs + 4264-line bookmarks file), it may hit the tool-call limit before writing the output file. The subagent read all 15 plan docs + the full arsenal but ran out of tool calls before writing `/home/das/hermes-plans/finn-master-upguide.md`. Solution: have the subagent return findings via its summary, then write the doc yourself using `write_file`. The subagent's research is still valuable even if it couldn't write the file.

**Better pattern for large multi-source docs:**
1. Subagent reads all sources, returns structured findings in its summary
2. Main agent writes the doc using `write_file` with the subagent's findings
3. This avoids the tool-call limit problem entirely

## Quick File Serving Over Tailscale (July 14 2026)
To share markdown docs with the user over Tailscale without a Docker container:

```bash
# Copy file to /tmp (serves from there)
cp /home/das/hermes-plans/some-doc.md /tmp/some-doc.md

# Start background Python HTTP server
# Use terminal(background=true) — NOT shell '&' (foreground mode rejects it)
# The server is long-lived so no notify_on_complete needed
cd /tmp && python3 -m http.server 8089 --bind 0.0.0.0

# Verify
curl -s -o /dev/null -w "%{http_code}" http://localhost:8089/some-doc.md
# Should return 200

# User accesses at: http://100.104.181.43:8089/some-doc.md (Tailscale IP)
```

Note: The python http.server process must be started with `terminal(background=true)`. Using shell-level `&` in foreground mode is rejected. The process is long-lived (server never exits) so `notify_on_complete` is not needed. Check existing port usage with `ss -tlnp | grep <port>` before starting.