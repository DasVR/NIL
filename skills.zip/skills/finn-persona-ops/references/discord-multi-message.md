# Discord Multi-Message Splitting — Implementation Notes

## Status: IMPLEMENTED (July 2026)

Erick wants Finn to send multiple separate Discord message bubbles per reply (like real texting), not one large block. This is a core persona formatting preference.

## Implementation

### Sentinel: ␤ (U+2424 SYMBOL FOR NEWLINE)
- Chosen because: (a) LLM can output it, (b) survives JSON/API serialization, (c) never appears in normal text, (d) invisible to users
- **Rejected sentinels**: `\x00SPLIT\x00` (null bytes stripped by JSON serialization, LLM can't output them); `---SPLIT---` (could appear in markdown); `\n\n---\n\n` (conflicts with horizontal rules)

### Patched Files
1. `~/.hermes/hermes-agent/plugins/platforms/discord/adapter.py` — `DiscordAdapter.send()` method (line ~1938)
2. `~/.hermes/SOUL.md` — "MESSAGE SPLITTING" section rewritten to instruct Finn to use ␤

### How It Works
1. SOUL.md instructs Finn to insert ␤ (U+2424) between message segments in every response
2. `DiscordAdapter.send()` checks for `_SPLIT_SENTINEL = "\u2424"` in content
3. If present: splits content into `bubble_segments` (stripped, empties filtered, capped at 8)
4. Each segment independently goes through `format_message()` + `truncate_message(MAX_MESSAGE_LENGTH=2000)`
5. All chunks from all segments collected into `all_chunks` list
6. Reply reference attached to first chunk of first bubble only (matches "first" reply_to_mode)
7. If no sentinel: `bubble_segments = [content]` — normal single-message delivery (backward compatible)

### Key Code Location
```python
# In DiscordAdapter.send() at line ~1938
_SPLIT_SENTINEL = "\u2424"
bubble_segments: list[str] = []
if _SPLIT_SENTINEL in content:
    bubble_segments = [
        seg.strip() for seg in content.split(_SPLIT_SENTINEL)
        if seg.strip()
    ]
    if len(bubble_segments) > 8:
        bubble_segments = bubble_segments[:8]
else:
    bubble_segments = [content]

# ... later, for each segment:
all_chunks: list[str] = []
for seg in bubble_segments:
    formatted = self.format_message(seg)
    seg_chunks = self.truncate_message(formatted, self.MAX_MESSAGE_LENGTH)
    all_chunks.extend(seg_chunks)
```

### Gateway Restart Required
The patched adapter only loads on gateway restart. **You CANNOT restart the gateway from within the gateway process** — `systemctl --user restart hermes-gateway` is blocked when run from a terminal inside the gateway (SIGTERM propagates to child processes before the command completes). Options:
- User sends `/restart` from the Discord chat
- Run `hermes gateway restart` from a separate SSH shell outside the gateway process
- `nohup bash -c 'sleep 2 && systemctl --user restart hermes-gateway'` also blocked (same reason)

### SOUL.md Changes
The "MESSAGE SPLITTING" section was rewritten:
- Old: "Always break any response longer than ~1200-1500 characters into 2-4 short, natural Discord messages" (instructions only, no mechanism)
- New: "insert the sentinel character ␤ (U+2424) between each message segment" with example: `yooo twin whats good␤so for the docker thing...␤also the webhook url...`

### How Discord Adapter Message Splitting Works (reference)

#### BasePlatformAdapter.truncate_message() (gateway/platforms/base.py:5494)
- Splits long content into chunks, preserving code block boundaries
- When a split falls inside a triple-backtick code block, the fence is closed and reopened
- Multi-chunk responses get `(1/N)` indicators
- Only triggers when content exceeds `max_length` (platform-specific)

#### DiscordAdapter (plugins/platforms/discord/adapter.py)
- `MAX_MESSAGE_LENGTH = 2000` (Discord's hard limit)
- `_SPLIT_THRESHOLD = 1900`
- `splits_long_messages = True` — signals to gateway delivery that the adapter chunks natively
- `send()` at line 1894: originally called `truncate_message()` once on full content, now splits on sentinel first

#### Stream Consumer (gateway/stream_consumer.py)
- Handles streaming responses with edit-in-place behavior
- `on_segment_break()` — finalizes current stream segment at tool boundaries
- `streaming.enabled: false` in our config — so responses go through non-streaming path (single `adapter.send()` call with full `final_response`)

#### Text Batching (Inbound)
- `_text_batch_delay_seconds` (0.6s default) — merges rapid successive USER messages
- `_text_batch_split_delay_seconds` (2.0s default) — delay between split batches
- This is for inbound message batching, not outbound splitting

### Key Files
- `plugins/platforms/discord/adapter.py` — DiscordAdapter.send() at line 1894
- `gateway/platforms/base.py` — BasePlatformAdapter.truncate_message() at line 5494
- `gateway/stream_consumer.py` — StreamConsumer (streaming delivery)
- `gateway/delivery.py` — delivery router (checks `splits_long_messages` flag)
- `gateway/run.py` — gateway main loop, calls adapter.send() for final response
- `~/.hermes/SOUL.md` — Finn persona instructions (sentinel usage)

### Natural Typing Delays (IMPLEMENTED July 2026)
After initial multi-bubble worked, Erick said "it looks kinda fake, it needs delay and stuff." Added natural pacing to the adapter's `send()` loop:

- **Delay before each subsequent bubble** (i > 0 in the all_chunks loop)
- Base delay: `random.uniform(0.6, 1.8)` seconds
- 15% chance of a "thinking pause": adds `random.uniform(1.5, 3.5)` extra seconds (simulates hesitation/thinking)
- Scales with text length: `len(chunk) / 700` added to base, capped at 5.0s total
- Super short bubbles (< 15 chars, e.g. "fr", "nah", "wait") cap at 1.2s max (quick double-text feel)
- **Typing indicator shown during delay**: `async with channel.typing(): await asyncio.sleep(_delay)` — fallback to plain sleep if typing context fails

Key code (in the `for i, chunk in enumerate(all_chunks)` loop, before `channel.send`):
```python
if i > 0:
    import random as _rnd
    _base = _rnd.uniform(0.6, 1.8)
    _thinking_pause = _rnd.random() < 0.15
    if _thinking_pause:
        _base += _rnd.uniform(1.5, 3.5)
    _delay = min(_base + len(chunk) / 700, 5.0)
    if len(chunk) < 15:
        _delay = min(_delay, 1.2)
    try:
        async with channel.typing():
            await asyncio.sleep(_delay)
    except Exception:
        await asyncio.sleep(_delay)
```

### SOUL.md Creative Humanization Patterns (UPDATED July 2026)
Erick asked for "humanization" and "creativity" after delays were added. Updated two SOUL.md sections:

**MESSAGE PACING section** — added:
- Vary rhythm: quick quick quick, or short... then longer, or one-word bubbles ("fr" "nah" "wait")
- 5+ bubbles when hyped or telling a story; just 2 when chill
- One-word bubbles are allowed and encouraged: "bet." "fr." "nah." "deadass?"
- Mix 3-word bubbles with 15-word ones (don't make every bubble the same length)

**NATURAL IMPERFECTIONS section** — added:
- Short afterthought follow-ups: "wait" "fr tho" "nah but seriously"
- Intentional double-texting: "actually nvm" or "wait no i take that back"
- Break mid-sentence across bubbles (hit send too early)
- "..." at end of a bubble to trail off, pick up in next
- Fake-type then correct: "i think the answer is 42... wait no it's 47 my bad"
- React to own messages: follow with "lmaoo" or "that sounded better in my head"
- Don't always end cleanly — sometimes just "anyway" or "yeah idk"

### Testing
- After patching + gateway restart, test with a response containing ␤
- Verify each segment arrives as a separate Discord message
- Verify segments under 2000 chars don't get further split (no `(1/N)` indicators)
- Verify reply references work (first segment only)
- Verify backward compatibility: responses without ␤ still send as single message
- Verify flood cap: 8+ segments get capped at 8 bubbles
- Verify typing delays: subsequent bubbles should NOT appear instantly — typing indicator visible, 0.6-5s gap between bubbles
- Verify short bubbles ("fr", "nah") arrive faster than long ones
- Verify occasional thinking pauses (~15% of bubbles have longer delay)
- Verify creative patterns: one-word bubbles, mid-sentence breaks, self-corrections feel natural

### ⚠️ Vulnerability: Hermes Updates Wipe the Sentinel Splitter
**Observed August 13 2026.** After `hermes-update` ran, the multi-bubble splitter code disappeared from `plugins/platforms/discord/adapter.py`. The ␤ sentinel started appearing raw in Discord messages because the adapter no longer split on it — it only did length-based truncation.

**Root cause:** `hermes-update` pulls fresh source from the Nous Research repo. The sentinel splitter was a local patch that never upstreamed, so updates overwrite it.

**Detection:** If the user says "ur new line thing isnt working" or "its the ␤ character", the splitter has been wiped.

**Recovery (immediate):**
1. Re-apply the patch to `plugins/platforms/discord/adapter.py` in the `send()` method
2. `rm -rf plugins/platforms/discord/__pycache__`
3. User runs `/restart` in Discord (or restart gateway from external shell)

**Permanent mitigation options:**
1. **Custom plugin approach:** Move the splitter into the `humanize` plugin's `pre_gateway_dispatch` hook — plugins survive `hermes-update` better than core patches.
2. **Post-update check script:** Add a cron or systemd `ExecStartPost` that verifies the splitter is present and re-patches if missing.
3. **Upstream it:** File a PR against `NousResearch/hermes-agent` to add the sentinel splitter natively to `DiscordAdapter.send()`.

**Recommendation:** After every `hermes-update`, verify multi-bubble splitting still works. If not, re-patch immediately.