---
name: python-fastapi-services
description: Scaffold, build, and deploy FastAPI Python backend services with modular architecture, Docker support, and OpenAI-compatible endpoints.
---

# Python FastAPI Services

Build production-ready FastAPI APIs from scratch. Covers clean project layout, engine/provider pattern, Docker containerization, rate limiting, and OpenAI-compatible endpoint design.

## When to Use This Skill

- Building a Python API backend the user can self-host
- Porting a Node/JS service to Python
- Creating an OpenAI-compatible proxy/routing layer
- Building any FastAPI service with Docker deployment

## Project Layout

```
project/
├── engines/          # Core business logic (pluggable computation)
│   ├── __init__.py
│   └── <engine>.py
├── providers/        # External integrations (LLM APIs, DBs, etc.)
│   ├── __init__.py
│   └── <provider>.py
├── main.py           # FastAPI app entry point
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── .venv/            # local venv
```

## Key Patterns

### Engine / Provider Separation
- `engines/` — pure logic, no HTTP, no env vars. Receives primitives, returns results.
- `providers/` — wraps external APIs (OpenRouter, OpenAI, DBs). Handles auth, retries, timeouts.
- `main.py` — routes only. Validates input, calls engines/providers, formats responses.

### Regex Pitfall: Porting JS → Python
JavaScript `[^]{0,200}` means "any character 0-200 times". In Python `re`, `[^]` inside a character class is an **unterminated negated class** (error). Use `[\s\S]{0,200}` instead.

```python
# WRONG — raises re.error: unterminated character set
re.compile(r"\bword\b[^]{0,200}\bother\b")

# RIGHT
re.compile(r"\bword\b[\s\S]{0,200}\bother\b")
```

### Rate Limiting with slowapi
```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter

@app.post("/v1/endpoint")
@limiter.limit("60/minute")
async def endpoint(request: Request, ...):
    ...
```

### OpenAI-Compatible Response Format
Return this shape for SDK drop-in compatibility:
```python
{
    "id": f"chatcmpl-{secrets.token_hex(12)}",
    "object": "chat.completion",
    "created": int(time.time()),
    "model": model,
    "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
    "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
}
```

### Docker Setup
Use `python:3.11-slim` base. Always set `PYTHONUNBUFFERED=1`. Expose the port the app listens on.

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
ENV PYTHONUNBUFFERED=1
EXPOSE 7860
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "7860"]
```

### Playwright Scraping in Docker (CRITICAL PITFALL)
When using Playwright for web scraping inside Docker, `python:3.11-slim` does NOT include the browser runtime dependencies. `playwright install-deps chromium` will FAIL on missing packages (`ttf-ubuntu-font-family`, `ttf-unifont` on some Debian versions).

**The fix:** install the runtime deps manually in the Dockerfile and skip `playwright install-deps`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \
    curl wget ca-certificates \
    libnss3 libnspr4 libatk-bridge2.0-0 libatk1.0-0 \
    libcups2 libdrm2 libdbus-1-3 libxkbcommon0 \
    libxcomposite1 libxdamage1 libxfixes3 libxrandr2 \
    libgbm1 libpango-1.0-0 libcairo2 \
    libasound2 libatspi2.0-0 \
    fonts-liberation fonts-unifont \
    && rm -rf /var/lib/apt/lists/*

RUN pip install --no-cache-dir uv
COPY requirements.txt .
RUN uv pip install --system -r requirements.txt

# Install Chromium browser binary only (skip broken install-deps)
RUN python3 -m playwright install chromium

COPY . .

EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

**Key insight:** You need the apt deps AND the browser binary. The `playwright install-deps` script is a convenience wrapper that sometimes fails on newer/older Debian packages. Installing manually is more reliable.

### Jinja2 Static File Frontend (Dark Terminal UI)
When the user wants a designed dashboard served by FastAPI, use Jinja2 templates + static files instead of a separate frontend framework.

**Setup in `main.py`:**
```python
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path

app = FastAPI()

# Templates
templates_dir = Path(__file__).parent / "templates"
app.state.templates = Jinja2Templates(directory=str(templates_dir))

# Static files (CSS, JS)
static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
```

**Template pattern:** Use `{% extends "base.html" %}` blocks. Keep templates simple with HTMX for interactivity.

**Dark terminal aesthetic CSS variables** (the user prefers `#050507` bg + `#00d992` accent + JetBrains Mono):
```css
:root {
  --abyss: #050507;
  --panel: #0a0a0f;
  --surface: #0f0f15;
  --border: #1a1a25;
  --green: #00d992;
  --text: #c8c8d0;
  --font-mono: 'JetBrains Mono', monospace;
  --font-ui: 'Inter', sans-serif;
}
```

Add subtle noise overlay + scanlines for texture. See `templates/dark-terminal-base.html` under this skill.

## Environment Variables
- `PORT` — server port (default 7860)
- `HOST` — bind address (default 0.0.0.0)
- `CORS_ORIGIN` — set `*` for self-hosted open access
- Any provider keys (OpenRouter, OpenAI, etc.)
- Optional `GODMODE_API_KEY` for Bearer auth

## Dependencies (typical)
- `fastapi>=0.111.0`
- `uvicorn[standard]`
- `httpx>=0.27.0`
- `pydantic>=2.8.0`
- `python-dotenv>=1.0.0`
- `slowapi>=0.1.9`

## Pitfalls

1. **Never use `terminal(background=true)` for Docker commands** — the user explicitly forbids this. Use foreground with generous `timeout=` instead.
2. **Always fix JS→Python regexes** when porting — `[^]` is invalid in Python; use `[\s\S]`.
3. **Install deps in a venv first** to catch import errors before Docker build time.
4. **Keep `main.py` thin** — route validation + dispatch only. Business logic belongs in `engines/`.
5. **Python 3.14 + Jinja2 cache bug** — If `TemplateResponse()` crashes with `TypeError: cannot use 'tuple' as a dict key (unhashable type: 'dict')`, the Jinja2 environment cache is broken on Python 3.14. **Fix:** recreate the venv with Python 3.11 (`python3.11 -m venv .venv`). This is a known CPython 3.14 compat issue with Jinja2's internal cache key hashing.
