#!/usr/bin/env bash
# Scaffolds a new FastAPI service with the engine/provider pattern
set -e

NAME=${1:-my-api}
mkdir -p "$NAME"/{engines,providers}
cd "$NAME"

cat > requirements.txt << 'EOF'
fastapi>=0.111.0
uvicorn[standard]>=0.30.0
httpx>=0.27.0
pydantic>=2.8.0
python-dotenv>=1.0.0
slowapi>=0.1.9
EOF

cat > .env.example << 'EOF'
PORT=7860
HOST=0.0.0.0
CORS_ORIGIN=*
EOF

cat > Dockerfile << 'EOF'
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
ENV PYTHONUNBUFFERED=1
EXPOSE 7860
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "7860"]
EOF

cat > docker-compose.yml << 'EOF'
services:
  api:
    build: .
    ports:
      - "7860:7860"
    env_file: .env
EOF

cat > engines/__init__.py << 'EOF'
EOF

cat > providers/__init__.py << 'EOF'
EOF

cat > main.py << 'EOF'
import os
from fastapi import FastAPI

app = FastAPI(title="My API", version="0.1.0")

@app.get("/v1/health")
async def health():
    return {"status": "ok"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", "7860")))
EOF

echo "Project '$NAME' scaffolded. Run: cd $NAME && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
