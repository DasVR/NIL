---
name: client-portal-auth
category: software-development
description: Auth patterns for small-business client portals. Replaces email-heavy flows with PIN-based self-activation, admin-controlled access keys, and simple invite mechanisms that work for non-technical users.
---

## When to use

- Building a client portal where the admin onboardstradespeople, small business owners, or other non-technical users
- Supabase Auth invite emails are hitting rate limits (default: 2/hour on free tier)
- Clients don't check email reliably or find magic links confusing
- You want to text or verbally share access credentials instead of email
- The target users are plumbers, HVAC techs, landscapers, local service businesses

## When NOT to use

- Enterprise SaaS with SSO/SAML requirements
- Consumer apps where users self-register freely
- Apps requiring OAuth (Google/GitHub sign-in) as the primary flow

## Pattern: Access Key Self-Activation

### Overview

```
Admin creates client record → auto-generates 8-char PIN
Admin texts PIN to client contact
Client visits /dashboard/login → "Activate with key" tab
Client enters email + PIN + chooses password
Edge function validates PIN, creates auth user, links profile, burns PIN
Auto-signed in → redirected to /dashboard
```

### Schema

```sql
-- Add to your clients table
alter table clients
  add column access_key text,
  add column access_key_created_at timestamptz;

create index clients_access_key_idx on clients (access_key) where access_key is not null;
```

### Access Key Generation

```typescript
const KEY_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/I/L ambiguity

function generateAccessKey(length = 8): string {
  let key = "";
  for (let i = 0; i < length; i++) {
    key += KEY_CHARS[Math.floor(Math.random() * KEY_CHARS.length)];
  }
  return key;
}
```

### Edge Function: verify-access-key

The edge function receives `{ email, password, access_key }` and:

1. Validates inputs (email format, password length ≥ 10)
2. Looks up client by access key
3. Optionally verifies email matches the client record
4. Creates auth user with `email_confirm: true` (key IS the verification)
5. Updates profile: `role = 'client', client_id = client.id`
6. Burns the key by setting `access_key = null`
7. Returns `{ ok: true, client_id }`

See `references/verify-access-key.ts` for full implementation.

**Deploy:**
```bash
supabase functions deploy verify-access-key
```

**Required env vars:** `SB_URL`, `SERVICE_ROLE_KEY`

### Frontend: Login Page

Add a third tab to the login page alongside "Sign in" and "Request access":

```typescript
type Mode = "signin" | "request" | "activate";

const tabs = [
  { mode: "signin", label: "Sign in" },
  { mode: "request", label: "Request access" },
  { mode: "activate", label: "Activate with key" },
];
```

Fields for activate mode:
- Email (must match client's email in the database)
- Access key (the PIN from admin)
- Password (new password, min 10 chars)

POST to the edge function, then immediately sign in:

```typescript
const res = await fetch(functionsUrl("verify-access-key"), {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    apikey: supabaseAnonKey,
    Authorization: `Bearer ${supabaseAnonKey}`,
  },
  body: JSON.stringify({ email, password, access_key: key }),
});

if (!res.ok) { /* show error */ return; }

// Auto-sign in
await supabase.auth.signInWithPassword({ email, password });
router.replace("/dashboard");
```

### Admin Panel Integration

**Creating a client:**
```typescript
const key = generateAccessKey();
await createClient({
  business_name: "Northline Plumbing",
  email: "boss@northline.com",
  access_key: key,
});
// Show: "Created! Access key: X7K9P2M3"
```

**Client detail page:**
- Show current key in monospace with copy button
- "Regenerate key" button (invalidates old, creates new)
- "Generate key" if none exists

### Security

- Single-use: key is burned on first activation
- Expiration: add `access_key_created_at` and check `now() - created_at < interval '7 days'`
- Ambiguous character avoidance: no `0`/`O`, `1`/`I`/`L`
- Uppercase normalization: client input normalized to uppercase before lookup
- Email matching: optional but recommended — prevents someone with a leaked key from activating with a different email

## Pattern Comparison

| Approach | Pros | Cons |
|----------|------|------|
| Supabase invite emails | Built-in, no extra code | Rate limits (2/hr free tier), tokens expire, clients don't check email |
| OAuth (Google/GitHub) | Familiar to tech users | Confusing for tradespeople, requires account on third party |
| Magic links | No password to remember | Still email-dependent, link expiration issues |
| **Access keys (this skill)** | Text-friendly, instant, no rate limits, single-step | Admin must generate and share key manually |

## Pattern: Push Notifications (ntfy)

Admin shouldn't need to log in to know a lead came in or a client activated. Wire ntfy into every significant event.

### Setup

Run ntfy in your Docker stack:
```yaml
ntfy:
  image: binwiederhier/ntfy
  command: serve
  ports:
    - "8091:80"
```

Reverse proxy via Caddy:
```
@notify host notify.dasdev.net
handle @notify {
    reverse_proxy ntfy:80
}
```

Subscribe in the ntfy app (iOS/Android) to:
- `https://notify.dasdev.net/dasdev-leads`
- `https://notify.dasdev.net/dasdev-clients`

### Where to notify

**Edge function (verify-access-key):**
```typescript
try {
  await fetch("https://notify.dasdev.net/dasdev-clients", {
    method: "POST",
    body: `Workspace activated: ${client.business_name}\nEmail: ${email}`,
  });
} catch { /* ignore network errors */ }
```

**Frontend (after createClient in admin):**
```typescript
import { notifyNewClient } from "@/lib/admin";
// ...
const key = generateAccessKey();
const client = await createClient({ business_name, email, access_key: key });
await notifyNewClient(client, key);
```

### Notification helpers (admin.ts)

```typescript
export async function notifyNewLead(payload: { name: string; email: string; message: string }) {
  try {
    await fetch("https://notify.dasdev.net/dasdev-leads", {
      method: "POST",
      body: `New lead: ${payload.name} (${payload.email})\n${payload.message}`,
    });
  } catch { /* ignore */ }
}

export async function notifyNewClient(client: ClientRow, accessKey?: string | null) {
  try {
    const body = accessKey
      ? `New client: ${client.business_name}\nAccess key: ${accessKey}`
      : `New client: ${client.business_name}`;
    await fetch("https://notify.dasdev.net/dasdev-clients", { method: "POST", body });
  } catch { /* ignore */ }
}
```

## Admin UI Improvements

**Linked accounts section (client detail page):**
Show every profile linked to the client with their role. Add a toggle to promote/revoke admin status without leaving the page.

**Access key display:**
Show the key in large monospace orange text. Include a "Copy" button and "Regenerate" action. If no key exists, show a "Generate key" button so the admin doesn't have to navigate away.

**Convert lead → instant key:**
When converting a lead to a client, auto-generate the access key and surface it in the success toast/notice. The admin can immediately text it.

## Pitfalls

**Pitfall — Deployed site still shows old login tabs after code change:**
The static build is served from Docker/NGINX. After `npm run build` passes locally, run `./deploy.sh` to rebuild the container and restart it. Then do a **hard refresh** (`ctrl + shift + r`) — browsers cache the old JS bundles aggressively.

**Pitfall — Making a new auth account and losing admin access:**
If you sign up with a new email (or in a new browser), that profile starts with `role = 'pending'` and `is_admin = false`. The existing admin account is not affected, but you need to set `is_admin = true` in the Supabase dashboard → Table Editor → `profiles` table for the new account to see the admin panel. Prefer adding an admin toggle in the client detail UI so you don't need the dashboard.

**Pitfall — Admin login error says "email and access key do not match":**
This is the generic Supabase sign-in error (same for wrong password, wrong email, or unconfirmed account). The code intentionally obscures which one it is for security. If you're sure the password is right, try: hard refresh, incognito window, or check Supabase Auth → Users to confirm the account exists and is confirmed.

**Pitfall — Supabase free tier email rate limits:**
Default `auth.rate_limit.email_sent = 2`. If you're inviting more than 2 clients per hour, you'll hit `429: email rate limit exceeded`. Access keys bypass this entirely.

**Pitfall — `admin.auth.admin.createUser` requires service_role:**
The edge function must have `SERVICE_ROLE_KEY` set. Without it, `createUser` returns a generic 500. Always validate env vars at startup.

**Pitfall — Existing users re-activating:**
If a client already exists in `auth.users` (e.g. from a prior request-access signup), `createUser` will fail with "already registered." Handle this by finding the existing user, updating their password, and linking their profile.

**Pitfall — Key case sensitivity:**
Clients may type lowercase. Always normalize to uppercase: `accessKey.trim().toUpperCase()` before sending and when generating.

**Pitfall — Profile trigger conflicts:**
If you have `on_auth_user_created` trigger that inserts a `pending` profile, the edge function's explicit `update profiles set role='client'` may race. Use `upsert` or ensure the trigger does `on conflict do nothing`.

**Pitfall — "Request access" tab stays broken if email auth is rate-limited:**
If Supabase email confirmation is unreliable (free tier), remove the "Request access" tab entirely from the login page. Keep only "Sign in" and "Activate with key". This prevents user frustration from broken signup flows.

**Pitfall — Removing a client requires cascade-aware schema:**
When deleting a client, Supabase RLS + `on delete cascade` must be configured on all child tables (projects, updates, messages, files, care plans). Verify this before exposing a "Remove" button in the admin UI. The frontend should use `deleteClient(clientId)` from admin.ts and redirect after success.

**Pitfall — Admin clients list becomes unwieldy at 10+ records:**
Add a search bar (filter by name/contact/email) and status filter tabs (All / Active / Paused / Archived). Show the access key inline so admins don't need to click into detail to copy it. Display status as colored badges (green active, orange paused, gray archived). Add a "Remove" button with a JS `confirm()` step.

**Pitfall — Converting a lead should surface the key immediately:**
When an admin clicks "Convert to client" on a lead, the flow must:
1. Create the client record with an auto-generated key
2. Send an ntfy notification
3. Show the key in the success notice (so admin can text it right then)
4. Mark the lead status as "converted"

This replaces the old "Send portal invite" button that tried to use Supabase email invites.

## Pattern: Admin Client List — Search, Filter, and Inline Actions

The default list shows every client in insertion order. Modernize it:

```typescript
// AdminClients.tsx — key additions
const [search, setSearch] = useState("");
const [filter, setFilter] = useState<"all" | "active" | "paused" | "archived">("all");
const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

const filtered = useMemo(() => {
  let list = clients;
  if (filter !== "all") list = list.filter((c) => c.status === filter);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (c) =>
        c.business_name.toLowerCase().includes(q) ||
        (c.contact_name ?? "").toLowerCase().includes(q) ||
        (c.email ?? "").toLowerCase().includes(q)
    );
  }
  return list;
}, [clients, filter, search]);
```

Each row shows: business name, contact info, colored status badge, current access key (if any), and a "Remove" button with a two-step confirm.

## Pattern: Client Detail Page — Admin Toggle + Remove

Add two actions to the client detail nav:

1. **Remove client**: `window.confirm()` then `deleteClient(id)` + redirect to `/admin/clients`
2. **Linked accounts** section: show each profile with role, with "Make admin" / "Revoke admin" toggle button

The `deleteClient` helper in admin.ts:
```typescript
export async function deleteClient(clientId: string): Promise<void> {
  const { error } = await getSupabase()
    .from("clients")
    .delete()
    .eq("id", clientId);
  if (error) throw error;
}
```

## Pattern: ntfy in Edge Functions (not just frontend)

Edge functions should also notify — not just the frontend. This guarantees notifications even if the admin is not actively using the dashboard when a client activates.

**verify-access-key edge function (after successful activation):**
```typescript
// After profile update and key burn:
try {
  const ntfyUrl = Deno.env.get("NTFY_URL") ?? "https://notify.dasdev.net/dasdev-clients";
  await fetch(ntfyUrl, {
    method: "POST",
    body: `Workspace activated: ${client.business_name}\nEmail: ${email}`,
  });
} catch { /* ignore network errors */ }
```

**submit-lead edge function (after saving lead):**
```typescript
try {
  const ntfyUrl = Deno.env.get("NTFY_URL") ?? "https://notify.dasdev.net/dasdev-leads";
  await fetch(ntfyUrl, {
    method: "POST",
    body: `New lead: ${name} (${email})\n${message}\nServices: ${services}`,
  });
} catch { /* ignore */ }
```

This means admin notifications work from two sources: frontend actions (admin creating a client) and backend events (client activating or submitting a lead).

## Pattern: Schema Review for Delete Cascade

Before adding client removal, verify your migration has:

```sql
-- profiles
client_id uuid references clients (id) on delete set null

-- projects
client_id uuid not null references clients (id) on delete cascade

-- updates
project_id uuid not null references projects (id) on delete cascade

-- messages
client_id uuid not null references clients (id) on delete cascade

-- files
client_id uuid not null references clients (id) on delete cascade
project_id uuid references projects (id) on delete set null

-- care_plans
client_id uuid not null references clients (id) on delete cascade
```

If any child table uses `on delete restrict`, the delete will fail with a foreign key error. Fix the migration before exposing the remove button.

## Pattern: Time-Limited Review Links

Share temporary preview URLs with clients so they can review deliverables (web design, branding assets, landing pages, etc.) and leave structured feedback without needing portal access.

### Schema

```sql
-- project_reviews stores the time-limited token and expiry
-- review_feedback stores anonymous or named comments left on that link
```

See `references/review-links-schema.sql` for the full migration.

### How it works

```
Admin creates project → checks "Enable client review link"
  → auto-generates 12-char token
  → optional external_url (staging site, Figma, Drive, etc.)
  → expiry: 3 / 7 / 14 / 30 days
  → stores token in project_reviews table
  → shows admin the link: dasdev.net/review?token=xxx

Anyone with the link can:
  → see project name + preview URL
  → leave feedback (name/email optional)
  → read past feedback

Link dies automatically when expiry hits.
Admin can manually deactivate from client detail page.
```

### Client library

See `references/review-links-client-lib.ts` for full implementation. Key functions:

```typescript
createReviewLink({ project_id, external_url?, expires_at? })  → ProjectReviewRow
deactivateReviewLink(reviewId)                                 → void
fetchReviewByToken(token)                                      → PublicReview | null
submitFeedback({ review_id, body, author_name?, author_email? }) → void
fetchProjectReviews(projectId)                                 → ProjectReviewRow[]
```

### Token generation

Same pattern as access keys but longer and mixed-case:

```typescript
const TOKEN_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghijkmnopqrstuvwxyz";
function generateToken(length = 12): string { ... }
```

### RLS policy summary

| Table | Select | Insert | Update |
|-------|--------|--------|--------|
| `project_reviews` | Anyone (token is the secret) | Admin only | Admin only |
| `review_feedback` | Admin only | Anyone, but only if review is active + not expired | Admin only |

### Static export gotcha

Dynamic `/review/[token]` routes don't work with `output: 'export'`. Use a single page at `/review` that reads `?token=` from query params via `useSearchParams()`.

### Admin UI integration

When creating a project in the admin panel:
1. Checkbox "Enable client review link" (default on)
2. Optional custom review URL (defaults to project URL)
3. Expiry picker: 3 / 7 / 14 / 30 days
4. After creation, show the generated link with copy button
5. Existing projects show active/inactive links on the card with deactivate option

### Client dashboard integration

On the client's `/dashboard`, each project card shows its active review links so the client can copy and share them too.

### Pitfall — review link leaks are real

Anyone with the token can read the review and leave feedback. Don't use guessable tokens. Keep length ≥ 12 with mixed alphanumeric characters. If a link leaks, deactivate it and generate a new one.

### Pitfall — Supabase free tier and `anon` RLS

The `anon` role can read reviews and insert feedback by policy design. Make sure `supabase/auth` is configured with the `anon` key actually usable (it is by default). If you lock down `anon` completely, the public review page will break.

### Pitfall — Migration numbering collisions in Supabase

If an old migration already occupies `0004_storage.sql` and you add `0004_project_reviews.sql`, the CLI will skip the new one because `0004` is already recorded in `supabase_migrations.schema_migrations`. Always check `supabase migration list` first. If there's a collision, renumber the new migration to the next available slot (e.g., `0007`, `0008`) before running `supabase db push`.

### Pitfall — Edge function deployed but returns 404

If the edge function exists in the repo but the live Supabase project returns `{"code":"NOT_FOUND"}`, the function was never deployed. Run `supabase functions deploy <name>` and verify with `curl` before testing from the browser. The browser's generic "something went wrong" hides the real 404.

## References

- `references/verify-access-key.ts` — Full edge function implementation
- `references/verify-access-key-with-ntfy.ts` — Updated edge function with ntfy notification
- `references/admin-clients-list.tsx` — Searchable, filterable client list with remove
- `references/review-links-schema.sql` — `project_reviews` + `review_feedback` migrations
- `references/review-links-client-lib.ts` — Public fetchers + admin helpers
