-- Time-limited review links for client deliverables
--
-- Run: supabase migration new project_reviews
-- Then: supabase migration new review_feedback
-- Then: supabase migration new review_rls

create table project_reviews (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects (id) on delete cascade,
  token text not null unique,
  external_url text,
  expires_at timestamptz not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index project_reviews_token_idx on project_reviews (token);
create index project_reviews_project_idx on project_reviews (project_id);
create index project_reviews_expiry_idx on project_reviews (expires_at) where active = true;

create trigger project_reviews_touch before update on project_reviews
  for each row execute function public.touch_updated_at();

create type review_feedback_status as enum ('open', 'resolved', 'wontfix');

create table review_feedback (
  id uuid primary key default gen_random_uuid(),
  review_id uuid not null references project_reviews (id) on delete cascade,
  author_name text,
  author_email text,
  body text not null,
  status review_feedback_status not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index review_feedback_review_idx on review_feedback (review_id, created_at desc);

create trigger review_feedback_touch before update on review_feedback
  for each row execute function public.touch_updated_at();

-- RLS: anyone can read a review by token; only admin manages links.
alter table project_reviews enable row level security;
alter table review_feedback enable row level security;

create policy "reviews_select_anon" on project_reviews
  for select to anon, authenticated using (true);
create policy "reviews_insert_admin" on project_reviews
  for insert to authenticated with check (public.is_admin());
create policy "reviews_update_admin" on project_reviews
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Anonymous feedback allowed only if review is active and not expired.
create policy "feedback_insert_anon" on review_feedback
  for insert to anon, authenticated
  with check (
    exists (
      select 1 from public.project_reviews
      where public.project_reviews.id = review_feedback.review_id
        and public.project_reviews.active = true
        and public.project_reviews.expires_at > now()
    )
  );

create policy "feedback_select_admin" on review_feedback
  for select to authenticated using (public.is_admin());
