---
name: cursor
description: "Set up and manage Cursor IDE, CLI, and Self-Hosted Pool workers."
version: 1.1.0
author: Finn
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Cursor, Self-Hosted, Cloud-Agents, CLI, IDE]
    related_skills: [claude-code, codex, opencode, hermes-agent]
---

# Cursor — Setup, CLI, and Self-Hosted Pool

Guide for installing Cursor's CLI/agent tool, registering self-hosted workers (Cursor Cloud Agents on your own hardware), and integrating with local model providers like Ollama.

## Prerequisites

- A Cursor account (free or paid plan)
- Linux server or desktop (x64 or ARM64)
- `curl`, `bash`, standard POSIX tools

## Part 1: Cursor Agent CLI Install

Cursor's headless agent is installed via a curl-to-bash script.

### Install Command
```bash
curl https://cursor.com/install -fsS | bash
```

### What the script does
1. Detects OS/arch (`uname -s` / `uname -m`)
2. Creates `~/.local/share/cursor-agent/versions/<version>/`
3. Downloads `agent-cli-package.tar.gz` from `downloads.cursor.com`
4. Extracts the `cursor-agent` binary
5. Symlinks:
   - `~/.local/bin/agent` → `cursor-agent`
   - `~/.local/bin/cursor-agent` → `cursor-agent`
6. Checks `~/.local/bin` is in PATH

### After install
```bash
# Verify
which agent
agent --version

# If ~/.local/bin is not in PATH, add it:
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

---

## Part 1b: Cursor TypeScript SDK (Programmatic Agents)

Cursor also publishes an **official TypeScript SDK** — `@cursor/sdk` on npm — that lets you spawn Cursor agents programmatically from Node.js scripts. This is separate from the CLI install above and is the preferred path when you want other tools (like Finn/Hermes) to invoke Cursor's models and agents.

### Install
```bash
npm install @cursor/sdk
```

### Get an API Key
1. Go to `https://cursor.com/dashboard`
2. Click **Settings** tab
3. Scroll to **Advanced** → **API Keys**
4. Click **New API Key**
5. Copy the key and store it securely (e.g., `~/.cursor/api_key`)

### Basic Usage (Verified Working Pattern — Cloud Mode)

The Agent has `.send(prompt)` (returns a Run object). To get the final result, **await `run.streamPromise`** first, then read `run._result` and `run._status`.

```typescript
const { Agent, configureCursorSdk } = require("@cursor/sdk");
configureCursorSdk({ apiKey: process.env.CURSOR_API_KEY });

const agent = await Agent.create({ cloud: true });
const run = await agent.send("Implement a REST API for user auth", {
  model: { id: "composer-2.5" },  // or "claude-opus-5", "grok-4.5", etc.
});

await run.streamPromise;        // REQUIRED — waits for stream to finish

console.log(run._result);       // agent's output text
console.log(run._status);       // "finished" | "running" | "failed"
console.log(run.id);            // run UUID
console.log(run._durationMs);   // time taken
```

> **Note:** The older docs reference `.prompt()` — that method does not exist in `@cursor/sdk@1.0.27`. Always use `.send()` + `await run.streamPromise`.

### Running on Cursor Cloud vs Local
- **Cloud** (`cloud: true`) — runs on Cursor Cloud, no local file access, most reliable
- **Local** (`local: { cwd: process.cwd() }, model: { id: "composer-2.5" }`) — runs on your machine, edits local files directly
  - ⚠️ Local mode requires `model` in the `create()` options, not in `.send()`
  - ⚠️ Local agents do NOT return a summary in `run._result`; they write files directly to disk. Verify file changes with `ls` after the run.
- Both consume your Cursor subscription quota

### Local Mode File Editing (Verified Pattern)

When using local mode to actually write files on disk (e.g. building a project):

```typescript
const agent = await Agent.create({
  local: { cwd: "/home/das/projects/my-app" },
  model: { id: "composer-2.5" },
});
const run = await agent.send("Create a dark terminal CSS file in the current directory");
await run.streamPromise;
// Local agents write files directly — check the filesystem:
// run._result may be empty/null, but files ARE modified
```

### Bridge Pattern for Hermes/Finn (Local Mode — Verified Working)

Since Hermes runs in Python but the SDK is Node.js, the bridge is a small Node.js script that Hermes calls via `terminal`:

```javascript
// cursor-bridge.js — LOCAL MODE (edits files on disk)
const { Agent, configureCursorSdk } = require("@cursor/sdk");
configureCursorSdk({ apiKey: process.env.CURSOR_API_KEY });

async function main() {
  const prompt = process.argv[2];
  const modelFlag = process.argv.find(arg => arg.startsWith("--model="));
  const modelId = modelFlag ? modelFlag.split("=")[1] : "composer-2.5";

  const agent = await Agent.create({
    local: { cwd: process.env.CURSOR_CWD || process.cwd() },
    model: { id: modelId },
  });
  const run = await agent.send(prompt);
  await run.streamPromise;                    // REQUIRED

  console.log(JSON.stringify({
    id: run.id,
    status: run._status,
    result: run._result,
    model: { id: modelId },
    durationMs: run._durationMs,
  }, null, 2));
}

main().catch(console.error);
```

Then from Finn/Hermes:
```bash
export CURSOR_API_KEY=$(cat ~/.cursor/api_key)
export CURSOR_MODEL=composer-2.5
export CURSOR_CWD=/home/das/projects/my-app
node /home/das/scripts/cursor-bridge.js "Implement feature X"
```

**Important:** In local mode, `run._result` is often empty because the agent writes files directly. Always verify by checking the filesystem (`ls -la`) after a local run.

> **Critical pitfall — August 2026:** Local mode sometimes returns a **partial JSON object** with only `id` and `model` keys, omitting `status`, `result`, and `durationMs` entirely. This is NOT a failure — the agent still wrote files to disk. Always fall back to filesystem verification when the response looks sparse.

```javascript
// Defensive result extraction
await run.streamPromise;
const result = {
  id: run.id ?? null,
  status: run._status ?? "unknown",
  result: run._result ?? "(local mode — check filesystem)",
  model: run._model ?? { id: modelId },
  durationMs: run._durationMs ?? null,
};
```

### Why This Matters
- **Finn uses Ollama** (free, local) for chat/personality
- **Finn spawns Cursor agents** (your subscription) for heavy coding, frontier reasoning, anything needing Claude/GPT/Composer
- No GitHub repo required — agents work on local directories or cloud VMs
- Your Cursor Pro subscription is the model backend; the SDK is the API

### Available Models (Verified August 2026)

List all available models dynamically:
```javascript
const { Cursor } = require("@cursor/sdk");
Cursor.models.list({}).then(models => {
  console.log(models.map(m => m.id));
});
```

Verified model IDs:
| Model ID | Notes |
|----------|-------|
| `composer-2.5` | Cursor's own agent model |
| `claude-opus-5` | Anthropic Opus 5 via Cursor |
| `claude-opus-4-8` | Opus 4.8 |
| `claude-sonnet-4` | Sonnet 4 |
| `grok-4.5` | Grok 4.5 |
| `gpt-5.2`, `gpt-5.4`, `gpt-5.6-luna` | GPT variants |
| `gemini-3.1-pro`, `gemini-3.6-flash` | Gemini |
| `kimi-k2.7-code`, `kimi-k3` | Kimi |

Model availability varies by plan and region. Use `Cursor.models.list({})` to check live availability.

### SDK Streaming Notes (August 2026)

`@cursor/sdk` bundles `rxjs@8.0.0-alpha.14` which has a broken `[Symbol.asyncIterator]`. Do NOT use `for await` or `.subscribe()` with async iteration.

**Correct pattern:** `.send()` returns a Run object. Always `await run.streamPromise` before reading results. Do NOT try to consume the stream manually via Observables.

```javascript
const run = await agent.send(prompt);
await run.streamPromise;                // waits for completion
console.log(run._result);               // final text output (cloud mode)
console.log(run._status);               // "finished" | "running" | etc.
```

If you need intermediate events (rare), collect via `.subscribe()` into a buffer:
```javascript
const events = [];
const sub = run.subscribe({
  next: (event) => events.push(event),
  error: (err) => console.error(err),
  complete: () => console.log("done"),
});
```
But for stability, just `await run.streamPromise` and read `run._result`.

### Post-Agent-Run Deployment: Caddy Reverse Proxy (Bind Mount Pattern)

When deploying an agent-built project behind Caddy (common for self-hosted stacks), you often need to add a new subdomain route. If Caddy's config is mounted as a **bind mount** (not a volume), `docker cp` to `/etc/caddy/Caddyfile` will fail with `device or resource busy`.

**Correct pattern:**
1. Find the host source path of the bind mount:
   ```bash
   docker inspect caddy --format='{{range .Mounts}}{{println .Source .Destination .Type}}{{end}}'
   # → /opt/stacks/foundation/caddy/Caddyfile /etc/caddy/Caddyfile bind
   ```
2. Edit the file directly on the **host filesystem**:
   ```bash
   sudo nano /opt/stacks/foundation/caddy/Caddyfile
   # Add your @subdomain host / handle @subdomain / reverse_proxy blocks
   ```
3. Reload Caddy from inside the container:
   ```bash
   docker exec caddy caddy reload --config /etc/caddy/Caddyfile
   ```

**Pitfall:** `docker cp container:/etc/caddy/Caddyfile /tmp/` works to read, but `docker cp /tmp/Caddyfile container:/etc/caddy/Caddyfile` fails for bind mounts. Always edit the source file on the host.

### Cloud Agent Filesystem Reliability (Critical — August 2026)

**Cloud agents CANNOT directly push to GitHub or write to host filesystem.** Their only reliable delivery mechanism is branch + PR. Agent creates branch (e.g. `cursor/nil-penpot-wireframes-c865`), commits locally, attempts push (often PUSH_BLOCKED due to no container creds). If push succeeds, GitHub PR auto-opens. Code trapped in container if push fails.

**After ANY agent run claiming file changes, ALWAYS verify with:**
```bash
git status --short          # should show modified/added files
git log --oneline -3       # should show new commit
git diff --stat            # summary of what changed
```

**The `files` array in bridge response is often empty** even when agent claims success. Never trust `result.files` alone.

**For mechanical/wiring tasks** (add API functions, wire stores, fix routes): write code directly on host + verify with `npm run build`. Do NOT delegate to cloud agent for mechanical work — it will claim success but leave nothing on disk.

**"Commit to master" does NOT work** — agent has no shared git state with your repo. It works in its own container at `/agent`. Tell it to create a branch + PR instead, then merge the PR.

### When Local Mode vs Cloud Mode

| Mode | Writes files to host? | Best for |
|------|----------------------|----------|
| **Local** | ✅ Yes, directly | File edits, scaffolding, incremental changes |
| **Cloud** | ❌ No (PR only) | Research, planning, architecture discussions |

**Correction to earlier guidance:** Previous versions of this skill claimed "cloud agents write files to disk with CURSOR_CWD". This is false. Cloud agents run in remote containers and file edits often don't reach the host. Only local mode agents (with `local: { cwd: ... }` in `Agent.create()`) write to the host filesystem, and even then you must verify with `git status`.

### Post-Agent-Run Verification Checklist

Cursor agents write code to disk in local mode, but they don't always install runtime dependencies or handle environment edge cases. **Always verify after a local run:**

| Check | Why It Matters | Fix |
|-------|--------------|-----|
| **Dependency version pins reverted?** | Agents may rewrite `requirements.txt`, `package.json`, etc. and drop critical pins | `git diff requirements.txt package.json` — restore pins before rebuilding |
| **Playwright browsers installed?** | Agents generate playwright scrapers but don't auto-install Chromium/FF/WebKit | `python3 -m playwright install chromium` |
| **Python version compatible?** | Generated code may use packages with known bugs on bleeding-edge Python (e.g., Jinja2 cache bug on Python 3.14) | Recreate venv with `python3.11` if imports fail |
| **Database file permissions?** | If the project was previously run in Docker, SQLite DBs may be owned by root | `sudo chown $(id -u):$(id -g) data/*.db` |
| **Missing pip packages?** | Agent may reference libraries not in `requirements.txt` | Check import errors, add deps, reinstall |
| **`.env` / config files exist?** | Agents often reference env vars they didn't create | `touch .env`, fill in required keys |
| **Static files served correctly?** | Templates reference CSS/JS that may 404 if paths are wrong | Open browser devtools → Network tab |

> **Rule of thumb:** Local mode agents write **code**, not **environments**. You are responsible for the runtime. Always run a smoke test (`python3 -c "from app.main import app"` or `uvicorn`) after an agent session before declaring victory.

> **Critical pitfall — August 2026:** When debugging version-specific library bugs (e.g., py-cord 2.8.1 breaking voice receive), a Cursor agent in local mode may see the pin as "wrong" and rewrite `requirements.txt` to the "latest" version. **Always diff `requirements.txt` and `package.json` after an agent run** when version pins are load-bearing. Verify the container actually has the intended version (`docker exec <c> python3 -c "import pkg; print(pkg.__version__)"`).

---

Cursor's dashboard has a **Self-Hosted** section where you can register your own machines as worker nodes. Cursor Cloud dispatches agent tasks to your machine instead of running them on Cursor's infra.

### Dashboard Settings
- **Enable Self-Hosted Pool** — creates a personal pool of workers
- **Enable Remote Control** — control local agents remotely from mobile/web
- **My Machines** — view connected workers and copy CLI connect commands

### How it works
1. You run the agent installer on your server (Part 1)
2. In Cursor dashboard, go to Settings → Self-Hosted
3. Enable "Self-Hosted Pool"
4. Click "My Machines" → get a connect/auth command
5. Run the auth command on your server to register it
6. Cursor Cloud can now dispatch agent tasks to your machine
7. Remote Control lets you trigger/manage agents from mobile

### Architecture
```
Cursor Cloud (cursor.com)
    ↓ dispatches tasks via websocket
Your Server (cursor-agent daemon)
    ↓ runs in your environment
Local files, Docker, shell, git
```

## Part 3: Ollama Integration

Cursor Desktop can use Ollama as a custom model provider, but this is typically configured in the desktop IDE settings, not on headless workers.

### Desktop IDE (Manual)
1. Open Cursor → Settings → Models
2. Add "Custom Model"
3. Point to your Ollama instance: `http://localhost:11434`
4. Select model (e.g., `codellama`, `deepseek-coder`, etc.)

### Headless Worker Limitation
The headless `cursor-agent` worker typically uses Cursor Cloud's model routing. To use Ollama on a worker, you'd need:
- The worker to have Ollama installed locally
- Cursor's agent to support custom model endpoints (feature availability varies)
- Or run a separate agent loop that calls Ollama directly (bypassing Cursor's cloud routing)

### Alternative: Hybrid Setup
If you want Cursor Cloud agents + Ollama local models in one system:
- Use Cursor Self-Hosted Pool for cloud-dispatched tasks
- Run a separate local agent (Claude Code, OpenCode, or custom) that uses Ollama
- Use Cursor CLI to trigger tasks on the cloud pool
- Use the local agent for private/offline work

## Pitfalls

### No official CLI npm package
The npm package `cursor` (v0.1.5) is a completely unrelated library (Node.js buffer cursor). Do NOT use `npm install -g cursor`. The official programmatic SDK is `@cursor/sdk` (v1.0.26+).

### SDK vs CLI confusion
- `@cursor/sdk` — TypeScript SDK for programmatic agents (npm install)
- `cursor-agent` — Headless CLI worker (curl-to-bash install)
- They serve different purposes; use the SDK when you need to spawn agents from code/Hermes

### curl|bash blocked by safety
The install script pipes curl to bash. Some systems or agent runtimes block this pattern. If blocked:
```bash
# Download first, inspect, then run
curl -fsSL https://cursor.com/install -o /tmp/cursor-install.sh
less /tmp/cursor-install.sh
bash /tmp/cursor-install.sh
```

### Self-Hosted Pool requires paid plan
As of mid-2026, the Self-Hosted Pool and Remote Control features require a Cursor paid plan (Pro, Teams, or Enterprise). Verify your plan supports it before attempting setup.

### Agent binary is NOT the IDE
`cursor-agent` is a headless worker binary, NOT the Cursor desktop IDE. The IDE (`.AppImage`, `.deb`, `.dmg`) is downloaded separately from cursor.com/download.

### Worker auth is session-scoped
The auth token from "My Machines" is typically time-limited or single-use. If the worker disconnects, you may need to re-auth from the dashboard.

### Firewall/websocket requirements
The worker maintains a persistent websocket connection to Cursor Cloud. If your server blocks outbound websockets (corporate firewall, strict iptables), the worker will fail to register.

## Commands

| Task | Command |
|------|---------|
| Install agent | `curl https://cursor.com/install -fsS \| bash` |
| Verify install | `which agent && agent --version` |
| Start agent (foreground) | `agent` |
| Connect to pool (from dashboard command) | `agent connect <token-from-dashboard>` |
| List sessions | `agent sessions` |

## Environment

| Variable | Purpose |
|----------|---------|
| `NO_COLOR` | Disables ANSI colors in installer output |

## When to use what

| Setup | Use when |
|-------|----------|
| Cursor Desktop IDE | Daily coding, pair programming, IDE features |
| Cursor CLI (`cursor-agent`) | CI/CD, headless automation, scripting |
| Cursor SDK (`@cursor/sdk`) | Programmatic agents from other tools (Finn/Hermes, scripts, apps) |
| Self-Hosted Pool | You want Cursor Cloud to run agents on YOUR hardware |
| Remote Control | Trigger agents from phone/tablet while AFK |
| Ollama + Cursor | You want local/private models alongside Cursor |

## Related Skills

- `claude-code` — Anthropic's autonomous coding agent CLI
- `opencode` — OpenCode CLI (alternative to Cursor/Claude Code)
- `codex` — OpenAI Codex CLI
- `hermes-agent` — This agent (Finn) itself

## Support Files

| File | Path | What It Is |
|------|------|------------|
| cursor-bridge.js | `templates/cursor-bridge.js` | Working Node.js bridge for Hermes/Finn — **local mode**, `await run.streamPromise`, returns JSON with `status`, `result`, `durationMs` |
| cursor-delegation-orchestrator.py | `templates/cursor-delegation-orchestrator.py` | Python orchestrator that delegates multi-wave coding tasks to Cursor agents via the bridge. Splits large projects into UI → scrapers → pipeline waves |
| sdk-research.md | `references/sdk-research.md` | Deep research on SDK capabilities, verified working paths, and what fails |
