#!/usr/bin/env python3
"""
Caddyfile Route Inserter
Inserts a new subdomain reverse-proxy block into an existing Caddyfile
just before a known anchor line (e.g., @godmode).

Usage:
    python3 /home/das/scripts/caddy-insert-route.py <caddyfile_path> <subdomain> <upstream_host> <upstream_port>

Example:
    python3 /home/das/scripts/caddy-insert-route.py /opt/stacks/foundation/caddy/Caddyfile leadvine leadvine 8000
"""
import sys
import shutil
from datetime import datetime

def insert_route(caddyfile_path: str, subdomain: str, upstream_host: str, upstream_port: int, anchor: str = "@godmode"):
    with open(caddyfile_path) as f:
        lines = f.readlines()

    route_block = (
        f"\t@{subdomain} host {subdomain}.dasdev.net\n"
        f"\thandle @{subdomain} {{\n"
        f"\t\treverse_proxy {upstream_host}:{upstream_port}\n"
        f"\t}}\n\n"
    )

    for i, line in enumerate(lines):
        if anchor in line:
            lines.insert(i, route_block)
            break
    else:
        print(f"Anchor '{anchor}' not found. Appending to end.")
        lines.append("\n" + route_block)

    # Backup
    backup = f"{caddyfile_path}.bak.{datetime.now().strftime('%Y%m%d%H%M%S')}"
    shutil.copy2(caddyfile_path, backup)

    with open(caddyfile_path, "w") as f:
        f.writelines(lines)

    print(f"Route inserted. Backup: {backup}")
    print(f"Reload Caddy: docker exec caddy caddy reload --config /etc/caddy/Caddyfile")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <caddyfile> <subdomain> <upstream_host> [upstream_port=8000]")
        sys.exit(1)
    insert_route(
        sys.argv[1],
        sys.argv[2],
        sys.argv[3],
        int(sys.argv[4]) if len(sys.argv) > 4 else 8000,
    )
