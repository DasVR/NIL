#!/usr/bin/env python3
"""
Cursor Agent Orchestrator for LeadVine MVP
Delegates coding tasks to Cursor SDK agents in local mode.
"""
import subprocess
import json
import os
import sys
from pathlib import Path

CURSOR_API_KEY = Path.home() / ".cursor" / "api_key"
CWD = "/home/das/projects/leadvine"
BRIDGE = "/home/das/scripts/cursor-bridge.js"

def call_cursor(prompt: str, model: str = "composer-2.5") -> dict:
    """Call a Cursor agent via the bridge and return the result."""
    env = os.environ.copy()
    env["CURSOR_API_KEY"] = CURSOR_API_KEY.read_text().strip()
    env["CURSOR_CWD"] = CWD

    # Build the JS snippet for local mode
    js = f'''
const {{ Agent, configureCursorSdk }} = require("@cursor/sdk");
configureCursorSdk({{ apiKey: process.env.CURSOR_API_KEY }});
(async () => {{
  try {{
    const agent = await Agent.create({{ local: {{ cwd: process.env.CURSOR_CWD }}, model: {{ id: "{model}" }} }});
    const run = await agent.send({json.dumps(prompt)});
    await run.streamPromise;
    console.log(JSON.stringify({{
      status: run._status,
      result: run._result,
      durationMs: run._durationMs,
    }}));
  }} catch (err) {{
    console.error(JSON.stringify({{ error: err.message || String(err) }}));
    process.exit(1);
  }}
}})();
'''
    result = subprocess.run(
        ["node", "-e", js],
        capture_output=True,
        text=True,
        env=env,
        timeout=300,
    )
    # Try to parse JSON from last non-empty line
    lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
    for line in reversed(lines):
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            continue
    return {"error": "no json output", "raw_stdout": result.stdout, "raw_stderr": result.stderr}


def main():
    task = sys.argv[1] if len(sys.argv) > 1 else "help"

    if task == "ui":
        prompt = (
            "In the current directory (/home/das/projects/leadvine), build a complete dark terminal-themed "
            "web UI for a lead generation dashboard called LeadVine. The existing FastAPI app uses "
            "Jinja2 templates in app/templates/ and static files in app/static/.\n\n"
            "Create/update these files:\n"
            "1. app/templates/base.html — base template with sidebar nav, dark terminal theme "
            "(bg #050507, accent #00d992, font JetBrains Mono from Google Fonts), scanline overlay effect. "
            "Include blocks for content.\n"
            "2. app/templates/dashboard.html — extends base.html with stat cards (total leads, avg score, "
            "recent scans, pipeline value), a leads table with sortable columns (company, contact, score, status, source, date), "
            "and a quick scan config panel.\n"
            "3. app/templates/lead_detail.html — extends base.html, shows single lead info with tabs for "
            "overview, website analysis, contact history, notes.\n"
            "4. app/templates/pipeline.html — kanban-style pipeline board (Discovered, Contacted, Replied, Meeting, Client, Lost) "
            "with cards that can be dragged (or at least clickable to change status).\n"
            "5. app/static/css/terminal.css — all the dark terminal styling, glowing borders, monospace text, "
            "accent colors, scanlines, smooth transitions.\n"
            "6. app/static/js/dashboard.js — sortable tables, search/filter, basic interactivity.\n\n"
            "Read the existing app/main.py, app/models.py, and app/routers/ to understand the data structures "
            "and make templates that match the existing backend fields. Don't break existing code."
        )
        print("[+] Delegating UI build to Cursor agent...")
        result = call_cursor(prompt)
        print(json.dumps(result, indent=2))

    elif task == "scrapers":
        prompt = (
            "In the current directory (/home/das/projects/leadvine), build the scraper engine for LeadVine.\n\n"
            "The existing app has a scrapers/ directory. Create these files:\n"
            "1. app/scrapers/google_maps.py — scrapes Google Maps for businesses by category + location. "
            "Use playwright or httpx + BeautifulSoup. Extract: name, address, phone, website, rating, review_count, hours, category. "
            "Handle pagination, rate limiting, and save results to the database using SQLAlchemy models from app/models.py.\n"
            "2. app/scrapers/website_checker.py — analyzes a business website. Check: HTTP status, SSL certificate validity, "
            "mobile responsiveness (viewport meta, basic media query detection), load speed (time request), tech stack detection "
            "(WordPress, Wix, Squarespace, React, etc. via headers/meta tags), has_contact_form detection, has_booking detection, "
            "SEO basics (title, meta description, h1 count, alt tags). Return a structured dict.\n"
            "3. app/scrapers/scorer.py — takes the website checker output and calculates a Website Score (0-100) using the rubric:\n"
            "   - Has website: 30 pts\n"
            "   - Custom domain (not subdomain like foo.wixsite.com): 15 pts\n"
            "   - Valid SSL: 10 pts\n"
            "   - Mobile responsive: 15 pts\n"
            "   - Modern design (detected via CSS flexbox/grid, recent HTML): 10 pts\n"
            "   - Load speed <2s=10pts, 3-5s=5pts, >5s=0pts\n"
            "   - SEO basics (title + meta desc + h1): 5 pts\n"
            "   - Has contact form: 5 pts\n"
            "4. Update app/routers/scans.py to expose endpoints: POST /scans/start (category, location, max_results), "
            "GET /scans/{scan_id}/status, GET /scans/{scan_id}/results. Use BackgroundTasks for async scraping.\n"
            "5. Update app/routers/leads.py with endpoints: GET /leads (list with filters), GET /leads/{lead_id}, "
            "PATCH /leads/{lead_id}/status (update pipeline status), POST /leads/{lead_id}/note (add contact note).\n\n"
            "Read existing files first. Don't break existing code. Use the existing database models."
        )
        print("[+] Delegating scraper engine to Cursor agent...")
        result = call_cursor(prompt)
        print(json.dumps(result, indent=2))

    elif task == "pipeline":
        prompt = (
            "In the current directory (/home/das/projects/leadvine), build the pipeline and dashboard backend for LeadVine.\n\n"
            "1. Update app/routers/dashboard.py with endpoints:\n"
            "   - GET /dashboard/stats — returns total_leads, avg_score, recent_scans_count, pipeline_value, "
            "     leads_by_status counts (Discovered, Contacted, Replied, Meeting, Client, Lost)\n"
            "   - GET /dashboard/recent-scans — last 5 scans with status\n"
            "   - GET /dashboard/recent-leads — last 10 leads added\n"
            "2. Ensure app/models.py has all needed fields for the pipeline: status enum (discovered, contacted, replied, meeting, client, lost), "
            "score (int), source (str), notes (text), contact_history (JSON or related table), scan_id (foreign key), "
            "website_analysis (JSON), enriched_at (datetime).\n"
            "3. Add Alembic migration script if models change.\n"
            "4. Wire up app/main.py so the dashboard router serves the root path / with the dashboard template.\n"
            "5. Make sure the Docker setup works: docker-compose.yml should build and run the FastAPI app, "
            "mount the app directory for dev, expose port 8000, use a volume for SQLite data.\n\n"
            "Read existing files first. Don't break existing code."
        )
        print("[+] Delegating pipeline/dashboard backend to Cursor agent...")
        result = call_cursor(prompt)
        print(json.dumps(result, indent=2))

    else:
        print(f"Usage: python3 {sys.argv[0]} <ui|scrapers|pipeline>")
        sys.exit(1)


if __name__ == "__main__":
    main()
