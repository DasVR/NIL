const { Agent, configureCursorSdk } = require("@cursor/sdk");

const API_KEY = process.env.CURSOR_API_KEY;
if (!API_KEY) {
  console.error(JSON.stringify({ error: "CURSOR_API_KEY env var required" }));
  process.exit(1);
}

configureCursorSdk({ apiKey: API_KEY });

const prompt = process.argv[2];
const modelFlag = process.argv.find(arg => arg.startsWith("--model="));
const modelId = modelFlag ? modelFlag.split("=")[1] : "composer-2.5";

if (!prompt) {
  console.error(JSON.stringify({ error: "Usage: node cursor-bridge.js \"<prompt>\" [--model=<model-id>]" }));
  process.exit(1);
}

(async () => {
  try {
    // LOCAL MODE — edits files on disk in CURSOR_CWD
    const agent = await Agent.create({
      local: { cwd: process.env.CURSOR_CWD || process.cwd() },
      model: { id: modelId },
    });
    const run = await agent.send(prompt);

    // REQUIRED — wait for stream to finish before reading results
    await run.streamPromise;

    // Defensive: local mode can return partial JSON (only id + model, no status/result)
    const result = {
      id: run.id ?? null,
      status: run._status ?? "unknown",
      result: run._result ?? "(local mode — check filesystem)",
      model: run._model ?? { id: modelId },
      durationMs: run._durationMs ?? null,
    };

    console.log(JSON.stringify(result, null, 2));
  } catch (err) {
    console.error(JSON.stringify({ error: err.message || String(err) }, null, 2));
    process.exit(1);
  }
})();
