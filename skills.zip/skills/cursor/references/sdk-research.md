# Cursor SDK Research — August 2026 Session Notes (Verified)

Package: `@cursor/sdk@1.0.27`
Runtime: Node.js v22.22.1
Date: August 9, 2026

## What the docs say vs what actually works

| Claimed | Reality |
|---------|---------|
| `agent.prompt()` returns a result object | **`.prompt()` does NOT exist on Agent.** Method missing entirely. |
| Cloud mode `agent.send()` returns Observable with `.subscribe()` | `run.subscribe()` throws `TypeError: run.subscribe is not a function` on many runs. |
| `.subscribe()` with `next/error/complete` works | Works inconsistently. Sometimes present, sometimes absent. |
| `await run.streamPromise` then read `run._result` | **This is the ONLY stable pattern.** Verified for both cloud and local. |

## Verified Working Pattern (Both Cloud + Local)

```javascript
const { Agent, configureCursorSdk } = require("@cursor/sdk");
configureCursorSdk({ apiKey: process.env.CURSOR_API_KEY });

// Cloud mode
const agent = await Agent.create({ cloud: true });
const run = await agent.send("say hello world");
await run.streamPromise;
console.log(run._result);   // "Hello world!"
console.log(run._status);   // "finished"

// Local mode — edits files on disk in CURSOR_CWD
const agent2 = await Agent.create({
  local: { cwd: "/home/das/projects/my-app" },
  model: { id: "composer-2.5" },  // REQUIRED in local mode
});
const run2 = await agent2.send("Create a file called hello.txt");
await run2.streamPromise;
// run2._result may be empty/null in local mode
// but the file IS created on disk — verify with ls
```

## Key discoveries

1. **Local mode requires `model` in `create()`, not `.send()`**
   - Passing model to `.send()` throws: `[validation_error] Required`
   - Must be: `Agent.create({ local: { cwd: ... }, model: { id: "..." } })`

2. **Local mode result is often empty**
   - Cloud mode: `run._result` contains the agent's text response
   - Local mode: agent writes files directly; `run._result` may be `""` or `"no result"`
   - Always verify local runs by checking the filesystem

3. **rxJS asyncIterator is broken**
   - `for await (const event of run)` → `TypeError: observer is not async iterable`
   - `run.subscribe({ next: ..., error: ..., complete: ... })` → sometimes works, sometimes `run.subscribe is not a function`
   - The `.subscribe()` method is apparently added lazily or conditionally

4. **Agent object methods (confirmed at runtime)**
   - `agent.send(prompt, options?)` → returns Run object
   - `agent.close()` → cleanup
   - `agent.reload()` → reload context
   - `agent.listArtifacts()` → list generated artifacts
   - `agent.getUsage()` → usage stats
   - `agent.downloadArtifact(id)` → download artifact

5. **Run object keys (confirmed at runtime)**
   - `_status` — `"finished"`, `"running"`, `"failed"`, etc.
   - `_result` — final text output (cloud mode)
   - `_error` — error message if failed
   - `_durationMs` — elapsed time
   - `id` — run UUID
   - `agentId` — agent UUID
   - `streamPromise` — Promise that resolves when stream ends
   - `createdAt` — timestamp
   - `_model` — model info

## Environment setup

```bash
# Save API key securely
mkdir -p ~/.cursor
echo "crsr_..." > ~/.cursor/api_key
chmod 600 ~/.cursor/api_key

# Install SDK
npm init -y
npm install @cursor/sdk dotenv
```

## Workflow for delegating coding tasks

1. Check `which agent || which cursor-agent` — CLI may not be installed; SDK is the reliable path
2. Save user's API key to `~/.cursor/api_key` (chmod 600)
3. Ensure Node.js + npm available
4. Install `@cursor/sdk` + `dotenv` in a project or home directory
5. For file-editing tasks: use **local mode** with `model` in `create()`
6. For Q&A / reasoning tasks: use **cloud mode**
7. ALWAYS `await run.streamPromise` before reading results
8. For local mode, ALWAYS verify by listing files after the run
9. Agent may return `"no result"` or `"shell-parser: tree-sitter natives are unavailable"` — this is a warning, not failure; check filesystem

## Historical note

Earlier research (Aug 3, 2026) claimed `.prompt()` was the stable path. That was incorrect — `.prompt()` was removed or never shipped in `@cursor/sdk@1.0.27`. The stable API is `.send()` + `await run.streamPromise`. Always verify SDK methods at runtime with `Object.getOwnPropertyNames(Object.getPrototypeOf(agent)).filter(m => typeof agent[m] === 'function')`.

## Models verified available (August 2026)

```javascript
// List models dynamically
const { Cursor } = require("@cursor/sdk");
Cursor.models.list({}).then(m => console.log(m.map(x => x.id)));
```

Known IDs: `composer-2.5`, `claude-opus-5`, `claude-opus-4-8`, `claude-sonnet-4`, `grok-4.5`, `gpt-5.2`, `gpt-5.4`, `gpt-5.6-luna`, `gemini-3.1-pro`, `gemini-3.6-flash`, `kimi-k2.7-code`, `kimi-k3`
