# Cursor Cloud Agent Reliability — September 2026 Session Notes

## Key Finding: Cloud Agents Do NOT Write to Host Filesystem

**Discovery date:** September 1, 2026
**Finding:** After dispatching a Cursor Cloud agent via `@cursor/sdk` REST bridge with `cwd=/home/das/projects/finn-pentest-harness`, the agent returned a detailed summary claiming success. However:
- `git status --short` showed **zero changes**
- `git diff --stat` was empty
- The `result.files` array in the bridge response was empty despite claims of "30 files modified"

**Root cause:** Cursor Cloud agents run in **remote containers**. They do not share a filesystem with the host. File edits happen inside the container and are lost when the container terminates. The agent's only reliable delivery path is:
1. Agent creates branch locally in its container (e.g. `cursor/nil-penpot-wireframes-c865`)
2. Agent attempts to push to GitHub (often fails with PUSH_BLOCKED — no container credentials)
3. If push succeeds → GitHub auto-opens a PR
4. User merges the PR
5. Only then do the changes reach the host

**"Commit to master" does NOT work.** The agent has no shared git state with your repo. It works in its own container at `/agent`.

## Verified Patterns

### What Works
| Approach | Reliability | Notes |
|----------|-------------|-------|
| Branch + PR | ✅ High | Agent creates branch, pushes (sometimes blocked), PR auto-opens |
| Direct REST with `result.text` parsing | ✅ High | Agent returns code in JSON response; parse and write to disk yourself |
| Local SDK mode (`local: { cwd: ... }`) | ✅ Medium | Writes to host filesystem, but requires `model` in `create()` and still needs verification |
| "Commit to master" | ❌ Never | Agent has no git state with your repo |
| Relying on `result.files` | ❌ Never | Often empty even when agent claims success |

### Bridge Reliability Fix

Root cause of v1 bridge hanging was NOT a code bug — it was **Cursor billing**. Cloud agents require usage-based pricing enabled with at least $2 remaining until the hard limit. Old bridge (v1) would silently poll forever waiting for a run that could never start. New bridge (v2) does pre-flight checks and returns clear actionable error messages immediately.

**Pre-flight checklist:**
1. `hermes config get cursor.api_key` exists and is valid
2. Cursor dashboard → Settings → Usage-based pricing is ON with >$2 remaining
3. If using a free-tier model (`composer-2.5`), verify it still works — free tiers can change

## Recommended Workflow

For **mechanical/wiring tasks** (add API functions, wire stores, fix routes):
- Write code directly on host + verify with `npm run build`
- Do NOT delegate to cloud agent for mechanical work

For **architecture/design tasks** (planning, research, API design):
- Use cloud agent in branch + PR mode
- Parse `result.text` for design docs and write to disk yourself

For **full builds** (scaffolding entire projects):
- Use Cursor IDE's Composer tab directly (you in the loop)
- OR: Use cloud agent for architecture → write scaffold yourself → verify with build

## Verification After ANY Agent Run

```bash
git status --short          # should show modified/added files
git log --oneline -3       # should show new commit
git diff --stat            # summary of what changed
```

If all three are empty, the agent made NO changes to your host filesystem regardless of what it claims in its response.
