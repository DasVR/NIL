# Captive Portal / Login Page Cloning — Research-First Workflow

When the user asks to clone or recreate branded login pages, captive portals, or WiFi sign-in screens — always research the real-world flow first rather than designing from imagination.

## Why Research First

Real captive portals follow specific provider patterns and flows that are NOT intuitive guesses:
- **Starbucks** → Google-hosted sign-in ("Free Wi-Fi / From our friends at Google"), email+password, "Accept & Connect", terms modal, help line
- **McDonald's** → No login required, just accept terms. 30 min free/day for guests, members get unlimited
- **Madison Square Garden** → Optimum WiFi, requires Optimum ID + password
- **Walmart** → App-based, pushes Walmart app for store maps/prices
- **Marriott** → Room number + last name, with premium upsell tier

Guessing these produces a generic dark card with "Connect to WiFi" — it looks wrong.

## Research Sources

1. **GitHub wifiphisher repo** — `extra-phishing-pages/<brand>-login/html/index.html` contains real captured portal HTML
2. **Brand blogs/case studies** — e.g., Purple.ai blog on McDonald's captive portal design
3. **Brand FAQ pages** — e.g., `faq.optimum.net` for MSG WiFi details
4. **TripAdvisor / Reddit threads** — users describe real login flows

## Build Pattern

1. Search for the real portal design/flow
2. Curl or extract the actual HTML if available (GitHub repos, open directories)
3. Note the exact field names, button text, terms wording, and upsell flows
4. Build a **gallery index** (`index.html`) linking to each cloned portal
5. Each portal is its own themed HTML file, fully responsive, with a working "Connect" button (alerts, not real auth)
6. Serve with `python3 -m http.server`

## Gallery Structure

```
project/
├── index.html          # Grid of brand cards linking to portals
├── starbucks.html      # Google-hosted email+password
├── mcdonalds.html      # Accept terms only
├── marriott.html       # Room + name + tier upsell
├── msg.html            # Optimum ID login
├── target.html         # Simple email capture
├── walmart.html        # App promotion + connect
├── ...
```

## Responsive Rules

- Card max-width 420px, centered
- Mobile padding reduced (28px/22px vs 36px/32px)
- Stack multi-column rows vertically on <480px
- Touch targets ≥44px for buttons

## Pitfalls

- **Don't build from imagination** — real portals have specific copy, field counts, and flows
- **Don't use real brand logos/trademarks as images** — use text, emoji, or CSS approximations to avoid IP issues
- **Don't wire real auth** — these are visual clones for reference/learning only
- **Don't forget the gallery index** — the user wants "a bunch of different" options, not one at a time
