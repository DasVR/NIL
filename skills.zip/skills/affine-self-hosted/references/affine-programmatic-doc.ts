import { io } from "socket.io-client";
import * as Y from "yjs";

const BASE_URL = process.env.AFFINE_BASE_URL || "https://affine.example.com";
const WS_URL = BASE_URL.replace("https://", "wss://").replace("http://", "ws://");
const WORKSPACE_ID = process.env.AFFINE_WORKSPACE_ID || "";
const EMAIL = process.env.AFFINE_EMAIL || "";
const PASSWORD = process.env.AFFINE_PASSWORD || "";

function randomId(len = 10) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let id = "";
  for (let i = 0; i < len; i++) id += chars[Math.floor(Math.random() * chars.length)];
  return id;
}

async function signIn() {
  const res = await fetch(`${BASE_URL}/api/auth/sign-in`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: EMAIL, password: PASSWORD }),
    redirect: "manual",
  });
  if (!res.ok && res.status !== 302) throw new Error(`Sign-in failed: ${res.status}`);
  const setCookies = res.headers.getSetCookie?.() ?? [];
  if (!setCookies.length) throw new Error("No cookies returned");
  return setCookies.map(c => c.split(";")[0]).join("; ");
}

function emitWithAck(socket, event, payload) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timeout: ${event}`)), 15000);
    socket.emit(event, payload, (res) => {
      clearTimeout(timer);
      if (res?.error) reject(new Error(`${event} error: ${JSON.stringify(res.error)}`));
      else resolve(res);
    });
  });
}

async function createDocument(socket, workspaceId, title, lines = []) {
  const docId = randomId();
  const doc = new Y.Doc();
  const blocksMap = doc.getMap("blocks");

  const pageId = randomId();
  const surfaceId = randomId();
  const noteId = randomId();

  doc.transact(() => {
    // Page block (root)
    const pageBlock = new Y.Map();
    pageBlock.set("sys:id", pageId);
    pageBlock.set("sys:flavour", "affine:page");
    pageBlock.set("sys:version", 2);
    const titleText = new Y.Text();
    titleText.insert(0, title);
    pageBlock.set("prop:title", titleText);
    const pageChildren = new Y.Array();
    pageChildren.push([surfaceId, noteId]);
    pageBlock.set("sys:children", pageChildren);
    blocksMap.set(pageId, pageBlock);

    // Surface block
    const surfaceBlock = new Y.Map();
    surfaceBlock.set("sys:id", surfaceId);
    surfaceBlock.set("sys:flavour", "affine:surface");
    surfaceBlock.set("sys:version", 5);
    surfaceBlock.set("sys:children", new Y.Array());
    blocksMap.set(surfaceId, surfaceBlock);

    // Note block (content container)
    const noteBlock = new Y.Map();
    noteBlock.set("sys:id", noteId);
    noteBlock.set("sys:flavour", "affine:note");
    noteBlock.set("sys:version", 1);
    const noteChildren = new Y.Array();
    noteBlock.set("sys:children", noteChildren);
    blocksMap.set(noteId, noteBlock);

    // Content blocks
    for (const line of lines) {
      const blockId = randomId();
      const block = new Y.Map();
      block.set("sys:id", blockId);
      block.set("sys:flavour", "affine:paragraph");
      block.set("sys:version", 1);
      block.set("sys:children", new Y.Array());
      block.set("prop:type", "text");
      const text = new Y.Text();
      text.insert(0, line);
      block.set("prop:text", text);
      blocksMap.set(blockId, block);
      noteChildren.push([blockId]);
    }
  });

  const update = Y.encodeStateAsUpdate(doc);
  await emitWithAck(socket, "space:push-doc-update", {
    spaceType: "workspace",
    spaceId: workspaceId,
    docId,
    update: Buffer.from(update).toString("base64"),
  });

  return docId;
}

async function registerDocInWorkspace(socket, workspaceId, docId, title) {
  const wsRes = await emitWithAck(socket, "space:load-doc", {
    spaceType: "workspace",
    spaceId: workspaceId,
    docId: workspaceId,
  });

  const wsDoc = new Y.Doc();
  const wsData = wsRes.data?.missing ?? wsRes.missing;
  if (wsData) {
    const buf = typeof wsData === "string" ? Buffer.from(wsData, "base64") : new Uint8Array(wsData);
    if (buf.length) Y.applyUpdate(wsDoc, buf);
  }

  const prevSV = Y.encodeStateVector(wsDoc);
  const meta = wsDoc.getMap("meta");
  let pages = meta.get("pages");
  if (!pages) {
    pages = new Y.Array();
    meta.set("pages", pages);
  }

  const pageEntry = new Y.Map();
  pageEntry.set("id", docId);
  pageEntry.set("title", title);
  pageEntry.set("createDate", Date.now());
  pages.push([pageEntry]);

  const wsUpdate = Y.encodeStateAsUpdate(wsDoc, prevSV);
  await emitWithAck(socket, "space:push-doc-update", {
    spaceType: "workspace",
    spaceId: workspaceId,
    docId: workspaceId,
    update: Buffer.from(wsUpdate).toString("base64"),
  });
}

async function main() {
  const cookie = await signIn();
  const socket = io(WS_URL, {
    transports: ["websocket"],
    path: "/socket.io/",
    autoConnect: false,
    extraHeaders: { Cookie: cookie },
  });

  socket.connect();
  await new Promise((resolve, reject) => {
    socket.on("connect", resolve);
    socket.on("connect_error", reject);
    setTimeout(() => reject(new Error("WebSocket connection timeout")), 10000);
  });

  await emitWithAck(socket, "space:join", {
    spaceType: "workspace",
    spaceId: WORKSPACE_ID,
    clientVersion: "0.27.3",
  });

  const docId = await createDocument(socket, WORKSPACE_ID, "New Document", ["Hello from the script!"]);
  await registerDocInWorkspace(socket, WORKSPACE_ID, docId, "New Document");
  console.log("Created and registered document:", docId);
  socket.disconnect();
}

main().catch(err => { console.error("Error:", err); process.exit(1); });
