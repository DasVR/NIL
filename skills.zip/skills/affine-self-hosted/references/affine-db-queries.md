# AFFiNE Self-Hosted — Common Database Queries

Run these inside the `affine_postgres` container against the `affine` database.

## List Users

```sql
SELECT id, name, email FROM users;
```

## List Workspaces

```sql
SELECT id, name, created_at FROM workspaces;
```

## Workspace Members (check ownership)

```sql
SELECT wm.user_id, u.email, wm.workspace_id, wm.role, wm.state
FROM workspace_members wm
JOIN users u ON wm.user_id = u.id;
```

## Pages in a Workspace

```sql
SELECT title, page_id
FROM workspace_pages
WHERE workspace_id = '<workspace-uuid>';
```

## Admin Feature Check

```sql
SELECT user_id, name, activated
FROM user_features
WHERE user_id IN (SELECT id FROM users);
```

## Which User is Admin?

```sql
SELECT u.email, uf.name, uf.activated
FROM user_features uf
JOIN users u ON uf.user_id = u.id
WHERE uf.name = 'administrator';
```

## User Feature Names

```sql
SELECT DISTINCT name FROM user_features;
```

## App Config Keys

```sql
SELECT id FROM app_configs;
```
