---
name: affine-self-hosted
description: Deploy, configure, and manage self-hosted AFFiNE instances. Covers first-run setup, workspace creation, programmatic document management via GraphQL/WebSocket, SMTP, copilot BYOK, and admin troubleshooting.
category: productivity
---

# Self-Hosted AFFiNE

Deploy and operate a self-hosted AFFiNE knowledge-base instance with Docker Compose, including first-run setup behavior, workspace requirements, and programmatic document creation.

## Deployment

Use the official Docker Compose stack from `toeverything/AFFiNE`. Standard layout:
```
/opt/stacks/affine/
├── docker-compose.yml
├── .env
├── config/
│   └── config.json
└── data/
    ├── storage/
    └── postgres/
```

Attach all services (server, postgres, redis) to an external `proxy` network so a shared Caddy reverse proxy can reach `affine_server:3010`.

## Key Environment Variables (`.env`)

| Variable | Purpose |
|----------|---------|
| `AFFINE_SERVER_EXTERNAL_URL` | Public URL (e.g. `https://affine.example.com`) |
| `MAILER_HOST` / `MAILER_PORT` / `MAILER_USER` / `MAILER_PASS` / `MAILER_SENDER` | Outbound SMTP |
| `DB_DATA_LOCATION` / `DB_USERNAME` / `DB_PASSWORD` | Postgres credentials |

**Important:** `docker compose restart` does NOT pick up new `.env` values. After editing `.env`, use `stop → rm -f → create → start` (or `--force-recreate`) so the container definition is rebuilt.

## First-Run Setup Wizard

Self-hosted AFFiNE starts in “setup mode.” The root path `/` redirects to `/admin/setup` when no admin user exists. There is **no separate pre-existing app URL** before onboarding.

- The wizard creates the first admin account + workspace
- The password is set by the user in the browser during setup
- **There is no backend/API way to know or reset this password** without database surgery
- Once setup completes, `/` serves the main app and `/admin` is the admin dashboard

## Workspace Requirement

AFFiNE is workspace-centric. If the `workspaces` table is empty, the app shows only the admin dashboard or setup wizard — there is no visible “normal app.”

- Users must create at least one workspace through the UI
- Check: `SELECT id, name FROM workspaces;`
- Empty result = no workspace exists yet

### Workspace Membership

A user must be listed as an owner/member in `workspace_members` to join a workspace via WebSocket. The setup wizard creates the first workspace under the account that completes onboarding.

- Check members: `SELECT wm.user_id, u.email, wm.role FROM workspace_members wm JOIN users u ON wm.user_id = u.id;`
- If a sign-in succeeds but `space:join` returns `SPACE_ACCESS_DENIED`, the email used is not a member of that workspace. Switch to the owner email.

## Admin Access Issue (GitHub Discussion #8209)

If a user sees the admin dashboard but cannot access `/admin` settings (treated as non-admin):
- AFFiNE uses a `user_features` table to grant admin capability
- The setup wizard normally inserts `feature_id = 7` (`administrator`) for the first user
- If this row is missing or corrupted, the user loses admin rights
- Fix: ensure the first user has a `user_features` row with `feature_id = 7`

## Programmatic Document Creation

AFFiNE docs use a Yjs CRDT over WebSocket (`/socket.io/`). The public GraphQL API can list workspaces/docs, but **mutating documents requires the WebSocket Y.Doc protocol**.

### Authentication
1. POST to `/api/auth/sign-in` with email + password
2. Capture `Set-Cookie` headers
3. Pass those cookies in WebSocket `extraHeaders`

### Create a Document
1. `io()` connect with `transports: ["websocket"]` and `path: "/socket.io/"`
2. Emit `space:join` with `{ spaceType: "workspace", spaceId, clientVersion: "0.27.3" }`
3. Build a `Y.Doc` with the standard AFFiNE block structure:
   - `affine:page` block (root, contains title)
   - `affine:surface` block
   - `affine:note` block (contains children)
   - Child blocks under note (`affine:paragraph`, `affine:list`, etc.)
4. Encode update: `Y.encodeStateAsUpdate(doc)`
5. Emit `space:push-doc-update` with base64-encoded update
6. The server auto-registers the doc in the workspace

Block keys:
- `sys:id`, `sys:flavour`, `sys:version`, `sys:children`
- `prop:title` (`Y.Text`), `prop:text` (`Y.Text`), `prop:type`

### GraphQL Introspection

Endpoint: `POST /graphql`

Useful mutations:
- `createWorkspace` — creates a workspace
- `updateWorkspace` — rename/metadata
- `deleteWorkspace` — remove workspace
- `publishDoc` — make doc public
- `inviteMembers` — add users

Queries:
- `workspaces` — list accessible workspaces
- `workspace(id)` — get workspace details
- `workspace { docs(pagination) }` — paginate documents
- `workspace { doc(docId) }` — get doc metadata

## SMTP Configuration

AFFiNE uses the `MAILER_*` env vars (not `AFFINE_SMTP_*`). Gmail app-password workflow:
1. Set `MAILER_HOST=smtp.gmail.com`, `MAILER_PORT=587`
2. Use the Gmail address as both `MAILER_USER` and `MAILER_SENDER`
3. Use an app-specific password for `MAILER_PASS`
4. Recreate the `affine_server` container to load new env vars

## Copilot / AI (BYOK)

In `config/config.json`:
```json
{
  "copilot": {
    "enabled": true,
    "byok": {
      "allowCustomEndpoint": true,
      "allowPrivateEndpoint": true
    }
  }
}
```

With `allowCustomEndpoint: true` and `allowPrivateEndpoint: true`, users can add their own OpenAI/Anthropic/local API keys via the workspace settings UI. No server-side API key is required.

## Reverse Proxy + Tunnel

- Caddy rule: `reverse_proxy affine_server:3010` on the `proxy` Docker network
- Cloudflare Tunnel ingress: `hostname: affine.example.com → service: http://localhost:80`
- Cloudflared does **not** support `SIGHUP` reload — use `systemctl restart cloudflared`

## Common Pitfalls

- **404 on public URL** → Check Cloudflare Tunnel ingress config and that cloudflared is running
- **502 from Caddy** → `affine_server` container is not on the `proxy` network
- **Admin dashboard only** → No workspace exists; user must create one through the UI
- **SMTP not working** → Env vars not loaded because container was only restarted, not recreated
- **Cannot access `/admin`** → Check `user_features` table for `administrator` entry
- **Docs pushed via WebSocket not visible in sidebar** → The `space:push-doc-update` creates the doc CRDT, but you must also update the workspace's `meta.pages` array. Load the workspace root doc (`docId === workspaceId`), push a new `Y.Map` entry into `meta.pages`, and push the update back.

## References

- `references/affine-programmatic-doc.ts` — runnable Node.js script for creating documents via WebSocket/Yjs
- `references/affine-graphql-snippets.md` — common GraphQL queries and mutations
