#!/usr/bin/env bash
# Secret scanning patterns for GitHub repo audits
# Usage: source this file or copy the grep commands into your audit loop

# Run from inside each cloned repo directory, e.g.:
# for repo in *; do cd "$repo"; bash ../secret-patterns.sh; cd ..; done

echo "=== Scanning $(basename "$PWD") ==="

# 1. API keys / tokens / secrets (exclude process.env and examples)
grep -rEin "(api[_-]?key|api[_-]?secret|secret[_-]?key|client[_-]?secret|access[_-]?token|auth[_-]?token|bearer)[\s]*[:=][\s]*[\"']?[a-zA-Z0-9_\-\.]{20,}[\"']?" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=build \
  --exclude="*.md" --exclude="*.example" --exclude="*example*" \
  | grep -vi "example\|placeholder\|your_\|xxxx\|****\|demo\|test\|sample\|my_token\|my_key\|process\.env\." | head -20

# Check for tracked .env files FIRST (most common leak)
echo "=== Tracked .env files ==="
git ls-files | grep "\.env$" || echo "None"

# 2. Discord tokens
grep -rEin "[MN][A-Za-z0-9]{23}\.[A-Za-z0-9]{6}\.[A-Za-z0-9]{27,}" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" | head -10

# 3. Discord webhooks
grep -rEin "discord(app)?\.com/api/webhooks/[0-9]+/[A-Za-z0-9_-]+" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" | head -10

# 4. OpenAI / LLM keys
grep -rEin "sk-[a-zA-Z0-9]{20,}" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" \
  | grep -vi "example\|placeholder" | head -10

# 5. Google API keys
grep -rEin "AIza[0-9A-Za-z_-]{35}" . \
  --exclude-dir=node_modules --exclude-dir=.git | head -10

# 6. AWS access key IDs
grep -rEin "AKIA[0-9A-Z]{16}" . \
  --exclude-dir=node_modules --exclude-dir=.git | head -10

# 7. Private keys
grep -rEin "BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY" . \
  --exclude-dir=node_modules --exclude-dir=.git | head -10

# 8. Database URLs with embedded passwords
grep -rEin "(mongodb|mysql|postgres|redis)://[^:]+:[^@]+@" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" | head -10

# 9. Custom webhook / notification URLs (e.g., ntfy)
grep -rEin "notify\.[a-z0-9_-]+\.[a-z]+/[a-zA-Z0-9_-]+" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" | head -10

# 10. Hardcoded passwords in config
grep -rEin "password[:\s]*[=:][\s]*[\"'][^\"']{4,}[\"']" . \
  --exclude-dir=node_modules --exclude-dir=.git --exclude="*.example" --exclude="*example*" --exclude="*.md" \
  | grep -vi "example\|placeholder\|your_\|demo\|test\|sample" | head -10

# 11. GitHub tokens
grep -rEin "gh[pousr]_[A-Za-z0-9_]{36,}" . \
  --exclude-dir=node_modules --exclude-dir=.git | head -10
