---
name: github-security-audit
description: Audit GitHub repositories for leaked credentials, API keys, tokens, secrets, and tracked .env files. Covers full scan workflow from inventory through remediation.
title: GitHub Repository Security Audit
triggers:
  - audit github repos for secrets
  - scan repos for leaked credentials
  - check github repos for api keys tokens passwords
  - find leaked secrets in repositories
  - github credential leak scan
  - review all repos for exposed env files
---

# GitHub Repository Security Audit

Audit all repositories under a GitHub account (or a specific org/user) for leaked credentials, API keys, tokens, secrets, and sensitive configuration files.

## Trigger Conditions
- User asks to scan/audit/review GitHub repositories for leaked credentials, secrets, API keys, tokens, or passwords
- User wants to ensure no sensitive data is exposed across their repo portfolio
- Post-incident cleanup: "remove that repo and check the rest for leaks"

## Workflow

### 1. Inventory Repositories
List all repos to establish scope. Use JSON output for programmatic handling:
```bash
gh repo list <OWNER> --limit 1000 --json name,description,updatedAt,visibility,url
```

### 2. Clone Locally for Scanning
Create a temp directory and clone repos in a loop. Skip private repos if the local token lacks access:
```bash
mkdir -p /tmp/repo-audit && cd /tmp/repo-audit
for repo in <REPO_NAME_1> <REPO_NAME_2> ...; do
  gh repo clone <OWNER>/"$repo" "$repo" 2>/dev/null && echo "cloned $repo" || echo "skip $repo"
done
```

### 3. Scan for Leaked Secrets
Run targeted grep searches **excluding** `node_modules`, `.git`, `dist`, `build`, `*.md`, `*.example`, and anything matching `*example*`.

Key patterns to search (see `references/secret-patterns.sh`):
- API keys / access tokens / bearer tokens / client secrets
- Discord tokens (`[MN][A-Za-z0-9]{23}\.[A-Za-z0-9]{6}\.[A-Za-z0-9]{27,}`)
- Discord webhooks
- OpenAI / Anthropic / generic LLM API keys (`sk-[a-zA-Z0-9]{20,}`)
- Google API keys (`AIza[0-9A-Za-z_-]{35}`)
- AWS access key IDs (`AKIA[0-9A-Z]{16}`)
- Private keys (`BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY`)
- Database URLs with embedded passwords (`mongodb|mysql|postgres|redis)://[^:]+:[^@]+@`)
- Custom webhook / notification URLs (e.g., `notify.*.net/*`)
- Hardcoded passwords in config files
- GitHub tokens (`gh[pousr]_[A-Za-z0-9_]{36,}`)

**All grep commands include `head` limits** to avoid flooding output when scanning large repos or `node_modules`-heavy codebases.

### 4. Identify Tracked `.env` Files
The most common leak vector is a `.env` file committed to git. Distinguish between:
- `.env.example` / `.env.sample` → Usually safe (placeholders)
- `.env` → Dangerous if tracked by git

Check which `.env` files are actually tracked:
```bash
cd <repo>
git ls-files | grep "\.env$"
```

If a real `.env` is tracked, it is a **confirmed leak** regardless of what grep found.

### 5. Report Findings
For each leaked secret, report:
- Repository name + visibility (public = critical)
- File path + line number
- Secret type / pattern matched
- Context snippet (truncated)

### 6. Remediation
If leaks are found:
1. **Rotate the exposed credential immediately** on the provider side (Discord, OpenAI, AWS, etc.)
2. Remove the file from git history using `git-filter-repo` or BFG Repo-Cleaner
3. Add `.env` to `.gitignore` if not already present
4. Verify the secret no longer appears in commit history
5. Re-scan to confirm cleanup

## Pitfalls & False Positives

- **Never trust `node_modules` hits.** Minified JS contains thousands of strings that look like tokens. Always `--exclude-dir=node_modules`.
- **`.env.example` is not a leak.** Developers commonly commit example env files. Only flag actual `.env` files.
- **Password hashes are still sensitive.** A `pbkdf2` or `bcrypt` hash in a tracked `.env` should be treated as leaked — the hash can be attacked offline.
- **GitHub CLI `delete_repo` scope requires explicit user authorization.** `gh auth refresh -s delete_repo` opens a device flow URL. The user MUST check the "Delete repositories" permission box before submitting. The CLI times out after ~60 seconds. If deletion fails with `HTTP 403: Must have admin rights to Repository`, the token lacks the scope — do not loop retries; explain to the user and wait for them to re-auth with the correct permission.
- **Browser-based deletion requires an active GitHub session.** The background browser tool may not have GitHub cookies. If the CLI lacks scope, do not assume the browser can compensate.
- **REST API deletion also returns 403 without `delete_repo` scope.** No workaround exists without that OAuth scope.
- **Exclude `process.env.` references.** Code that reads from `process.env.VAR_NAME` is not a leak; only hardcoded values are.

## References
- `references/secret-patterns.sh` — Copy-paste grep patterns for local secret scanning
- `references/cred-audit-report-template.md` — Markdown template for reporting findings to the user