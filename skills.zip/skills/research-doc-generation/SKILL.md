---
name: "research-doc-generation"
version: "1.0.0"
category: "productivity"
description: "Compile comprehensive research documents into printable, styled PDFs for user study and review"
tags: ["documents", "pdf", "markdown", "research", "printing", "deliverables"]
requires: ["python3", "pip/venv"]
---

# Research Document Generation

## Trigger Conditions
- User asks for "files to print," "research docs," "study guide," "comprehensive reference"
- User wants "large file with a lot of information"
- User requests PDF, DOCX, or printable output from research
- User says "compile this into a document" or "make me a guide"

## Core Workflow

### 1. Compile Markdown Source (Primary Format)
- Write to `cursor-research/` or similar folder in the user's portfolio/repo
- **Must be comprehensive** — never a stub. User expects large, dense content.
- Structure with TOC, numbered sections, tables, code blocks, diagrams
- Include practical commands, cheatsheets, architecture diagrams (ASCII)
- **Embed creativity** — personal framing (e.g., "Finn Corps"), creative analogies, persona-driven sections
- Save as `.md` first — this is the source of truth

### 2. Push Markdown to GitHub
- `git add -A && git commit -m "docs: ..." && git push`
- Ensures Cursor IDE has full context
- User explicitly expects this as standard workflow step

### 3. Convert to Styled PDF
**Preferred toolchain:** Python `markdown` library → HTML → `weasyprint` with custom dark CSS

```bash
# Create venv (PEP 668 requirement on this system)
python3 -m venv /tmp/pdfgen
/tmp/pdfgen/bin/pip install markdown weasyprint
```

```python
import markdown
from weasyprint import HTML
from pathlib import Path

md = Path('input.md').read_text()
html_body = markdown.markdown(md, extensions=[
    'tables', 'fenced_code', 'toc', 'attr_list',
    'def_list', 'footnotes'
])

# Load CSS from skill template
css_path = Path.home() / '.hermes/skills/productivity/research-doc-generation/templates/printable-dark.css'
css = css_path.read_text()

full = f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>{css}</style></head>
<body>{html_body}</body></html>'''

HTML(string=full).write_pdf('output.pdf')
```

**DO NOT use pandoc** — fails on markdown tables containing `|` characters (LaTeX math delimiter errors), requires heavy TeXLive install, and produces worse-styled output.

### 4. Alternative: DOCX
- `pandoc input.md -o output.docx` (if pandoc available)
- Otherwise, note DOCX as secondary; user usually prefers PDF

### 5. Send Deliverables
- Attach PDF as media: `MEDIA:/path/to/file.pdf`
- Confirm pushed to GitHub
- Report file size / page estimate

## Pitfalls

| Pitfall | Why | Fix |
|---------|-----|-----|
| Pandoc + xelatex | `\|` in table cells triggers LaTeX math mode error | Use weasyprint route instead |
| System pip blocked | PEP 668 on Ubuntu prevents system pip installs | Always use `python3 -m venv` |
| Tiny PDF output | Default weasyprint without CSS produces bland, compact output | Apply dark CSS with generous margins, large fonts, page breaks |
| Missing page numbers | Default weasyprint has no headers/footers | Use `@page` CSS rule with `@bottom-center` |
| No dark theme | White background hurts eyes for long study sessions | Dark `#12121f` background, `#e8e8f0` text, accent colors |

## Templates
- `templates/printable-dark.css` — Production-ready dark theme CSS for technical documents

## Scripts
- `scripts/md-to-pdf.py` — One-shot conversion script with venv auto-setup

## References
- `references/pdf-generation-pitfalls.md` — Session transcripts of pandoc/weasyprint failures and resolutions

## Verification
- PDF opens without errors
- File size > 100 KB for documents > 1000 lines
- Code blocks render with proper background and border-left accent
- Tables have alternating row colors
- Page numbers appear in footer