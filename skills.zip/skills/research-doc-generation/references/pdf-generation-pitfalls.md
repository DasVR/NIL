# PDF Generation Pitfalls — Session Notes

## July 31, 2026 Session: AI Systems Research Doc

### Pandoc + LaTeX Failure
- **Error**: `! LaTeX Error: Bad math environment delimiter.` at line 804
- **Cause**: Markdown table cell containing `| OpenAI | GPT-4o, o1 | \)` — the `\)` triggers LaTeX math mode because pandoc's markdown→LaTeX converter interprets `\)` as closing math delimiter
- **Fix**: Use weasyprint route instead of pandoc+xelatex for markdown with tables
- **Note**: This is a systemic issue — any markdown table with backslash-paren patterns will break pandoc LaTeX. Weasyprint is immune because it uses HTML→PDF, not LaTeX.

### System pip Blocked (PEP 668)
- **Error**: `pip install weasyprint` fails with PEP 668 message
- **Fix**: Always create venv: `python3 -m venv /tmp/pdfgen`
- **Note**: This is an Ubuntu system-level constraint. The venv approach works reliably.

### Tiny PDF Output (First Attempt)
- **Symptom**: 0.1 MB PDF for 1,247-line document
- **Cause**: Default weasyprint without CSS produces extremely compact, unstyled output
- **Fix**: Apply custom dark CSS with generous margins, large fonts, page breaks, headers/footers
- **Result**: 163 KB after applying `printable-dark.css`

### Weasyprint Success Path
```
python3 -m venv /tmp/pdfgen
/tmp/pdfgen/bin/pip install markdown weasyprint
# Use skill's md-to-pdf.py script or inline python
```

### Verification Checklist
- [ ] PDF size > 100 KB for documents > 1000 lines
- [ ] Code blocks have background + left border accent
- [ ] Tables render with alternating row colors
- [ ] Page numbers in footer
- [ ] Dark background, light text (easy on eyes for long reading)
- [ ] H1 sections start on new pages
