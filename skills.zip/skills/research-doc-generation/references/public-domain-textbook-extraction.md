# Public-Domain Textbook Chapter Extraction

## Trigger
User needs study notes for a specific textbook chapter, and a public-domain or older edition is available via Internet Archive.

## Workflow

### 1. Find the Book on Internet Archive
- Search: `site:archive.org "Book Title" "edition"`
- Look for items with `_text.pdf` (OCR text layer) or `_djvu.txt` (raw OCR).
- Verify the edition matches or is close to the assigned edition. Note edition differences to the user.

### 2. Download the PDF
```bash
curl -sL "https://archive.org/download/IDENTIFIER/IDENTIFIER_text.pdf" -o /tmp/book.pdf
```

### 3. Extract the Chapter Pages with pymupdf
```python
import pymupdf, re

doc = pymupdf.open('/tmp/book.pdf')
# Find pages containing the chapter start
for i in range(min(120, len(doc))):
    text = doc[i].get_text()
    if re.search(r'Chapter\s+1\b', text, re.I):
        print(f"Chapter 1 starts on page {i+1}")
        break

# Extract the chapter text (e.g., pages 19-31)
chapter_text = ""
for i in range(18, 31):  # 0-indexed
    chapter_text += doc[i].get_text() + "\n\n"
```

### 4. Parse Section Headings from Raw OCR
The OCR text will have line-break artifacts and OCR errors. Parse headings by:
- Looking for ALL-CAPS lines under 80 chars
- Filtering out figure captions and page numbers
- Using context (next line is paragraph text, not another heading)

```python
import re
lines = chapter_text.splitlines()
headings = []
for i, line in enumerate(lines):
    s = line.strip()
    if s and s[0].isupper() and len(s) < 80 and not s.endswith('.'):
        if i+1 < len(lines) and lines[i+1].strip() and not lines[i+1].strip()[0].isupper():
            if len(s.split()) < 12:
                headings.append(s)
```

### 5. Build Structured Notes
Use the extracted text to create a study document with:
- Learning objectives
- Section summaries (in your own words, not copy-pasted)
- Key terms with definitions
- Study questions
- Quick summary

Save as both `.docx` (for printing/submission) and `.txt` (for quick reference).

## Important: Copyright Boundary
- **Public-domain or older editions**: Fair game for extraction and note-building.
- **Current assigned edition**: Extracted notes must be clearly labeled as sourced from an older edition. User must cross-check against their actual textbook.
- **Never reproduce verbatim copyrighted text** for submission. Notes should be paraphrased summaries.

## Example Output Structure
```
THE ART OF BEING HUMAN
Chapter 1: The Humanities: A Shining Beacon

Source: Janaro, R. P., & Altshuler, T. C. (11th ed.)...
Note: These notes are based on the 11th edition public OCR. Cross-check against your assigned 13th edition.

LEARNING OBJECTIVES
1. Define "the humanities."
2. ...

1. WHAT ARE THE HUMANITIES?
Definition and History
- ...

KEY TERMS
| Term | Definition |
|------|-----------|
| Aesthetic | ... |

STUDY QUESTIONS
1. ...

QUICK SUMMARY
...
```

## Pitfalls
- Internet Archive `_djvu.txt` URLs often return HTML, not raw text. Prefer `_text.pdf`.
- OCR text has artifacts (e.g., "BcE" instead of "BCE", "anum-" line breaks). Clean these during note-building.
- Chapter page numbers in the PDF may not match the printed book's pagination.
