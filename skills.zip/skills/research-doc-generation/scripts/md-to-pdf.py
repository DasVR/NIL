#!/usr/bin/env python3
"""Convert markdown to styled dark PDF using weasyprint.
Auto-creates venv if weasyprint not available."""
import subprocess, sys, os, argparse
from pathlib import Path

def ensure_weasyprint():
    try:
        import weasyprint
        return sys.executable
    except ImportError:
        venv = Path("/tmp/pdfgen")
        if not venv.exists():
            subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
        pip = venv / "bin/pip"
        subprocess.run([str(pip), "install", "markdown", "weasyprint"], check=True)
        return str(venv / "bin/python3")

def convert(md_path: str, css_path: str = None, out_path: str = None):
    py = ensure_weasyprint()
    md = Path(md_path)
    out = Path(out_path or md.with_suffix('.pdf'))
    css_file = css_path or str(Path.home() / ".hermes/skills/productivity/research-doc-generation/templates/printable-dark.css")

    script = f'''
import markdown
from weasyprint import HTML
from pathlib import Path

md = Path('{md}').read_text()
html_body = markdown.markdown(md, extensions=['tables','fenced_code','toc','attr_list','def_list','footnotes'])
css = Path('{css_file}').read_text()
full = f"""\u003c!DOCTYPE html\u003e\u003chtml\u003e\u003chead\u003e\u003cmeta charset=\"UTF-8\"\u003e\u003cstyle\u003e{{css}}\u003c/style\u003e\u003c/head\u003e\u003cbody\u003e{{html_body}}\u003c/body\u003e\u003c/html\u003e"""
HTML(string=full).write_pdf('{out}')
print(f"PDF: {{os.path.getsize('{out}')/1024:.0f}} KB")
'''
    result = subprocess.run([py, "-c", script], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("stderr:", result.stderr)
    return out

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("markdown", help="Input markdown file")
    parser.add_argument("--css", help="Custom CSS file", default=None)
    parser.add_argument("--output", "-o", help="Output PDF path", default=None)
    args = parser.parse_args()
    pdf = convert(args.markdown, args.css, args.output)
    print(f"Created: {pdf}")
