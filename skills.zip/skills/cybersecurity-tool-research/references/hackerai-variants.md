# HackerAI Variants — Session Note (2026-08-10)

Two completely different products share the "HackerAI" name:

## hackerai.sh
- **Type:** Open-source terminal-native CLI
- **Install:** `npm install -g hackerai`
- **Models:** GPT, Claude, Gemini, Llama, Qwen, DeepSeek (free, auto-rotates)
- **Modes:** Hunt (autonomous scanner), Chat (Q&A), Code (exploit/PoC generation)
- **Key feature:** Multi-provider pentest engine, secure approval system (like sudo for AI)
- **Target audience:** Terminal users, pentesters who live in the shell

## hackerai.co
- **Type:** Commercial web/desktop copilot
- **Access:** Web browser at hackerai.co or downloadable desktop app (.deb, .AppImage, macOS, Windows)
- **Models:** GPT-4, Claude, etc (commercial, no free tier mentioned)
- **Workflow:** Web chat interface — describe target, get analysis + suggested commands + draft reports
- **Key feature:** File upload, report generation with CVSS scoring
- **Target audience:** Pentesters who prefer GUI workflow

## Lesson

When user provides a specific URL or domain, verify THAT exact target first. Do NOT assume similarly named tools are the same product. The `.co` and `.sh` variants have completely different architectures, pricing, and workflows.