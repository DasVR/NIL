# Flipper Zero GPIO Board Research — Condensed Reference

Session: 2026-09-01 — User needed a Flipper Zero GPIO add-on for WiFi deauth + BLE/Bluetooth under $110.

## Critical Finding (UPDATED)

ESP32-C5 **does** have Bluetooth 5 LE on silicon, but **Marauder firmware support for C5 BLE is early and buggy** (v1.13.0 era). Most C5 boards are marketed as 5GHz WiFi + wardriving tools; BLE is a secondary "maybe works" feature. The **only C5-based product with verified dual-band WiFi 6 + Bluetooth 5** from the Marauder author is the **Marauder v8**.

## Board Comparison

| Board | Chip | WiFi | BLE/BT | 5 GHz | Price (USD) | Notes |
|-------|------|------|--------|-------|-------------|-------|
| **Scout Lite** (PINGEQUA) | ESP32-C5 | Dual-band WiFi 6 | ⚠️ maybe | ✅ | ~$64.98 | Wardriving focus, GPS, microSD, pre-flashed Marauder |
| **Apex 5** (HoneyHoney) | ESP32-C5 | Dual-band WiFi 6 | ⚠️ maybe | ✅ | ~$122+ | Over budget; BLE not primary |
| **Double Barrel 5G** (HoneyHoney) | ESP32-C5 | Dual-band WiFi 6 | ⚠️ maybe | ✅ | ~$165 | Way over budget; BLE not primary |
| **Poltergeist** (Rabbit Labs) | ESP32-C5 | Dual-band WiFi 6 | ⚠️ maybe | ✅ | ~$170 | Over budget; BLE not primary |
| **Marauder v8** (JCMK) | ESP32-C5 | Dual-band WiFi 6 | ✅ BT 5 | ✅ | **$100** | Built by Marauder author; **official** dual-band + BT 5 |
| **Marauder C5 Adapter** + DevKitC-1 | ESP32-C5 | Dual-band WiFi 6 | ⚠️ early | ✅ | **~$55** ($30 adapter + ~$25 devkit) | DIY assembly |
| **C5 Wardriver** (JCMK) | ESP32-C5 | Dual-band WiFi 6 | ⚠️ unknown | ✅ | **$69** | Sold out often |
| **5Ghost BW16** (PINGEQUA) | RTL8720DN | Dual-band 2.4/5 GHz | ⚠️ BLE scan only | ✅ | **$39.99+** | Cheapest dual-band; BLE recon, not full stack |
| **Electronic Cats Marauder** | ESP32-S3 | 2.4 GHz only | ✅ Full BT/BLE | ❌ | ~$40 | Cheapest with full Bluetooth; standard Marauder firmware |
| **Mayhem v2** | ESP32-S | 2.4 GHz only | ✅ WiFi + BLE | ❌ | ~$69-75 | All-in-one: camera, SD, NRF/CC, no 5GHz |
| **Official Flipper WiFi Devboard** | ESP32-S2 | 2.4 GHz only | ❌ No | ❌ | ~$35-50 | Basic, no Bluetooth |

## Recommended Picks (Under $110)

- **Best 5GHz + official BLE**: **Marauder v8 ($100)** — ESP32-C5, dual-band WiFi 6, Bluetooth 5, GPS, SD, by JustCallMeKoko. Fits budget exactly.
- **Best dual-band WiFi on budget**: **5Ghost BW16 ($39.99)** — RTL8720DN, dual-band, BLE recon, evil portal. No full BT stack.
- **Best full BLE/Bluetooth (no 5GHz)**: **Electronic Cats Marauder ($40)** — ESP32-S3, 2.4 GHz, full BT/BLE spam + recon.
- **Best all-in-one without 5GHz**: **Mayhem v2 (~$69)** — WiFi + BLE + camera + SD + NRF24/CC1101.

## What to Avoid

- Random AliExpress 3-in-1 boards — power/noise issues, sketchy firmware, no support.
- Buying C5 boards expecting mature BLE spam — Marauder C5 BLE support is still catching up.

## Sources & Vendors

- JustCallMeKoko LLC (Marauder v8, C5 Adapter, C5 Wardriver): https://justcallmekokollc.com/
- PINGEQUA (Scout Lite, 5Ghost): https://www.pingequa.com/collections/for-flipper-zero
- HoneyHoney Team (Apex 5, Double Barrel): https://www.tindie.com/stores/honeyhoneytrading/
- Rabbit Labs (Poltergeist): https://rabbit-labs.com/
- Electronic Cats: https://electroniccats.com/store/flipper-add-on-marauder/

## Lesson

When comparing embedded hardware for wireless pentesting, always cross-check **which radio stacks the firmware actually supports**, not just the silicon spec sheet. ESP32-C5 has Bluetooth 5 LE on paper, but Marauder C5 BLE maturity lags behind ESP32-S3. If you need both 5GHz WiFi and reliable BLE, buy from the firmware author (JCMK) or accept the 2.4GHz-only ESP32-S3 route.
