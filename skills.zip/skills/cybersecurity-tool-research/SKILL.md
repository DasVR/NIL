---
name: cybersecurity-tool-research
description: Research pentesting, security, and hacking tools — verify exact URLs, distinguish variants, collect datasets.
category: research
---

# Cybersecurity Tool Research

Research workflows for pentesting, security, and hacking tools, including dataset collection from GitHub and the open web.

## When to Use

- User asks "how does X work?" where X is a pentesting / security / hacking tool
- User provides a specific URL or domain and wants to understand it
- Downloading password lists, wordlists, exploit code, or security datasets from GitHub

## Workflow

1. **Verify the exact URL / domain.** When user provides a specific URL (e.g. `hackerai.co`), research THAT exact site before looking at similarly named alternatives (e.g. `hackerai.sh`). Many tools have confusingly similar names.
2. **Research first, then act.** Dig into the tool's website, GitHub, docs, and recent reviews before summarizing.
3. **Distinguish variants.** Open-source CLI tools and commercial web apps often share names but are completely different products.
4. **Capture the architecture.** For AI copilots, note whether they are: terminal-native CLI, web-based chat, desktop app, or IDE plugin. This matters for how the user would actually use it.

## Dataset Collection

When downloading split files (e.g. `rockyou_2025_00.txt` through `_05.txt`):
- Use `execute_code` with `urllib.request` for batch downloading
- Merge parts with `shutil.copyfileobj` for efficiency
- Decompress `.gz` files with the `gzip` module
- Keep original split files alongside the merged result until user confirms

## Pitfalls

- **Wrong variant.** Answering about `hackerai.sh` (open-source terminal CLI) when user asked about `hackerai.co` (commercial web/desktop copilot). They are different products.
- **Over-explaining before verifying.** When user says "no, I meant X", stop explaining and immediately verify the correct target.
- **Confusing research phase with action phase.** User expects research results, not a plan of how you will research.
- **Newer chip ≠ better for all features.** ESP32-C5 adds dual-band WiFi 6 / 5 GHz but drops Bluetooth/BLE entirely. When researching embedded pentest hardware, always verify which radio stacks are actually present on the silicon, not just the generation number. See `references/flipper-zero-gpio-boards.md` for a concrete example.