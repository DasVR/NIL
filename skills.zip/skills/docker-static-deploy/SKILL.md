---
name: docker-static-deploy
description: Deploy static websites (HTML/CSS/JS) via Docker nginx:alpine containers, accessible over Tailscale or LAN. Covers the full build → containerize → run → verify → share pipeline.
version: 1.0.0
author: Finn
tags: [docker, nginx, tailscale, deployment, static-site, web]
platforms: [linux]
triggers:
  - host a website through docker
  - deploy a static site
  - serve html via docker
  - docker website tailscale
  - put a site online
  - host a portfolio
  - docker nginx static site
  - serve a site over tailscale
---

# Docker Static Site Deployment

Deploy static websites (single-page or multi-page HTML/CSS/JS) using Docker `nginx:alpine` containers. This is the go-to pattern for serving web design work, portfolios, landing pages, and client sites from a homelab/server.

## Deployment Options

### Option A: Docker + Nginx (Tailscale / LAN)

```dockerfile
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
RUN chmod 644 /usr/share/nginx/html/index.html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Option A+ Static frontend + API proxy to backend

When the static site needs to call a backend API (e.g. a chat UI talking to a FastAPI router), use this nginx config that proxies `/api/*` to the backend while serving HTML:

```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    location /api/ {
        proxy_pass http://<backend-host>:<backend-port>/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 300s;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

In the Dockerfile, copy both `index.html` and `nginx.conf`:
```dockerfile
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
COPY nginx.conf /etc/nginx/conf.d/default.conf
RUN chmod 644 /usr/share/nginx/html/index.html /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

**Backend host:** If both containers are on the same Docker `proxy` network, use the host's docker bridge IP (e.g. `172.22.0.1`) or the backend container's name if both are in the same compose stack.

See `templates/nginx.proxy.conf` for the ready-to-copy config.

### Option B: Docker + Caddy Reverse Proxy (Public Domain)

When the user already runs a Caddy reverse proxy in a Docker compose stack (e.g., the foundation stack at `/opt/stacks/foundation/`):

1. Build a static export with Next.js or similar
2. Create a Dockerfile that copies the built `dist/` into nginx:alpine
3. Build the image and run on the `proxy` Docker network
4. Add a `handle` block to `/opt/stacks/foundation/caddy/Caddyfile`
5. `docker restart caddy` to pick up the new mount (reload is NOT enough)

Full details in `self-hosted-infrastructure` skill, Section 5.

### Option C: Cloudflare Tunnel (Bypass Router)

When port forwarding is blocked by router-level DNS filtering, Spectrum, or parental controls. See `self-hosted-infrastructure` skill, Section 1.

## Pitfalls

### Docker permission denied (even when in docker group)

> **CRITICAL**: The `RUN chmod 644` line is NOT optional — see Pitfalls below.

For multi-file sites, copy the whole directory:
```dockerfile
COPY . /usr/share/nginx/html/
RUN chmod -R 644 /usr/share/nginx/html/
```

### 3. Build and run
```bash
# Build the image
docker build -t <site-name> .

# Run the container (pick an unused port)
docker run -d --name <site-name> -p <port>:80 --restart unless-stopped <site-name>
```

### 4. Verify locally
```bash
curl -s -o /dev/null -w "HTTP %{http_code} | Size: %{size_download} bytes\n" http://localhost:<port>
```

### 5. Verify over Tailscale
```bash
TAILSCALE_IP=$(tailscale ip -4)
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://$TAILSCALE_IP:<port>
```

The Tailscale link is: `http://<tailscale-ip>:<port>`

### 6. Share with the user
Send the Tailscale URL. The recipient must be on the same Tailnet and connected to Tailscale.

## Pitfalls

### Docker permission denied (even when in docker group)
**Symptom**: `docker` commands fail with "permission denied while trying to connect to the docker API at unix:///var/run/docker.sock" even though `groups` shows the user in the `docker` group.

**Cause**: The current shell session was started before the docker group membership took effect.

**Fix**: Use `newgrp docker` with a heredoc to run all docker commands in a fresh group context:
```bash
newgrp docker << 'ENDGRP'
docker build -t <name> .
docker run -d --name <name> -p 8088:80 <name>
ENDGRP
```

Do NOT use `sudo docker` — sudo requires a terminal for password auth and will fail in non-interactive sessions.

### nginx 403 Forbidden on copied files
**Symptom**: Container starts, `docker ps` shows it running, but `curl` returns `HTTP 403`.

**Cause**: The source file has restrictive permissions (e.g. `600`) and `COPY` preserves them. nginx worker process can't read the file.

**Fix**: Add `RUN chmod 644 /usr/share/nginx/html/index.html` (or `chmod -R 644 /usr/share/nginx/html/` for multi-file) after the COPY in the Dockerfile. Rebuild the image.

### Port already allocated
**Symptom**: `docker run` fails with "Bind for 0.0.0.0:<port> failed: port is already allocated".

**Fix**: Check what's using the port (`docker ps -a` or `ss -tlnp | grep <port>`) and either stop the conflicting container or pick a different port. Common safe ports: 8088, 8089, 8090, 3001, 3002.

### Left-behind containers from failed attempts
**Symptom**: Dead containers from failed setup attempts accumulate on the server (e.g. `novnc-login`, test containers from debugging).

**Fix**: Clean up after failed attempts:
```bash
docker rm -f <failed-container-name>
docker image prune -f   # remove dangling images
```

This user explicitly does not want bloat on the server — always clean up failed containers, test images, and unused artifacts before finishing.

### Docker build context is bloated (no .dockerignore)
**Symptom**: `docker build` is extremely slow, copies hundreds of MB of node_modules/.venv into the image, or produces multi-GB images.

**Cause**: `COPY . .` copies everything in the project root — including `node_modules/`, `.venv/`, `__pycache__/`, `.git/`, and build artifacts.

**Fix**: Add a `.dockerignore` file BEFORE building:
```
node_modules/
.venv/
__pycache__/
*.pyc
.git/
dist/
.env
*.log
```

For Node.js projects with a separate frontend build step, also ignore:
```
web/node_modules/
web/dist/          # if the host dist is stale; usually build inside Dockerfile
```

**Rule of thumb**: Always `ls -la` the project root before writing a Dockerfile. If there's a `node_modules` or `.venv`, create `.dockerignore` first.

## Useful Commands

```bash
# List running containers
docker ps

# Stop and remove a container
docker rm -f <name>

# Rebuild after editing HTML
docker rm -f <name>
docker build -t <name> .
docker run -d --name <name> -p <port>:80 --restart unless-stopped <name>

# View container logs
docker logs <name>

# Exec into container to debug
docker exec -it <name> sh
```

## Tailscale Notes

- Get the server's Tailscale IPv4: `tailscale ip -4`
- Get all devices on the tailnet: `tailscale status`
- The container does NOT need Tailscale installed — it binds to `0.0.0.0:<port>` which is accessible via the host's Tailscale IP
- `--restart unless-stopped` ensures the container survives server reboots
- For external access (non-Tailscale), use a reverse proxy (Caddy/Traefik) or cloudflared tunnel instead

## Templates

- `templates/Dockerfile.static` — minimal nginx:alpine Dockerfile for single-file sites
- `templates/Dockerfile.static-multi` — Dockerfile for multi-file static sites
- `templates/nginx.proxy.conf` — nginx config with `/api/*` reverse-proxy for static sites that call a backend (e.g. chat UIs, dashboards)

## Related Skills

- `popular-web-designs` — design system templates to inform the visual style before building
- `claude-design` — design process and taste guidance for one-off HTML artifacts