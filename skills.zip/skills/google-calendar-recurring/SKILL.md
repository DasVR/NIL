---
name: google-calendar-recurring
description: "Create, manage, and bulk-replace recurring events in Google Calendar using the raw API. Complements the bundled google-workspace skill which lacks RRULE support in its CLI wrapper."
version: 1.0.0
author: agent
platforms: [linux, macos, windows]
requires_skills: [google-workspace]
---

# Google Calendar Recurring Events

The bundled `google-workspace` skill's `google_api.py` CLI wrapper does **not**
expose `recurrence` / RRULE parameters. When you need repeating events (weekly
school blocks, daily standups, etc.), use this skill's raw-Python recipe.

## When to use

- Weekly school/work schedules (Mon–Fri classes, deep-work blocks)
- Daily or weekly repeating meetings
- Bulk-replacing scattered one-off events with a clean recurring series
- Any event needing `RRULE` (BYDAY, COUNT, UNTIL, etc.)

## Prerequisites

Complete OAuth setup via the `google-workspace` skill first. Token lives at
`~/.hermes/google_token.json`.

## Quick recipe: create a weekly recurring event

```python
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
import json

with open('/home/das/.hermes/google_token.json') as f:
    token_data = json.load(f)

creds = Credentials(
    token=token_data['token'],
    refresh_token=token_data.get('refresh_token'),
    token_uri=token_data.get('token_uri', 'https://oauth2.googleapis.com/token'),
    client_id=token_data['client_id'],
    client_secret=token_data['client_secret'],
    scopes=token_data['scopes']
)

service = build('calendar', 'v3', credentials=creds)

body = {
    'summary': 'Morning Routine',
    'description': 'Wake up, shower, breakfast, commute prep.',
    'start': {'dateTime': '2026-08-11T06:00:00-04:00', 'timeZone': 'America/New_York'},
    'end':   {'dateTime': '2026-08-11T07:15:00-04:00', 'timeZone': 'America/New_York'},
    'recurrence': ['RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR'],
    'colorId': '10',  # optional
}

ev = service.events().insert(calendarId='primary', body=body).execute()
print(ev['id'], ev['htmlLink'])
```

## Bulk replace: scattered one-offs → recurring series

A common pattern: user has dozens of manually-created daily events that overlap
or are inconsistent. The fix is list → filter → delete → recreate.

```python
from hermes_tools import terminal
import json

# 1. List all events in the date range
result = terminal(
    'python ~/.hermes/skills/productivity/google-workspace/scripts/google_api.py '
    'calendar list --start 2026-08-10T00:00:00-04:00 '
    '--end 2026-08-31T23:59:59-04:00 --max 100'
)
events = json.loads(result['output'])

# 2. Filter by keyword/summary
to_delete = [e for e in events if 'P1:' in e['summary'] or 'Morning Routine' in e['summary']]

# 3. Delete (the CLI handles one-by-one fine)
for e in to_delete:
    terminal(f"python ~/.hermes/skills/productivity/google-workspace/scripts/google_api.py "
             f"calendar delete {e['id']}")

# 4. Recreate as recurring via raw API (see Quick recipe above)
```

## Common RRULE patterns

| Pattern | RRULE string |
|---------|-------------|
| Weekly Mon–Fri | `RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR` |
| Weekly Sat–Sun | `RRULE:FREQ=WEEKLY;BYDAY=SA,SU` |
| Daily for 10 days | `RRULE:FREQ=DAILY;COUNT=10` |
| Weekly until Dec 31 | `RRULE:FREQ=WEEKLY;UNTIL=20261231T235959Z` |

## Deleting recurring series vs instance

- **Base event ID** (no `_YYYYMMDD` suffix) → deletes the **entire series**.
- **Instance ID** (has `_YYYYMMDD` suffix) → deletes **only that occurrence**.

## Pitfalls

1. **Timezone is mandatory** — always include `timeZone` in `start`/`end` or use
   explicit offsets like `-04:00`. Silent failures happen without it.
2. **First occurrence date drives the RRULE** — if your first date is a Tuesday
   and RRULE says `BYDAY=MO`, the first occurrence will be the *next* Monday.
3. **Don't use background=True for bulk delete** — the user explicitly dislikes
   background processes for calendar operations. Run in foreground with generous
   timeout, or use `execute_code` with Python loops.
4. **Google Calendar API rate limits** — avoid rapid-fire sequential API calls.
   Space insertions by ~100ms or batch when possible.

## Color IDs (Google Calendar)

| ID | Color |
|----|-------|
| 1  | Lavender |
| 2  | Sage |
| 3  | Grape |
| 4  | Flamingo |
| 5  | Banana |
| 6  | Tangerine |
| 7  | Peacock |
| 8  | Graphite |
| 9  | Blueberry |
| 10 | Basil |
| 11 | Tomato |

## References

- `google-workspace` skill — OAuth setup and basic CRUD
- Google Calendar API docs: https://developers.google.com/calendar/api/v3/reference/events
- RRULE spec (RFC 5545): https://datatracker.ietf.org/doc/html/rfc5545#section-3.3.10
