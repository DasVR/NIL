# Homework Scheduling Workflow

## Trigger
User asks to put homework/assignments on their calendar.

## Rule: Always Ask Due Dates First

Never create a stacked single-day schedule without validating due dates with the user. The default should be spreading assignments across available study blocks between today and each due date.

## Workflow

1. **Collect due dates**: Ask "When is each assignment due?"
2. **Map by urgency**: Sort assignments by due date (nearest first).
3. **Slot into study blocks**: Assign each to the next available deep-work / study block.
4. **Create one-off events** with `description` containing the due date.
5. **If corrected**: Bulk-delete by event ID, then recreate.

## Pitfall: Stacking Everything into Today

- **What happened**: Created 5 homework events all on the same afternoon without asking due dates.
- **User correction**: "No im splitting it up, english is due tommorrow, ap stats book work is due friday..."
- **Fix**: Deleted all 5 events, then recreated them spread across Wed-Sun based on actual due dates.

## Example (Python)

```python
from hermes_tools import terminal
import json

# 1. Delete incorrectly-stacked events
for eid in old_event_ids:
    terminal(f"python ~/.hermes/skills/productivity/google-workspace/scripts/google_api.py calendar delete {eid}")

# 2. Recreate spread across days
for a in assignments:
    terminal(
        f"python ~/.hermes/skills/productivity/google-workspace/scripts/google_api.py "
        f"calendar create --summary \"HW: {a['name']}\" "
        f"--start \"{a['start']}\" --end \"{a['end']}\" "
        f"--description \"{a['desc']}\""
    )
```
