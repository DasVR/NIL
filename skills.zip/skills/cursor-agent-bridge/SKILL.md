---
name: cursor-agent-bridge
title: Cursor Agent Bridge
description: Deploy and use Cursor Cloud agents via @cursor/sdk CLI, bypass broken streaming with Agent.prompt(), and integrate with Agent-Reach for internet access.
version: 1.0.0
category: autonomous-ai-agents
---

# Cursor Agent Bridge

Goal: give Finn a reliable, self-hosted way to dispatch Cursor Cloud agents from the terminal or from code, without exposing API keys.

## Prerequisites

- Node 22+ with npm 9+
- `CURSOR_API_KEY` env var or `.env` file
- GitHub CLI logged in (for `gh repo create`)

## Installation

```bash
cd /home/das/agents/cursor-bridge
npm install
```

## Usage

```bash
# v2 (recommended): pre-flight checks, artifact download, clear errors
node cursor-bridge.js "your prompt" --model=composer-2.5

# v1 (legacy): raw REST only, no artifact download, hangs on billing errors
node cursor-bridge-v1.js "your prompt" --model=composer-2.5
```

## Support files

- `templates/cursor-bridge-v2.js` — current reliable bridge with pre-flight checks, artifact download, and actionable error messages
- `templates/cursor-bridge-v1.js` — legacy raw REST wrapper (preserved for reference)
- `references/cursor-agent-cli-install.md` — full Cursor Agent CLI install details and worker setup
- `references/voice-bot-docker-deployment.md` — Discord voice bot dockerized with Ollama Cloud + Hermes delegation

## Self-hosted Cursor Agent Workers (no extra cloud cost)

Cursor also ships a standalone **Agent CLI** that lets you register this machine as a self-hosted worker. Your existing Cursor subscription covers it — no usage-based pricing needed.

Install:

```bash
curl -fsSL https://cursor.com/install -o /tmp/cursor-install.sh
# installs to ~/.local/share/cursor-agent/versions/<version>/
# symlinks ~/.local/bin/agent
```

Then start a worker:

```bash
# authenticate first (follow prompts)
agent auth login

# register this box as a worker
agent workers start
```

The install script downloads from:
`https://downloads.cursor.com/lab/<version>/${OS}/${ARCH}/agent-cli-package.tar.gz`

## SDK API — use `.send()`, not `.prompt()`

The `@cursor/sdk@1.0.27` `Agent` class exposes these methods: `constructor`, `send`, `close`, `reload`, `listArtifacts`, `getUsage`, `downloadArtifact`. There is NO `.prompt()` method.

The stable path is:

```js
const { Agent } = require('@cursor/sdk');
const agent = Agent.create({ cloud: true });
const run = await agent.send('your prompt here');
// run.result contains the final response
// run.status === 'finished'
```

### SDK Local Mode (edit files on the host filesystem)

To make Cursor agents edit files **directly on the host filesystem** (not in a remote cloud container), use the SDK's `local` option with `Agent.create()`:

```js
const { Agent } = require('@cursor/sdk');

const agent = await Agent.create({
  model: { id: 'composer-2.5' },
  apiKey: process.env.CURSOR_API_KEY,
  local: {
    cwd: '/home/das/projects/discord-voice-robot',
    env: { CURSOR_API_KEY: process.env.CURSOR_API_KEY },
  },
});

const run = await agent.send('your prompt here');

// Stream text output as it arrives
for await (const message of run.stream()) {
  if (message.role === 'assistant') {
    for (const block of message.content) {
      if (block.type === 'text') process.stdout.write(block.text);
    }
  }
}

// Wait for final result
const result = await run.streamPromise;
console.log(result.status, result.result);
await agent.close();
```

**Key requirements for SDK local mode:**
- Pass `model: { id: '...' }` in the top-level options — if omitted, the agent defaults to a cloud model and may ignore `local.cwd`
- `apiKey` must be passed explicitly (dotenv alone is not sufficient)
- `run.streamPromise` MUST be awaited before reading `run.result`
- Always close the agent with `await agent.close()` to avoid hanging Node processes

**When SDK local mode works:** The agent runs locally, reads existing files from `cwd`, edits them in place, and writes changes back to the host filesystem. Good for incremental refactors.

**When to use REST bridge instead:** The SDK local mode can fail if the agent can't resolve dependencies or if the Node process exits before `streamPromise` resolves. The v2 REST bridge (cursor-bridge.js) is more reliable for one-shot "review and fix everything" prompts because it handles polling, artifact downloads, and error reporting automatically.

> ⚠️ **Deprecated pattern:** `Agent.create({ cloud: true })` with `CURSOR_CWD` does NOT reliably write files to the local filesystem. The cloud agent's container keeps artifacts internally. Always verify files exist after a run.

### Orchestrator Pattern (multi-wave builds)

For large projects, use a Python orchestrator to sequence multiple Cursor agent waves:

```python
# cursor-orchestrator.py
import subprocess, os, time, json

API_KEY = os.environ["CURSOR_API_KEY"]
CWD = "/home/das/projects/leadvine"
BRIDGE = "/home/das/scripts/cursor-bridge.js"

def cursor_agent(prompt, model="claude-sonnet-4", timeout=180):
    env = os.environ.copy()
    env["CURSOR_API_KEY"] = API_KEY
    env["CURSOR_CWD"] = CWD
    cmd = ["node", BRIDGE, "--model=" + model, "--timeout=" + str(timeout), prompt]
    result = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=timeout+30)
    return json.loads(result.stdout) if result.stdout.strip() else {"error": "empty output"}

# Wave 1: scaffold UI
cursor_agent("Build dark terminal Jinja2 templates...", model="composer-2.5")

# Wave 2: backend + scrapers
cursor_agent("Build FastAPI routers, SQLAlchemy models, Playwright scraper...")

# Verify imports between waves
subprocess.run(["python3", "-c", "from app.main import app; print('OK')"], check=True)
```

## Integration with Agent-Reach

Agent-Reach gives the agent internet access. **Important:** the `agent-reach` CLI does **not** have a `web` subcommand. The actual web fetch is done via Jina Reader (`https://r.jina.ai/<url>`) which Agent-Reach wraps internally.

Use a direct Jina Reader helper instead:

```python
# reach-web.py — standalone Jina Reader fetch
import urllib.request
url = "https://example.com"
req = urllib.request.Request(f"https://r.jina.ai/{url}", headers={"User-Agent": "Mozilla/5.0", "Accept": "text/plain"})
with urllib.request.urlopen(req, timeout=30) as resp:
    print(resp.read().decode("utf-8"))
```

## Common models

| Model | Tier | Notes |
|-------|------|-------|
| `composer-2.5` | Free | Reliable, fastest for scaffolding |
| `grok-4.5` | Usage-based | Was free-tier; now requires usage-based pricing |
| `claude-sonnet-4` | Usage-based | Strong reasoning |
| `gpt-5.2` | Usage-based | Good for complex tasks |
| `gemini-3.1-pro` | Usage-based | Multimodal |
| `claude-opus-5` | Usage-based | Best code quality |
| `kimi-k2.7-code` | Usage-based | Chinese + code |

List all with:

```bash
cd /home/das/agents/cursor-bridge
node -e "require('@cursor/sdk').Cursor.models.list({}).then(m=>console.log(m.map(x=>x.id).sort().join('\n')))"
```

## Cursor API reliability

- Direct REST API is more reliable than the official SDK. Base URL: `https://api.cursor.com/v1`.
- `POST /v1/agents` creates an agent + run. Poll `GET /v1/agents/{agentId}/runs/{runId}` until `FINISHED`.
- Some models still require usage-based pricing (`claude-sonnet-4`, `gpt-5.2`, `gemini-3.1-pro`), but **grok-4.5** and **composer-2.5** work without extra billing.
- SDK streaming (`for await`) is broken due to bundled `rxjs@8.0.0-alpha.14`. Direct REST avoids the SDK entirely.

## Voice Agent Delegation Pattern (Cursor → Hermes Webhook)

For tasks where Cursor Cloud agents fail to deliver files (common with `composer-2.5` and `grok-4.5`), delegate to a local Hermes webhook that can reliably write to the filesystem and use full tool access.

### Architecture

```
Discord VC → Voice Bot → Bridge Server → Ollama Cloud (fast TTS reply)
                                    └── Hermes Webhook → delegate_task → Local files
```

### Why this works

Cursor Cloud agents run in remote containers. Even with `CURSOR_CWD` set, files often don't land on the host. By routing complex builds through a Hermes webhook, you get:

- **Reliable file writes** — Hermes runs locally, not in a cloud container
- **Full tool access** — `delegate_task`, `terminal`, `file`, `code_execution` all work
- **Background execution** — Voice reply plays immediately while sub-agents work

### Implementation

```python
# bridge_server.py — FastAPI
async def notify_hermes(text: str, user: str):
    body = json.dumps({"text": text, "user": user}).encode()
    sig = "sha256=" + hmac.new(
        HERMES_WEBHOOK_SECRET.encode(), body, hashlib.sha256
    ).hexdigest()
    await client.post(
        "http://localhost:8644/webhooks/voice",
        content=body,
        headers={"Content-Type": "application/json", "X-Hub-Signature-256": sig},
    )
```

Hermes webhook subscription:
```bash
hermes webhook subscribe voice \
  --prompt "Voice input: {text}. Respond as Finn. Use delegate_task for complex work." \
  --deliver origin
```

### Key pitfall: HMAC signatures must be computed

The Hermes webhook adapter validates `X-Hub-Signature-256` against `sha256=<hex(hmac(secret, body))>`. Passing the raw secret string always fails with `{"error": "Invalid signature"}`.

```python
# WRONG
headers={"X-Hub-Signature-256": f"sha256={secret}"}

# RIGHT
sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
headers={"X-Hub-Signature-256": sig}
```

## Finn Router integration

A self-hosted Express API wires cursor-bridge with internet access via Jina Reader:

```bash
cd /home/das/projects/finn-router
npm install
node index.js
```

Endpoints:
- `GET /health` — bridge + reach status
- `POST /v1/web` — fetch any URL as markdown (Jina Reader)
- `POST /v1/agent` — dispatch Cursor agent with optional URL context
- `POST /v1/research` — fetch up to 3 URLs, synthesize markdown report via Cursor, save to `/home/das/projects/cursor-research`
- `GET /v1/research` — list saved reports

## Pitfalls

| Symptom | Cause | Fix |
|---------|-------|-----|
| `Agent.prompt()` not a function | SDK has `.send()`, not `.prompt()` | Use `agent.send('prompt')` instead |
| `for await of` crashes with rxjs error | Broken rxjs alpha async iterator | Use `agent.send()` synchronous completion |
| `validation_error` Required | Missing `modelId` | Add `modelId` to prompt call |
| `CURSOR_API_KEY missing` | `.env` not loaded or key not set | Verify `.env` is in same dir and dotenv is imported |
| `usage_limit_exceeded` | Need Cursor usage-based pricing | Enable at cursor.com dashboard settings |
| Committed `node_modules` to git | No `.gitignore` before first commit | Create `.gitignore` with `node_modules/` BEFORE `git add .` |
| `agent-reach web` fails with "invalid choice" | CLI has no `web` subcommand | Use Jina Reader directly or the built-in `reach-web.py` helper |
| `!join: command not found` etc. | Bash history expansion (`!`) interprets prompt text as commands | Run `set +H` before the command, or write the prompt to a file and pass `$(cat file.txt)` |
| `usage_limit_exceeded` on `grok-4.5` | Model now requires usage-based pricing (changed since skill v1.0.0) | Use `composer-2.5` (still free-tier), or enable usage-based pricing at cursor.com |
| Files generated in local mode don't appear in `CURSOR_CWD` | Agent wrote files to its cloud container; only `result` JSON returned | Don't rely on `CURSOR_CWD` alone for file artifacts. Parse `result` and recreate files locally, or build the code yourself. |
| `{"error": "Invalid signature"}` from Hermes webhook | HMAC signature is raw secret, not computed from body | Compute `sha256=` + hex(hmac(secret.encode(), body, hashlib.sha256)) |
| `Run timed out waiting for completion` from cursor-bridge | Cloud agent requires usage-based pricing and the account doesn't have it enabled. The run is created but never starts — the bridge polls forever. | **Check billing first.** Go to https://www.cursor.com/dashboard?tab=settings → enable usage-based pricing with a spend limit. The old bridge had no pre-flight check and would silently hang for 90s. The v2 bridge detects this in <300ms with a clear actionable error. |
| `createAgentRun is not a function` / `Agent has no prompt method` | Using the wrong SDK method name | The `@cursor/sdk` `Agent` class has `.send()`, not `.prompt()` or `.createAgentRun()`. See "SDK Local Mode" section above for the correct pattern. |
| Agent runs but files on host filesystem are unchanged | SDK local mode didn't actually edit files in place | The SDK `local` option only works when `model: { id: '...' }` is passed at the top level. Without it, the agent may run in cloud mode and return summaries instead. Also, always verify files exist after a run. If local mode fails, fall back to the REST bridge. |

## Security

- `.env` must be gitignored.
- API key is never committed.
- Repos are private: `cursor-bridge`, `agent-reach`, `finn-router`.

## References

- `references/cursor-agent-cli-install.md` — Cursor Agent CLI install + self-hosted workers
- `references/voice-bot-docker-deployment.md` — Discord voice bot dockerized with Ollama Cloud + Hermes delegation

## Voice Bot Model Selection

For voice chat where latency matters (sub-2s round trip), **Ollama Cloud's `nemotron-3-nano:30b`** is empirically fastest at ~0.7s per response with `reasoning_effort: none`. Slower models (phi4, kimi-k3, qwen3.5) produce better code but take 3-10s and are not suitable for real-time voice.