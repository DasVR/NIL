# Cursor SDK `Agent.prompt()` Discovery — 2026-08-10

## Finding

`@cursor/sdk@1.0.27` **DOES** have a static `.prompt()` method on the `Agent` class. It is a convenience wrapper that:
1. Creates an agent (`Agent.create(options)`)
2. Sends the prompt (`agent.send(prompt)`)
3. Waits for completion (`run.streamPromise`)
4. Auto-disposes the agent
5. Returns a `Run` object with `.result`, `.status`, `.id`, `.durationMs`, `.usage`

## Correct usage

```js
const { Agent } = require('@cursor/sdk');
const run = await Agent.prompt("your prompt here", {
  apiKey: process.env.CURSOR_API_KEY,
  model: { id: "composer-2.5" },
  environment: "local",  // or "cloud"
  cwd: "/home/das/projects/discord-voice-robot",
});
// run.result is the final response text
// run.status === "finished"
```

## What does NOT work

The `Run` object does NOT have `.textStream`. Attempting:
```js
for await (const chunk of run.textStream) { ... }
```
throws `TypeError: Cannot read properties of undefined (reading 'Symbol(Symbol.asyncIterator)')`.

Text is available synchronously via `run.result` after the prompt resolves.

## Instance-level pattern (if you need artifacts / file changes)

```js
const agent = await Agent.create({
  apiKey: process.env.CURSOR_API_KEY,
  model: { id: "composer-2.5" },
  environment: "local",
  cwd: "/home/das/projects/...",
});
const run = await agent.send("your prompt here");
await run.streamPromise;  // MUST await before reading result
console.log(run.result);
const changes = await run.getFileChanges();
await agent.close();
```

## Why the skill was wrong

The original SKILL.md claimed "There is NO `.prompt()` method" and that `.send()` was the only path. This was incorrect — `.prompt()` exists and is actually the simpler, recommended path for one-shot delegation. The `.send()` path is for advanced use cases where you need streaming, artifacts, or file-change tracking.
