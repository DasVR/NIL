# Cursor Agent CLI Installer Details

## What it downloads

The official installer (`curl -fsSL https://cursor.com/install`) is a bash script that:

1. Detects OS (`linux` or `darwin`) and arch (`x64` or `arm64`)
2. Downloads from:
   `https://downloads.cursor.com/lab/<version>/${OS}/${ARCH}/agent-cli-package.tar.gz`
   (e.g., `https://downloads.cursor.com/lab/2026.07.23-e383d2b/linux/x64/agent-cli-package.tar.gz`)
3. Extracts to `~/.local/share/cursor-agent/versions/<version>/`
4. Symlinks `~/.local/bin/agent` → the extracted binary
5. Prints PATH instructions

## No sudo needed

Everything goes under `$HOME`:
- Binary: `~/.local/share/cursor-agent/versions/<version>/`
- Symlink: `~/.local/bin/agent`

## Post-install

```bash
# make sure ~/.local/bin is in PATH
export PATH="$HOME/.local/bin:$PATH"

# authenticate with cursor account
agent auth login

# start a worker on this machine
agent workers start
```

## Worker behavior

- Connects **outbound** to Cursor over HTTPS — no inbound ports needed
- Runs in the background, accepts tasks dispatched from other Cursor instances
- Can run builds/tests, edit files, clone repos
- Uses your existing Cursor subscription — no extra cloud costs

## Limitations

- Requires Cursor subscription (Pro/Business/Team)
- May require enabling "self-hosted workers" in Cursor Dashboard settings
- The `agent workers start` command might block the terminal (run it in tmux/screen if needed)
