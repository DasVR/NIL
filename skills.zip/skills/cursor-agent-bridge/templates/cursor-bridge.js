#!/usr/bin/env node
/**
 * cursor-bridge.js — Cursor Cloud Agent CLI wrapper
 *
 * Usage:
 *   node cursor-bridge.js "your prompt here" --model=composer-2.5
 *
 * Models: composer-2.5, claude-opus-5, claude-opus-4-8, grok-4.5, gpt-5.2, etc.
 *   See full list with: node -e "require('@cursor/sdk').Cursor.models.list({}).then(m=>console.log(m.map(x=>x.id)))"
 *
 * Env: CURSOR_API_KEY (loaded from .env file in this dir)
 */

const { Agent, configureCursorSdk } = require('@cursor/sdk');
const dotenv = require('dotenv');

dotenv.config({ quiet: true });

const API_KEY = process.env.CURSOR_API_KEY;
if (!API_KEY) {
  const out = { status: 'error', error: 'CURSOR_API_KEY env var required', code: 'missing_key' };
  console.log(JSON.stringify(out));
  process.exit(1);
}

configureCursorSdk({ apiKey: API_KEY });

async function main() {
  const args = process.argv.slice(2);
  const promptIndex = args.findIndex(a => !a.startsWith('--'));
  const prompt = promptIndex >= 0 ? args[promptIndex] : 'say hello';
  const modelFlag = args.find(a => a.startsWith('--model='));
  const modelId = modelFlag ? modelFlag.split('=')[1] : 'composer-2.5';

  const result = await Agent.prompt(prompt, {
    cloud: true,
    model: { id: modelId }
  });

  console.log(JSON.stringify(result, null, 2));
}

main().catch(err => {
  const out = {
    status: 'error',
    error: err.message || String(err),
    code: err.code || err.status || null
  };
  console.log(JSON.stringify(out, null, 2));
  process.exit(1);
});
