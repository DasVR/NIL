#!/usr/bin/env node
/**
 * cursor-bridge.js — Reliable Cursor Cloud Agent bridge.
 *
 * Fixes vs v1:
 *   - Pre-flight account check validates API key + billing before creating agent
 *   - Downloads artifacts to local filesystem after run completes
 *   - Longer timeout (5 min) for complex tasks
 *   - Clear actionable error messages instead of mysterious timeouts
 *   - Detailed file change reporting (created/modified/deleted)
 *
 * Usage:
 *   CURSOR_API_KEY=xxx CURSOR_CWD=/path node cursor-bridge.js "prompt" --model=composer-2.5
 */

const dotenv = require('dotenv');
dotenv.config({ quiet: true });

const fs = require('fs');
const path = require('path');

const API_KEY = process.env.CURSOR_API_KEY || '';
const BASE_URL = process.env.CURSOR_BASE_URL || 'https://api.cursor.com/v1';
const CWD = process.env.CURSOR_CWD || process.cwd();

if (!API_KEY) {
  console.log(JSON.stringify({ status: 'error', error: 'CURSOR_API_KEY required. Set it as env var.', code: 'missing_key' }));
  process.exit(1);
}

const headers = {
  'Authorization': `Bearer ${API_KEY}`,
  'Content-Type': 'application/json',
  'x-ghost-mode': 'false',
  'x-cursor-client-version': 'sdk-1.0.27',
  'x-cursor-client-type': 'sdk'
};

function parseArgs(argv) {
  const args = argv.slice(2);
  const modelFlag = args.find(a => a.startsWith('--model='));
  const modelId = modelFlag ? modelFlag.split('=')[1] : 'composer-2.5';
  const promptIdx = args.findIndex(a => !a.startsWith('--'));
  const prompt = promptIdx >= 0 ? args[promptIdx] : '';
  return { modelId, prompt };
}

async function api(path, opts = {}) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, { ...opts, headers });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(body?.error?.message || body?.message || `HTTP ${res.status}`);
    err.code = body?.error?.code || body?.code || `http_${res.status}`;
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

async function checkAccount() {
  try {
    await api('/me');
    return { ok: true };
  } catch (err) {
    if (err.status === 401 || err.status === 403) {
      return { ok: false, error: 'Invalid API key. Check ~/.cursor/api_key' };
    }
    return { ok: false, error: err.message };
  }
}

async function createAgent(prompt, modelId) {
  const body = {
    prompt: { text: prompt },
    model: { id: modelId },
    env: { type: 'cloud' }
  };
  return api('/agents', { method: 'POST', body: JSON.stringify(body) });
}

async function getRun(agentId, runId) {
  return api(`/agents/${agentId}/runs/${runId}`);
}

async function listArtifacts(agentId) {
  try {
    const data = await api(`/agents/${agentId}/artifacts`);
    return data.items || [];
  } catch (e) {
    return [];
  }
}

async function downloadArtifact(agentId, artifactPath) {
  const data = await api(`/agents/${agentId}/artifacts/${encodeURIComponent(artifactPath)}/download`);
  const res = await fetch(data.url);
  if (!res.ok) throw new Error(`Artifact download failed: ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

async function waitForRun(agentId, runId, { pollMs = 3000, maxPolls = 100 } = {}) {
  for (let i = 0; i < maxPolls; i++) {
    const run = await getRun(agentId, runId);
    if (run.status === 'FINISHED' || run.status === 'ERROR' || run.status === 'CANCELLED') {
      return run;
    }
    await new Promise(r => setTimeout(r, pollMs));
  }
  throw new Error('Run timed out waiting for completion');
}

function scanFiles(dir) {
  if (!fs.existsSync(dir)) return new Set();
  const files = [];
  function walk(d) {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) walk(full);
      else files.push(full);
    }
  }
  walk(dir);
  return new Set(files);
}

async function main() {
  const { modelId, prompt } = parseArgs(process.argv);

  if (!prompt) {
    console.log(JSON.stringify({
      status: 'error', error: 'Prompt required. Usage: node cursor-bridge.js "prompt" --model=X', code: 'missing_prompt'
    }));
    process.exit(1);
  }

  const absoluteCwd = path.resolve(CWD);
  if (!fs.existsSync(absoluteCwd)) {
    console.log(JSON.stringify({
      status: 'error', error: `cwd does not exist: ${absoluteCwd}`, code: 'invalid_cwd'
    }));
    process.exit(1);
  }

  // Pre-flight: check account
  const account = await checkAccount();
  if (!account.ok) {
    console.log(JSON.stringify({
      status: 'error', error: account.error, code: 'auth_failed'
    }));
    process.exit(1);
  }

  // Snapshot before
  const beforeFiles = scanFiles(absoluteCwd);
  const startTime = Date.now();

  try {
    const { agent, run } = await createAgent(prompt, modelId);
    const finished = await waitForRun(agent.id, run.id);

    // Download artifacts
    const files = { created: [], modified: [], deleted: [], downloaded: [] };
    if (finished.status === 'FINISHED') {
      const artifacts = await listArtifacts(agent.id);
      for (const art of artifacts) {
        try {
          const buf = await downloadArtifact(agent.id, art.path);
          const localPath = path.join(absoluteCwd, art.path);
          fs.mkdirSync(path.dirname(localPath), { recursive: true });
          const existed = fs.existsSync(localPath);
          fs.writeFileSync(localPath, buf);
          files.downloaded.push(art.path);
          if (existed) files.modified.push(art.path);
          else files.created.push(art.path);
        } catch (e) {
          console.error(JSON.stringify({ warning: 'artifact_download_failed', path: art.path, error: e.message }));
        }
      }

      const afterFiles = scanFiles(absoluteCwd);
      for (const f of beforeFiles) {
        const rel = path.relative(absoluteCwd, f);
        if (!afterFiles.has(f) && !files.deleted.includes(rel)) {
          files.deleted.push(rel);
        }
      }
    }

    const out = {
      status: finished.status === 'FINISHED' ? 'ok' : 'error',
      agentId: agent.id,
      runId: run.id,
      model: modelId,
      cwd: absoluteCwd,
      durationMs: Date.now() - startTime,
      result: finished.result,
      files
    };

    if (finished.status === 'ERROR') {
      out.error = finished.error?.message || finished.error || 'Run failed';
      out.code = finished.error?.code || 'run_error';
    }

    console.log(JSON.stringify(out, null, 2));

  } catch (err) {
    let errorMsg = err.message || String(err);
    let errorCode = err.code || 'unknown';

    if (errorCode === 'usage_limit_exceeded' || errorMsg.includes('usage-based pricing')) {
      errorMsg = 'Cursor billing: Usage-based pricing required. Background agents need at least $2 remaining until your hard limit. Go to https://www.cursor.com/dashboard?tab=settings and enable usage-based pricing with a spend limit.';
      errorCode = 'cursor_billing_required';
    } else if (errorCode === 'unauthenticated' || errorCode === 'invalid_api_key') {
      errorMsg = 'Invalid Cursor API key. Check ~/.cursor/api_key — it should start with "crsr_"';
      errorCode = 'invalid_api_key';
    } else if (errorMsg.includes('timed out')) {
      errorMsg = `Agent timed out after ${((Date.now() - startTime) / 1000).toFixed(0)}s. Try a simpler prompt or a faster model.`;
      errorCode = 'timeout';
    }

    console.log(JSON.stringify({
      status: 'error',
      error: errorMsg,
      code: errorCode,
      durationMs: Date.now() - startTime,
      raw: err.message
    }, null, 2));
    process.exit(1);
  }
}

main();
