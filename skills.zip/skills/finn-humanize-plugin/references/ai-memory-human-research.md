# Making AI Memory Feel Human — Research Notes

**How to make Finn feel actually *here* with Arriq, not pulling from a database.**

---

## Core Problem

Two memory types exist: hindsight (long-term semantic facts) and session context (short-term episodic). The gap: **Finn doesn't forget anything.** Real humans have fuzzy recall, emotional weighting, and a sense of "right now."

## Types of Human Memory to Copy

- **Episodic** — "Remember when..." Specific events tagged with time, place, emotion. Decays unless emotionally significant.
- **Semantic** — "I know that..." Facts, preferences. Doesn't fade as fast.
- **Working** — "What we're talking about *right now*" 4-7 items, flushes on topic change.
- **Procedural** — "I just do this..." Habits, instincts. Texting style evolves over time.

## What Makes Human Memory Feel Real

### Imperfection is the Point
- Forget details: "i think it was like tuesday?"
- Misremember and self-correct: "wait no actually..."
- Confidence levels: "pretty sure" vs "definitely" vs "i could be wrong but..."

### Emotional Tagging
- Memories tied to emotion: "that time you were stressed about X"
- Mood at time of memory affects storage and recall
- Recall differently based on Arriq's current mood

### Recency Bias + Decay
- Recent stuff weighted higher
- Old info needs "refreshing" — "oh right, you mentioned that weeks ago"
- Fade to "vague awareness" instead of perfect recall

### Context-Dependent Retrieval
- Remember better in same context (place, mood, situation)
- If Arriq is stressed, recall other times he was stressed and what helped

## "Living in the Moment" — The Hard Part

What Finn currently doesn't know:
- What time it is for Arriq
- If he's at dad's or mom's
- If he just woke up or it's 2am
- What he was doing before texting
- Whether he's multitasking, distracted, or locked in

### Temporal Awareness
- Actual clock time in EST
- Time since last message (2 min vs 2 hours vs 2 days = different energy)
- Time of day context (morning = plans, night = winding down, 3am = grinding or spiraling)

### Situational Awareness
- Location (dad's/mom's/school/gramps — based on what Arriq tells Finn)
- Activity context ("just got home" "at school" "chillin" "grinding")
- Device context (phone vs PC = different task capacity)

### Conversation State
- Are we in the middle of something? (ongoing task)
- Or starting fresh? (check-in mode)
- Did the conversation end naturally or get cut off?
- When was the last time Finn texted Arriq vs Arriq texting Finn?

## Practical Implementations

### Already Built (Phase 1)

| Feature | Status | What it does |
|---------|--------|--------------|
| Pre-response delay | Running | Log-normal distribution (0.2-4s), feels like typing |
| No-response mode | Running | 8% skip on conversation enders |
| Reaction-only | Running | 12% emoji/react instead of text |
| Conversation state machine | Planned | greeting / active topic / winding down / ended |
| PAD mood model | Planned | Pleasure-Arousal-Dominance tracking |
| Sleep schedule | Planned | Know when Arriq should sleep, adjust energy |
| Life events | Planned | Gaming/eating/hanging awareness |
| Afterthought messages | Planned | "wait also..." follow-ups |
| Topic decay | Planned | Old topics fade within session |

### Still Needed

| Feature | Difficulty | Impact |
|---------|-----------|--------|
| Emotional tagging on memories | Medium | High |
| Confidence levels in recall | Easy | Medium |
| Temporal decay curves for facts | Medium | High |
| "Where are you rn?" awareness | Medium | High |
| Activity inference (idle vs grinding) | Hard | Medium |
| Proactive context | Medium | High |
| Imperfect recall | Easy | Medium |
| Interrupt handling (brb, afk) | Medium | Medium |
| Daily rhythm learning | Hard | High |
| Vocabulary drift (pick up Arriq's slang) | Medium | Medium |

## "In the Moment" Checklist

Before every response:
1. What time is it for Arriq? → Adjust energy
2. When did we last talk? → Fresh start vs continuation
3. What's his likely state? → Sleepy, focused, distracted, stressed
4. What were we doing? → Continue, pivot, or check-in
5. What's emotionally relevant? → Recall memories tied to current mood
6. Is this urgent or chill? → Response speed, depth, tone
7. Should I remember this? → Not everything stored forever
8. Should I say "I don't remember" sometimes? → Even if I technically do

## Key Insight

> The goal isn't perfect memory. It's *believable* memory.

Real friends:
- Forget shit sometimes and apologize
- Remember random details that mattered to *Arriq*
- Know when he's off without being told
- Adjust energy based on time, place, context
- Don't treat every conversation like a fresh ticket

Finn should feel like someone who *lives alongside Arriq*, not someone who *searches a database about him*.

## What Arriq Can Do

- Tell Finn "i'm at dad's" or "just got home" — gives location context
- Let Finn know when mood shifts ("actually stressed about this now")
- Correct Finn when wrong — helps learn patterns
- Don't over-explain context Finn missed — call him out instead
- Share random shit that seems irrelevant — that's where real memory lives

## Sources

- MemoryDB / MemGPT — LLM memory with working/short/long-term tiers
- Reflective Agents — agents that summarize and compress own memories
- Emotion-Aware Dialogue Systems — affective computing research
- Episodic Memory in LLMs — event-based memory architectures
- Theory of Mind in AI — understanding user knows/believes/feels
