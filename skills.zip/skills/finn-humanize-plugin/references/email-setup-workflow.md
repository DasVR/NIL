# Email Setup Workflow — dasdev.net via Cloudflare (July 24 2026)

## What We Built
Set up hello@dasdev.net that routes through Cloudflare Email Routing, forwards to Gmail, and sends via Gmail SMTP with Himalaya CLI.

## Steps
1. **Cloudflare Email Routing**: Log into cloudflare.com → pick dasdev.net → Email → Email Routing → add route: hello@dasdev.net → arriqaalraee@gmail.com. Cloudflare auto adds MX records.
2. **Gmail App Password**: Go to https://myaccount.google.com/apppasswords → generate one for "mail".
3. **Store password securely**: `pass init arriqaalraee@gmail.com` then `pass insert email/gmail-app-password` and paste the app password.
4. **Himalaya config**: Write `~/.config/himalaya/config.toml` with account using SMTP through Gmail, referencing the pass-stored password.
5. **Test**: `himalaya message send --account dasdev < email.raw`

## Key Lesson
Sending FROM a residential IP gets flagged as spam. The correct architecture is:
- MX/forwarding via Cloudflare (free, handles inbound)
- Gmail SMTP for sending (reputable IP, won't get blacklisted)
- App password + pass for secure credential storage
- "Send mail as" alias in Gmail so replies appear from hello@dasdev.net

## Files
- `~/.config/himalaya/config.toml` — himalaya email client config
- `~/.hermes/config.yaml` — has `humanize.episodic_memory: true`
- `/home/das/business-info.txt` — user contact info saved
