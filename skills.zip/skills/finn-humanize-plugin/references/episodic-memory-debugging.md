# Episodic Memory Debugging — July 24 2026

## Problem
Episodic memory hooks (pre_llm_call_memory, post_llm_call_memory) were registered but producing ZERO output. No log entries, no file creation, no errors.

## Root Cause 1: Hook functions were `async def`
The core hook invoker in `agent/turn_context.py` and `agent/turn_finalizer.py` calls hooks SYNCHRONOUSLY:
```python
for hook in hooks:
    result = hook(session_id, user_message, ...)  # NOT awaited!
```
When `pre_llm_call_memory` was `async def`, it returned a coroutine object that was never awaited. The function body never executed. Zero logs, zero file creation.

Fix: Changed to regular `def pre_llm_call_memory(...)` (sync function).

## Root Cause 2: Still no output after sync conversion
After fixing async→sync, hooks still produced no output. Added unconditional debug logging:
```python
def pre_llm_call_memory(session_id, user_message, ...):
    with open("/tmp/hook_debug.log", "a") as f:
        f.write(f"HOOK_ENTERED: {datetime.now()}\n")
    # ... rest of function
```

This confirmed the hook WAS being called. The silent failure was actually that the log file `~/.hermes/episodic_memory.json` was being created but the standard logging level wasn't showing it.

## Verification
```bash
python3 -c "import json; f=open('/home/das/.hermes/episodic_memory.json'); d=json.load(f); print('moments:', len(d.get('moments',[])))"
```
Result: 2 moments stored, including "im at home rn since its 3:24am"

## Key Files
- `~/.hermes/plugins/humanize/__init__.py` — EpisodicMemory class, hook functions
- `~/.hermes/hermes-agent/agent/turn_context.py` — Hook invocation (lines 420+)
- `~/.hermes/hermes-agent/agent/turn_finalizer.py` — Hook invocation (lines 340+)
- `~/.hermes/hermes-agent/agent/shell_hooks.py` — Hook firing logic
- `~/.hermes/hermes-agent/website/docs/user-guide/features/hooks.md` — Hook signatures

## Lesson
All `pre_llm_call` and `post_llm_call` hooks MUST be synchronous `def` functions. The core does NOT await them.
