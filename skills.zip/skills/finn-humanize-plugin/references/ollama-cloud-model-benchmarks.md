# Ollama Cloud Model Benchmarks (July 13 2026 — Comprehensive)

24 models tested across 6 categories: casual convo, coding, agentic tool calling, research, writing, instruction following. All via Ollama Cloud API (`POST https://ollama.com/v1/chat/completions`).

## Test Methodology

- API: `POST https://ollama.com/v1/chat/completions` with `Authorization: Bearer $OLLAMA_API_KEY`
- Each test: single request, measured wall-clock time, token usage, content quality checked
- Tool calling: real OpenAI-format `tools` array with a `get_weather` function
- Coding: TaskManager class prompt (class + json persistence + error handling + under 60 lines)
- All tests run via `execute_code` with `urllib.request` (NOT terminal curl — terminal blocks long localhost calls)

## Models Tested (24)

glm-5.2, glm-5.1, glm-4.7, deepseek-v4-pro, deepseek-v4-flash, deepseek-v3.2, kimi-k2.7-code, kimi-k2.6, qwen3-coder-next, qwen3.5:397b, devstral-2:123b, devstral-small-2:24b, mistral-large-3:675b, ministral-3:14b, nemotron-3-super, nemotron-3-ultra, minimax-m2.7, minimax-m3, gpt-oss:120b, gpt-oss:20b, gemma3:4b, gemma3:12b, gemma3:27b, gemma4:31b, gemini-3-flash-preview

## Results by Category

### Casual Convo (short replies, speed matters most)
| model | latency | tokens | notes |
|-------|---------|--------|-------|
| glm-5.2 | 1.17s | 122t | solid, natural |
| deepseek-v4-flash | 1.1s | 114t | fast, decent |
| qwen3-coder-next | 1.14s | 70t | fastest, low tokens |
| devstral-small-2:24b | 1.23s | 53t | very efficient |
| gemma3:4b | 1.43s | 60t | ok for simple, no tool calling |
| mistral-large-3:675b | 1.71s | 64t | clean, efficient |
| nemotron-3-ultra | 1.23s | 93t | good balance |
| gemma4:31b | 2.72s | 97t | a bit slow for casual |

**WINNER: glm-5.2** — best balance of speed + natural language

### Coding (quality + speed)
| model | latency | tokens | has class | has json | quality |
|-------|---------|--------|-----------|----------|--------|
| qwen3-coder-next | 3.99s | 391t | yes | yes | best token efficiency |
| glm-5.2 | 3.62s | 487t | yes | yes | solid, fast |
| gemini-3-flash-preview | 3.47s | 669t | yes | yes | good but token heavy |
| deepseek-v4-flash | 3.38s | 670t | yes | yes | good but token heavy |
| kimi-k2.7-code | 10.03s | 673t | yes | yes | too slow |
| devstral-2:123b | 8.09s | 670t | yes | yes | too slow |
| gpt-oss:120b | 8.2s | 732t | yes | yes | token heavy, slow |
| deepseek-v4-pro | 10.13s | 670t | yes | yes | too slow |

**WINNER: qwen3-coder-next** — fastest decent code, lowest token usage (391t)
**RUNNER UP: glm-5.2** — solid code, fast, efficient tokens (487t)
**NOTE: None included error handling even when explicitly asked.**

### Agentic / Tool Calling (real OpenAI tools array)
| model | latency | tokens | tool calls | notes |
|-------|---------|--------|-----------|-------|
| gemma4:31b | 0.86s | 130t | 1 | FASTEST + cheapest |
| devstral-small-2:24b | 0.92s | 131t | 1 | nearly identical |
| gpt-oss:20b | 1.03s | 202t | 1 | solid |
| devstral-2:123b | 1.01s | 131t | 1 | clean |
| deepseek-v4-flash | 1.23s | 404t | 1 | fast but token heavy |
| glm-5.2 | 3.48s | 235t | 1 | WORKS but 4x slower than gemma4 |
| nemotron-3-ultra | 1.33s | 404t | 1 | fast, token heavy |
| mistral-large-3:675b | 1.46s | 131t | 1 | efficient but adds markdown to JSON |
| gemma3:4b | FAIL | — | 0 | 500 error, no tool support |
| gemma3:12b | FAIL | — | 0 | 500 error, no tool support |

**WINNER: gemma4:31b** — 0.86s, 130 tokens, clean tool calls
**RUNNER UP: devstral-small-2:24b** — 0.92s, 131t
**CRITICAL: glm-5.2 is 4x slower on tool calls (3.48s vs 0.86s). This matters for agentic workflows.**

### Research (summarize, analyze, technical)
| model | latency | tokens | notes |
|-------|---------|--------|-------|
| nemotron-3-ultra | 1.83s | 255t | fast + efficient |
| gemma4:31b | 1.99s | 260t | solid |
| deepseek-v4-flash | 1.95s | 308t | good |
| qwen3-coder-next | 2.82s | 244t | decent |
| glm-5.2 | 5.12s | 434t | quality but slow + token heavy |
| minimax-m2.7 | 10.14s | 463t | way too slow |

**WINNER: nemotron-3-ultra** — fastest research (1.83s), efficient, good quality

### Writing (creative, structured, marketing copy)
| model | latency | tokens | sample |
|-------|---------|--------|--------|
| qwen3-coder-next | 1.79s | 146t | "Crafted for the bold and the unapologetic, *Obsidian Portfolio*..." |
| devstral-2:123b | 1.91s | 134t | clean and concise |
| gemma4:31b | 2.05s | 117t | "Elevate your vision with a cinematic, dark-mode sanctuary..." |
| glm-5.2 | 2.67s | 339t | quality but token heavy |

**WINNER: qwen3-coder-next** — fastest (1.79s), most efficient (146t), great copy
**RUNNER UP: gemma4:31b** — fire writing, 117 tokens, 2.05s

## Overall Rankings

### Best All-Rounders (can do everything well)
1. **glm-5.2** — best at casual + solid coding + good writing. Slow on tool calls (3.48s). Current default.
2. **gemma4:31b** — consistently top 3 in every category. Fastest tool calling. Great writing. Sneaky good.
3. **qwen3-coder-next** — dominates coding + writing. Bad at casual (too terse).

### Best by Category
| use case | best model | why |
|---------|-----------|-----|
| casual convo | glm-5.2 | natural, 1.17s, good vibe |
| coding | qwen3-coder-next | fast, efficient code, 391t |
| agentic/tool calling | gemma4:31b | 0.86s, 130 tokens |
| research | nemotron-3-ultra | 1.83s, efficient, technical |
| writing | qwen3-coder-next | 1.79s, great copy, 146t |
| fast classifier | devstral-small-2:24b | 0.92s, 131t |

### Models to Avoid
- **gemma3:4b / gemma3:12b** — can't do tool calling (500 errors)
- **glm-4.7** — slow (6-8s across the board)
- **deepseek-v3.2** — slow (7-8s)
- **minimax-m2.7** — inconsistent, sometimes 10s+
- **qwen3.5:397b** — 28s on reasoning test, way too slow
- **mistral-large-3:675b** — adds markdown formatting to JSON (bad for tool calls)
- **gpt-oss:20b** — empty outputs on 4/5 tests (confirmed in prior benchmarks too)
- **gemini-3-flash-preview** — empty on 3/5 tests in prior benchmarks

### Recommended Router Config
| task | model | why |
|------|-------|-----|
| casual convo (finn texting) | glm-5.2 | natural language, 1.17s |
| coding tasks | qwen3-coder-next | fast + efficient code |
| agentic / tool calling | gemma4:31b | 0.86s tool calls |
| research / summarization | nemotron-3-ultra | 1.83s, efficient |
| writing / creative | qwen3-coder-next or gemma4:31b | both fire |
| humanize internal tasks | devstral-small-2:24b | fast, cheap |
| memory extraction | ministral-3:14b | solid middle ground |
| browser automation | gemma4:31b | fast tool calling = fast browser |

### Token Efficiency (lower = cheaper)
Casual convo: devstral-small-2:24b (53t) < mistral-large (64t) < qwen3-coder-next (70t) < glm-5.2 (122t)
Tool calling: gemma4:31b (130t) = devstral-small (131t) = mistral-large (131t) << glm-5.2 (235t)

## Key Changes from Previous Benchmarks
- Previous benchmarks tested ~11 models with 5 simple prompt types. This round tests 24 models with 6 categories including REAL tool calling (OpenAI tools array), coding quality inspection, and token efficiency analysis.
- **gemma4:31b** was NOT tested before — it's a new discovery and a top performer.
- **qwen3-coder-next** was NOT tested before — dominates coding + writing.
- **nemotron-3-ultra** was NOT tested before — best research model.
- **devstral-small-2:24b** was NOT tested before — best budget/classifier model.
- Previous note about gemma3:4b being "best fast chat model" is still valid for casual only, but it CANNOT do tool calling (500 error).

## Benchmark Script Pattern
Use `execute_code` with urllib.request (NOT terminal curl — terminal blocks long localhost/firecrawl calls):
```python
import json, urllib.request, time

def call_model(model, messages, max_tokens=500, tools=None):
    payload = {"model": model, "messages": messages, "max_tokens": max_tokens, "temperature": 0.3}
    if tools:
        payload["tools"] = tools
    data = json.dumps(payload).encode()
    req = urllib.request.Request(BASE_URL, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    })
    start = time.time()
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    elapsed = time.time() - start
    choice = result["choices"][0]
    return {
        "content": choice["message"]["content"],
        "tool_calls": choice["message"].get("tool_calls", []),
        "latency": round(elapsed, 2),
        "tokens": result.get("usage", {}).get("total_tokens", 0)
    }
```
Split into batches of ~12 models to avoid execute_code 5-minute timeout. Save results to /tmp/ between batches.