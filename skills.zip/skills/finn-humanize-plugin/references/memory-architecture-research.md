# Memory Architecture Research — July 2026

## Problem: Hindsight Context Bloat
Hindsight memory gets injected into EVERY turn. As it grows, it crowds out the actual conversation in the context window. This is a fundamental scaling problem for long-running companion agents.

## External Research Findings

### Humalike x Hermes (July 22 2026)
Commercial plugin for Hermes that adds "social intelligence" — decides when to speak, paces replies, learns group tone, remembers who people are. Backed by investors in ElevenLabs/Revolut. Nous Research (Teknium) offered PR support for integration.

**Features we already have in humanize plugin:**
- Pre-response delay (log-normal timing) ✅
- 1-3 short messages instead of walls ✅
- No-response on conversation enders (8%) ✅
- Mood model + conversation state tracking ✅
- Emoji-only reactions ✅

**Gap:** Humalike focuses on *group* social intelligence (Slack/Telegram). Our plugin focuses on *1-on-1* companion feel. Both valid, different use cases.

### Obsidian Vault Agent Memory (RoundtableSpace, July 22 2026)
Open-source vault giving AI agents persistent memory, semantic search, automated work tracking. Captures decisions, wins, review evidence inside Obsidian.

**Verdict: Heavy for companion use case.** We already have hindsight + skills + session search + hermes-plans docs. Adding a whole note-taking app as dependency is bloat. Better to tighten what we have.

### Anthropic's 6 Agent Patterns (July 19 2026)
Hanako/X breakdown of agent architecture patterns:
1. Prompt chaining (fixed steps)
2. Routing (classify then handle)
3. Parallelization (multiple calls at once)
4. Orchestrator-workers (lead decides subtasks at runtime)
5. Evaluator-optimizer (write → grade → loop)
6. Autonomous agent (no fixed path)

**Key insight:** "Most production systems people call agents are pattern 1, 2, or 5 with good error handling." The autonomous pattern is expensive and has blast radius.

For companion AI, patterns 2 (routing) and 5 (evaluator-optimizer) are most relevant:
- **Routing:** Route memory retrieval vs. direct response based on query type
- **Evaluator-optimizer:** Could grade memory relevance before injecting into context

### ECC Repo — Anthropic Hackathon Winner (June 1 2026)
Affaan's "ECC" (agent harness performance optimization system): 183 agent skills, 48 sub-agents, 79 ready-made commands under MIT license.

**Key advice from community:** "Pick 3 first: planning, testing, code review. Once those are reliable, then add specialized agents. The stack only helps if the workflow stays simple."

**Relevance to us:** See how they structured sub-agents and commands. Could level up our skill architecture. Repo: github.com/affaan-m/ECC

## Production Memory Systems Research (July 24 2026)

### What Big Companies Actually Use
- **Claude/Anthropic:** Custom internal system, not public. Uses embeddings + vector search + tiered storage.
- **OpenAI:** Custom retrieval with vector store + memory endpoints.
- **Common pattern across all:** Embedding model → vector DB → similarity search → inject only top-K relevant chunks.

### Self-Hostable Options Ranked by Bloat

#### 1. Letta (formerly MemGPT) — The Research-Grade Option
- Built by Berkeley researchers specifically for agent memory
- Core concept: agents manage their own context by reading/writing "memory blocks"
- Memory types: core memory (persona, human), archival memory (long-term), recall memory (recent conversation)
- Self-hostable via Docker, 24k+ stars
- **Verdict for us:** It's a whole platform, not just a memory layer. Heavy for our use case but the architecture (memory blocks, self-managing context) is the gold standard to copy.

#### 2. pgvector — The Zero-Bloat Option
- PostgreSQL extension adding vector search
- Production-proven, millions of embeddings in the wild
- Supports HNSW and IVFFlat indexes for fast approximate search
- Distance metrics: L2, inner product, cosine similarity
- **Verdict for us:** BEST option if we already use Postgres. One `CREATE EXTENSION`, done.

#### 3. sqlite-vec — The File-Based Option
- Zero containers, single file, pure Python package
- Good for up to ~100k memories
- Perfect for companion-agent scale
- **Verdict for us:** BEST option if we want file-based portability and zero new infrastructure.

#### 4. ChromaDB — The Dedicated Vector DB
- Purpose-built for embeddings
- Runs in Docker or embeddable in Python
- Persistence, filtering, metadata
- Single container with Postgres backend
- **Verdict for us:** Good middle ground, but pgvector/sqlite-vec are leaner.

#### 5. Zep — The Agent-Specific Option
- Docker compose setup, designed exactly for AI agent memory
- Does embedding + retrieval + memory consolidation automatically
- Adds another container
- **Verdict for us:** Too heavy. Does too much we don't need.

#### 6. mem0 — The Extraction-Focused Option
- Open source, built for agent memory
- Has self-hosted option, extracts "facts" from conversations
- Needs container or Postgres
- **Verdict for us:** Middle ground, but sqlite-vec is simpler.

#### 7. Weaviate / Milvus — Enterprise Overkill
- Multiple containers, complex setup
- **Verdict for us:** Overkill for a personal companion agent.

## Recommended Architecture

### For Our Use Case (No-Bloat Rule Applies)
**Primary recommendation: pgvector OR sqlite-vec**

**Why:**
- We already have hindsight which likely uses sqlite or could use Postgres
- pgvector = one extension, zero new infra
- sqlite-vec = single file, zero containers
- Both do: embed text → store vector → cosine similarity search → return top-k

### Proposed Memory Tiering System

```
Hot Memory (injected every turn):
├── User profile (name, age, goals, preferences)
├── Current conversation topic
└── Active tasks/goals

Warm Memory (vector search, top-5 per turn):
├── Past project details
├── Previous conversation summaries
├── Skills learned
└── Shared experiences

Cold Memory (explicit search only):
├── Old session transcripts
├── Completed projects
└── Historical facts with low relevance
```

### Proposed Implementation Flow
1. Conversation happens
2. Extract memories (hindsight already does this)
3. Embed them with a local model (all-MiniLM-L6-v2 or similar)
4. Store in pgvector/sqlite-vec
5. On each turn: embed the query, search for top 5-10 similar memories
6. Only inject those into context

**Result:** Context stays flat forever, no matter how many memories we stack.

### Embedding Model Choice
- **Local (free, slower):** `sentence-transformers/all-MiniLM-L6-v2` — 22M params, fast enough on CPU, 384-dim embeddings
- **API (fast, costs):** OpenAI `text-embedding-3-small` — better quality, but adds dependency
- **Recommendation for us:** Local all-MiniLM. No API costs, no network dependency, runs offline.

## Recommended Next Steps
1. Keep episodic memory for short-term "living in the moment" feel
2. Add a lightweight vector store (pgvector if using Postgres, sqlite-vec otherwise) for long-term retrieval
3. Tier the memory: hot facts in context, warm facts in vector DB, cold facts archived
4. Avoid heavy dependencies — the user explicitly wants "no bloat"

## User Preference Captured
- User said: "i think we might need to change from hindsight or smth to make it better, or use something that can hold alot without using all ur context"
- User said: "research like the frontier, production memory packages that companies use, like claude and chatgpt"
- User dislikes bloat (reiterated from prior sessions)
- User wants me to remember everything from months back without losing track of current convo